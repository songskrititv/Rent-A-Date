export function formatBDT(amount: number): string {
  return `৳${amount.toLocaleString('en-IN')}`;
}

export function formatDate(dateString: string): string {
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  } catch {
    return dateString;
  }
}

export function formatTime(time24: string): string {
  if (!time24) return '';
  const [hours, minutes] = time24.split(':');
  const h = parseInt(hours, 10);
  if (isNaN(h)) return time24;
  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  return `${h12}:${minutes || '00'} ${ampm}`;
}

export const MANDATORY_CONSENT_NOTICE = 
  "Payment covers only the specific social experience described in the booking. It does not guarantee romantic interest, physical contact, sexual activity, or consent to any additional activity. Every participant has the right to set boundaries and withdraw consent at any time.";

export const MANDATORY_CONSENT_NOTICE_BN = 
  "পেমেন্ট শুধুমাত্র বুকিংয়ে উল্লেখিত নির্দিষ্ট সামাজিক অভিজ্ঞতাকে অন্তর্ভুক্ত করে। এটি কোনো রোমান্টিক আগ্রহ, শারীরিক ঘনিষ্ঠতা, বা অতিরিক্ত কোনো কার্যকলাপে সম্মতির নিশ্চয়তা দেয় না। প্রতিটি অংশগ্রহণকারীর নিজের সীমানা নির্ধারণ করার এবং যেকোনো সময় সম্মতি প্রত্যাহার করার পূর্ণ অধিকার রয়েছে।";

export const TRANSLATIONS = {
  en: {
    brandName: "Rent a Date",
    tagline: "Book a Companion. Share an Experience.",
    heroHeadline: "Good Company. Memorable Experiences.",
    heroSub: "Discover vetted companions in Dhaka for coffee meetups, fine dining, cultural galas, city explorations, and meaningful conversations.",
    explore: "Explore Companions",
    howItWorks: "How It Works",
    safety: "Safety & Boundaries",
    becomeCompanion: "Become a Companion",
    bookServices: "Book Services",
    manageServices: "Manage My Services",
    adminArea: "Admin Panel",
    searchAreaPlaceholder: "Area (e.g., Gulshan, Dhanmondi, Banani)",
    allCategories: "All Experiences",
    searchCta: "Find Companions",
    startingFrom: "Starting from",
    verifiedBadge: "ID Verified",
    perHour: "per hour",
    perSession: "per session",
    perPackage: "package",
    bookNow: "Book This Service",
    viewProfile: "View Profile & Rates",
    safetyNoticeTitle: "Code of Conduct & Service Boundaries",
    demoSandboxTag: "DEMO SANDBOX",
    demoNotice: "Simulation mode active. No actual banking or payment gateway transactions are processed.",
    signIn: "Sign In",
    signUp: "Sign Up",
    logout: "Log Out",
    loginTitle: "Sign In to Your Account",
    registerTitle: "Create a Free Account",
    joinAsCompanion: "Become a Companion Provider",
    quickDemoLogin: "1-Click Demo Accounts",
    referralProgram: "Refer & Earn",
    referralTagline: "Invite friends to verify profile and earn ৳500 booking credits",
    yourCredits: "Available Credits"
  },
  bn: {
    brandName: "রেন্ট আ ডেট",
    tagline: "সঙ্গী বুক করুন। সুন্দর অভিজ্ঞতা ভাগ করুন।",
    heroHeadline: "ভালো সান্নিধ্য। স্মরণীয় অভিজ্ঞতা।",
    heroSub: "ঢাকায় কফি আড্ডা, ডিনার, সাংস্কৃতিক অনুষ্ঠান, শিল্পকলা প্রদর্শনী ও অর্থপূর্ণ কথোপকথনের জন্য বিশ্বস্ত সামাজিক সঙ্গী খুঁজুন।",
    explore: "সঙ্গী খুঁজুন",
    howItWorks: "কীভাবে কাজ করে",
    safety: "নিরাপত্তা ও নীতিমালা",
    becomeCompanion: "সঙ্গী হিসেবে যোগ দিন",
    bookServices: "সার্ভিস বুক করুন",
    manageServices: "আমার সার্ভিস পরিচালনা",
    adminArea: "অ্যাডমিন প্যানেল",
    searchAreaPlaceholder: "এলাকা (যেমন: গুলশান, ধানমন্ডি, বনানী)",
    allCategories: "সকল অভিজ্ঞতা",
    searchCta: "অনুসন্ধান করুন",
    startingFrom: "শুরু",
    verifiedBadge: "আইডি যাচাইকৃত",
    perHour: "প্রতি ঘণ্টা",
    perSession: "প্রতি সেশন",
    perPackage: "প্যাকেজ",
    bookNow: "বুক করুন",
    viewProfile: "প্রোফাইল ও রেট দেখুন",
    safetyNoticeTitle: "আচরণবিধি ও সেবার সীমানা",
    demoSandboxTag: "ডেমো স্যান্ডবক্স",
    demoNotice: "সিমুলেশন মোড সক্রিয়। কোনো আসল আর্থিক লেনদেন হচ্ছে না।",
    signIn: "সাইন ইন / লগইন",
    signUp: "সাইন আপ",
    logout: "লগআউট",
    loginTitle: "আপনার অ্যাকাউন্টে লগইন করুন",
    registerTitle: "নতুন অ্যাকাউন্ট তৈরি করুন",
    joinAsCompanion: "কম্প্যানিয়ন হিসেবে যোগ দিন",
    quickDemoLogin: "১-ক্লিকে তাৎক্ষণিক ডেমো লগইন",
    referralProgram: "রেফার ও ক্রেডিট",
    referralTagline: "বন্ধুদের আমন্ত্রণ জানিয়ে ভেরিফিকেশনে ৳৫০০ ক্রেডিট অর্জন করুন",
    yourCredits: "উপলব্ধ ক্রেডিট"
  }
};
