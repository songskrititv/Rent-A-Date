export interface SafeVenue {
  id: string;
  name: string;
  area: string;
  category: 'Specialty Cafe' | 'Fine Dining' | 'Art Gallery & Cultural' | 'Heritage Space';
  address: string;
  popularFor: string;
  safetyRating: number;
}

export const DHAKA_SAFE_VENUES: SafeVenue[] = [
  {
    id: 'vn-1',
    name: 'North End Coffee Roasters',
    area: 'Dhanmondi',
    category: 'Specialty Cafe',
    address: 'House 54, Road 27, Dhanmondi, Dhaka',
    popularFor: 'Artisanal pour-overs, relaxed conversation, quiet ambiance',
    safetyRating: 4.9
  },
  {
    id: 'vn-2',
    name: 'Bengal Shilpalay & Bengal Cafe',
    area: 'Dhanmondi',
    category: 'Art Gallery & Cultural',
    address: 'House 42, Road 27 (Old 16), Dhanmondi, Dhaka',
    popularFor: 'Contemporary art exhibitions, bookstore, peaceful courtyard',
    safetyRating: 5.0
  },
  {
    id: 'vn-3',
    name: 'Crimson Cup Coffee',
    area: 'Banani',
    category: 'Specialty Cafe',
    address: 'House 54, Road 11, Block D, Banani, Dhaka',
    popularFor: 'Vibrant youth cafe scene, mocha, outdoor terrace',
    safetyRating: 4.8
  },
  {
    id: 'vn-4',
    name: 'Izumi Japanese Kitchen',
    area: 'Gulshan 2',
    category: 'Fine Dining',
    address: 'House 24/C, Road 113, Gulshan 2, Dhaka',
    popularFor: 'Gourmet dining, private zen garden courtyard, dinner dates',
    safetyRating: 4.9
  },
  {
    id: 'vn-5',
    name: "Gloria Jean's Coffees",
    area: 'Gulshan 1',
    category: 'Specialty Cafe',
    address: 'Navana Platinum Square, Gulshan 1 Avenue, Dhaka',
    popularFor: 'Spacious seating, evening iced drinks, central meeting spot',
    safetyRating: 4.9
  },
  {
    id: 'vn-6',
    name: 'Drik Gallery & Courtyard Cafe',
    area: 'Dhanmondi / Panthapath',
    category: 'Art Gallery & Cultural',
    address: 'DrikPath Bhaban, 16 Sukrabad, Panthapath, Dhaka',
    popularFor: 'Photography exhibitions, social talks, indie rooftop vibe',
    safetyRating: 4.9
  },
  {
    id: 'vn-7',
    name: 'Trouvaille Coffee & Eatery',
    area: 'Uttara',
    category: 'Specialty Cafe',
    address: 'House 21, Gareeb-e-Nawaz Avenue, Sector 11, Uttara, Dhaka',
    popularFor: 'Cozy desserts, quiet corner talks, pastel aesthetics',
    safetyRating: 4.8
  },
  {
    id: 'vn-8',
    name: 'Tabaq Coffee',
    area: 'Bashundhara R/A',
    category: 'Specialty Cafe',
    address: 'Ground Floor, Jamuna Future Park / Bashundhara Gate, Dhaka',
    popularFor: 'Specialty espresso, warm lighting, convenient public access',
    safetyRating: 4.8
  },
  {
    id: 'vn-9',
    name: 'Historic Beauty Boarding',
    area: 'Old Dhaka',
    category: 'Heritage Space',
    address: '1 Bangla Bazar, Old Dhaka',
    popularFor: 'Literary heritage, afternoon cha, classic Bengali culture',
    safetyRating: 4.7
  }
];

export interface PromoCode {
  code: string;
  discountType: 'fixed' | 'percentage';
  discountValue: number;
  description: string;
  minAmount: number;
}

export const ACTIVE_PROMO_CODES: PromoCode[] = [
  {
    code: 'DHAKA2026',
    discountType: 'fixed',
    discountValue: 300,
    description: '৳300 off on any social experience in Dhaka',
    minAmount: 1000
  },
  {
    code: 'FIRSTDATE',
    discountType: 'percentage',
    discountValue: 15,
    description: '15% discount on your first companionship booking',
    minAmount: 800
  },
  {
    code: 'COFFEE100',
    discountType: 'fixed',
    discountValue: 100,
    description: '৳100 off on casual coffee meetups',
    minAmount: 700
  }
];
