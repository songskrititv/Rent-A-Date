import { ServiceCategory } from '../types';

export const INITIAL_CATEGORIES: ServiceCategory[] = [
  {
    id: 'cat-1',
    name: 'Romantic Date',
    nameBn: 'রোমান্টিক ডেট',
    slug: 'romantic-date',
    description: 'A charming, respectful dining or evening companionship experience with engaging conversation and warm company.',
    icon: 'Heart',
    suggestedDuration: '2 - 3 Hours',
    minPriceEstimate: 1500,
    isActive: true,
    order: 1
  },
  {
    id: 'cat-2',
    name: 'Coffee Meetup',
    nameBn: 'কফি আড্ডা',
    slug: 'coffee-meetup',
    description: 'Casual, relaxed conversations at a vibrant cafe. Ideal for casual networking, venting, or exchanging thoughts.',
    icon: 'Coffee',
    suggestedDuration: '1 - 2 Hours',
    minPriceEstimate: 800,
    isActive: true,
    order: 2
  },
  {
    id: 'cat-3',
    name: 'Lunch or Dinner Companion',
    nameBn: 'লাঞ্চ বা ডিনার সঙ্গী',
    slug: 'lunch-dinner',
    description: 'Share a delicious meal without dining alone. Great for foodies exploring culinary hotspots or upscale restaurants.',
    icon: 'UtensilsCrossed',
    suggestedDuration: '2 - 3 Hours',
    minPriceEstimate: 1800,
    isActive: true,
    order: 3
  },
  {
    id: 'cat-4',
    name: 'Social Conversation',
    nameBn: 'সামাজিক আড্ডা ও মতবিনিময়',
    slug: 'social-conversation',
    description: 'Deep, attentive, and intellectually stimulating dialogue in quiet public spaces or campus gardens.',
    icon: 'MessagesSquare',
    suggestedDuration: '1 - 2 Hours',
    minPriceEstimate: 700,
    isActive: true,
    order: 4
  },
  {
    id: 'cat-5',
    name: 'Theatre & Cultural Event',
    nameBn: 'নাটক ও সাংস্কৃতিক অনুষ্ঠান',
    slug: 'theatre-cultural',
    description: 'Attend stage plays at Shilpakala Academy, poetry readings, or traditional film festivals with an appreciative partner.',
    icon: 'Theater',
    suggestedDuration: '2 - 4 Hours',
    minPriceEstimate: 1200,
    isActive: true,
    order: 5
  },
  {
    id: 'cat-6',
    name: 'Concert Companion',
    nameBn: 'কনসার্ট সঙ্গী',
    slug: 'concert-companion',
    description: 'Experience live musical gigs, acoustic nights, or band concerts with someone who shares your music taste.',
    icon: 'Music2',
    suggestedDuration: '3 - 5 Hours',
    minPriceEstimate: 2000,
    isActive: true,
    order: 6
  },
  {
    id: 'cat-7',
    name: 'Art Exhibition Companion',
    nameBn: 'শিল্পকলা প্রদর্শনী সঙ্গী',
    slug: 'art-exhibition',
    description: 'Visit gallery openings (Bengal Shilpalay, Drik Gallery) and dissect modern artwork in good company.',
    icon: 'Palette',
    suggestedDuration: '2 Hours',
    minPriceEstimate: 1200,
    isActive: true,
    order: 7
  },
  {
    id: 'cat-8',
    name: 'Party & Social Event Companion',
    nameBn: 'পার্টি ও সামাজিক অনুষ্ঠান',
    slug: 'party-social-event',
    description: 'A polished, articulate companion as your +1 for corporate galas, weddings, networking mixers, or launch parties.',
    icon: 'Sparkles',
    suggestedDuration: '3 - 5 Hours',
    minPriceEstimate: 3000,
    isActive: true,
    order: 8
  },
  {
    id: 'cat-9',
    name: 'Travel & City Companion',
    nameBn: 'শহর ভ্রমণ ও গাইড সঙ্গী',
    slug: 'travel-city-companion',
    description: 'Explore the heritage trails of Old Dhaka, scenic boat rides, or hidden architectural gems with an informed local guide.',
    icon: 'Compass',
    suggestedDuration: '4 - 6 Hours',
    minPriceEstimate: 2500,
    isActive: true,
    order: 9
  },
  {
    id: 'cat-10',
    name: 'Other Approved Social Experience',
    nameBn: 'অন্যান্য অনুমোদিত সামাজিক অভিজ্ঞতা',
    slug: 'other-social',
    description: 'Book shopping companions, book fair (Ekushey Boi Mela) strolls, or sports match attendance within verified guidelines.',
    icon: 'Smile',
    suggestedDuration: '2 Hours',
    minPriceEstimate: 1000,
    isActive: true,
    order: 10
  }
];
