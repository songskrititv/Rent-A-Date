import React, { useState, useMemo } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { SafetyBanner } from './components/common/SafetyBanner';
import { Footer } from './components/common/Footer';
import { HeroSection } from './components/discovery/HeroSection';
import { CompanionCard } from './components/discovery/CompanionCard';
import { FilterSidebar } from './components/discovery/FilterSidebar';
import { CompanionDetailModal } from './components/discovery/CompanionDetailModal';
import { BookingFlowModal } from './components/booking/BookingFlowModal';
import { CustomerDashboard } from './components/customer/CustomerDashboard';
import { ProviderDashboard } from './components/provider/ProviderDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { HowItWorksView } from './components/common/HowItWorksView';
import { MessagingDrawer } from './components/messages/MessagingDrawer';
import { SafetyModal } from './components/safety/SafetyModal';
import { LiveMeetupModal } from './components/common/LiveMeetupModal';
import { VoiceCallModal } from './components/common/VoiceCallModal';
import { AuthModal } from './components/auth/AuthModal';
import { ReferralProgramModule } from './components/referral/ReferralProgramModule';
import { PhoneInstallModal } from './components/pwa/PhoneInstallModal';
import { MobileInstallBar } from './components/pwa/MobileInstallBar';
import { OfflineBanner } from './components/pwa/OfflineBanner';
import { Sparkles, SlidersHorizontal, ArrowUpDown, Gift } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { 
    allUsers, 
    services, 
    categories, 
    activeView, 
    setActiveView, 
    selectedProviderId, 
    setSelectedProviderId,
    activateProviderStatus,
    currentUser,
    language
  } = useApp();

  // Modals and Drawers state
  const [safetyModalOpen, setSafetyModalOpen] = useState(false);
  const [reportTargetUserId, setReportTargetUserId] = useState<string | null>(null);
  const [messagesDrawerOpen, setMessagesDrawerOpen] = useState(false);
  const [initialChatPartnerId, setInitialChatPartnerId] = useState<string | null>(null);
  const [bookingServiceId, setBookingServiceId] = useState<string | null>(null);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);
  
  // PWA Phone installation state
  const [phoneInstallModalOpen, setPhoneInstallModalOpen] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  React.useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  // Filters state for Explore page
  const [filters, setFilters] = useState({
    searchQuery: '',
    selectedCategory: '',
    selectedArea: '',
    gender: 'all',
    maxPrice: 5000,
    verifiedOnly: false,
    sortBy: 'recommended' as 'recommended' | 'price_low' | 'price_high' | 'rating'
  });

  const handleFilterUpdate = (updates: Partial<typeof filters>) => {
    setFilters(prev => ({ ...prev, ...updates }));
  };

  const handleResetFilters = () => {
    setFilters({
      searchQuery: '',
      selectedCategory: '',
      selectedArea: '',
      gender: 'all',
      maxPrice: 5000,
      verifiedOnly: false,
      sortBy: 'recommended'
    });
  };

  // Filter companions list
  const activeProviders = useMemo(() => {
    return allUsers.filter(u => u.isProviderActive);
  }, [allUsers]);

  const filteredProviders = useMemo(() => {
    return activeProviders.filter(provider => {
      // 1. Keyword search (Name, Bio, Interests)
      if (filters.searchQuery) {
        const query = filters.searchQuery.toLowerCase();
        const matchesName = provider.displayName.toLowerCase().includes(query) || provider.fullName.toLowerCase().includes(query);
        const matchesBio = provider.bio.toLowerCase().includes(query);
        const matchesInterests = provider.interests.some(i => i.toLowerCase().includes(query));
        if (!matchesName && !matchesBio && !matchesInterests) return false;
      }

      // 2. Dhaka Area filter
      if (filters.selectedArea && !provider.area.toLowerCase().includes(filters.selectedArea.toLowerCase())) {
        return false;
      }

      // 3. Gender preference filter
      if (filters.gender !== 'all' && provider.gender !== filters.gender) {
        return false;
      }

      // 4. Verification filter
      if (filters.verifiedOnly && provider.verificationStatus !== 'verified') {
        return false;
      }

      // 5. Category and Price filter (check provider services)
      const providerServices = services.filter(s => s.providerId === provider.id && s.isActive);
      if (providerServices.length === 0) return false;

      if (filters.selectedCategory) {
        const hasCategory = providerServices.some(s => s.categoryId === filters.selectedCategory);
        if (!hasCategory) return false;
      }

      // Max price check
      const minServicePrice = Math.min(...providerServices.map(s => s.price));
      if (minServicePrice > filters.maxPrice) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (filters.sortBy === 'rating') {
        return b.rating - a.rating;
      }
      if (filters.sortBy === 'price_low' || filters.sortBy === 'price_high') {
        const aMinPrice = Math.min(...services.filter(s => s.providerId === a.id).map(s => s.price));
        const bMinPrice = Math.min(...services.filter(s => s.providerId === b.id).map(s => s.price));
        return filters.sortBy === 'price_low' ? aMinPrice - bMinPrice : bMinPrice - aMinPrice;
      }
      return 0; // recommended
    });
  }, [activeProviders, services, filters]);

  // Open direct chat
  const handleOpenDirectChat = (partnerId?: string) => {
    if (partnerId) setInitialChatPartnerId(partnerId);
    setMessagesDrawerOpen(true);
  };

  // Open report modal
  const handleOpenReport = (targetUserId: string) => {
    setReportTargetUserId(targetUserId);
    setSafetyModalOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF7F5] text-stone-900">
      
      {/* Header and Safety Boundary Bar */}
      <Header
        onOpenSafetyModal={() => {
          setReportTargetUserId(null);
          setSafetyModalOpen(true);
        }}
        onOpenMessages={() => handleOpenDirectChat()}
        onOpenPhoneInstallModal={() => setPhoneInstallModalOpen(true)}
      />
      <SafetyBanner
        onOpenSafetyModal={() => {
          setReportTargetUserId(null);
          setSafetyModalOpen(true);
        }}
      />

      {/* Main Body Routing */}
      <main className="flex-1">
        {activeView === 'explore' && (
          <div className="space-y-12">
            {/* Hero & Quick Discovery */}
            <HeroSection
              onSearch={({ area, categoryId, genderPref }) => {
                handleFilterUpdate({
                  selectedArea: area,
                  selectedCategory: categoryId,
                  gender: genderPref
                });
                const el = document.getElementById('explore-listings');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              onBecomeCompanion={activateProviderStatus}
            />

            {/* Main Discovery Container */}
            <div id="explore-listings" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6 scroll-mt-24">
              
              {/* Category Quick Badges Strip */}
              <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
                <button
                  onClick={() => handleFilterUpdate({ selectedCategory: '' })}
                  className={`px-4 py-2 text-xs font-semibold rounded-xl border transition-all whitespace-nowrap cursor-pointer ${
                    filters.selectedCategory === ''
                      ? 'border-[#721C38] bg-[#721C38] text-white shadow-xs'
                      : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  All Experiences
                </button>
                {categories.filter(c => c.isActive).map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => handleFilterUpdate({ selectedCategory: cat.id })}
                    className={`px-4 py-2 text-xs font-semibold rounded-xl border transition-all whitespace-nowrap cursor-pointer ${
                      filters.selectedCategory === cat.id
                        ? 'border-[#721C38] bg-[#721C38] text-white shadow-xs'
                        : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    {language === 'bn' ? cat.nameBn : cat.name}
                  </button>
                ))}
              </div>

              {/* Referral Promotion Strip */}
              <div className="bg-gradient-to-r from-rose-50 via-white to-amber-50/50 rounded-2xl p-3.5 sm:p-4 border border-rose-200/80 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#721C38] text-white flex items-center justify-center shrink-0 shadow-2xs">
                    <Gift className="w-5 h-5 text-rose-200" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-stone-900 flex items-center gap-2">
                      <span>{language === 'bn' ? 'রেফারেল প্রোগ্রাম: বন্ধুদের আমন্ত্রণ জানিয়ে ৳৫০০ ক্রেডিট অর্জন করুন' : 'Refer Friends & Earn ৳500 Booking Credits'}</span>
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">
                        {language === 'bn' ? 'ভেরিফিকেশন বোনাস' : 'Verification Reward'}
                      </span>
                    </h4>
                    <p className="text-[11px] text-stone-500">
                      {language === 'bn' 
                        ? 'আপনার বন্ধু প্রোফাইল বা ফেস ভেরিফিকেশন করলেই তাৎক্ষণিক ওয়ালেটে ক্রেডিট যোগ হবে।' 
                        : 'Instant platform credit when your invited friend completes profile verification.'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveView('referral_program')}
                  className="px-4 py-2 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-bold rounded-xl transition-all shadow-2xs cursor-pointer shrink-0 flex items-center gap-1.5 self-end sm:self-center"
                >
                  <span>{language === 'bn' ? 'রেফারেল ও ক্রেডিট দেখুন' : 'Open Referral Hub'}</span>
                  <ArrowUpDown className="w-3.5 h-3.5 rotate-90" />
                </button>
              </div>

              {/* Discovery Grid with Sidebar */}
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
                
                {/* Desktop Filter Sidebar */}
                <aside className="hidden lg:block lg:col-span-1 sticky top-28">
                  <FilterSidebar
                    filters={filters}
                    onChange={handleFilterUpdate}
                    onReset={handleResetFilters}
                    resultCount={filteredProviders.length}
                  />
                </aside>

                {/* Mobile Filter Trigger */}
                <div className="lg:hidden flex items-center justify-between gap-3">
                  <button
                    onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
                    className="px-4 py-2 bg-white border border-stone-200 rounded-xl text-xs font-semibold flex items-center gap-2 shadow-xs"
                  >
                    <SlidersHorizontal className="w-3.5 h-3.5 text-[#721C38]" />
                    <span>Filter & Search ({filteredProviders.length})</span>
                  </button>

                  <select
                    value={filters.sortBy}
                    onChange={(e) => handleFilterUpdate({ sortBy: e.target.value as any })}
                    className="text-xs bg-white border border-stone-200 rounded-xl px-3 py-2 text-stone-700"
                  >
                    <option value="recommended">Recommended</option>
                    <option value="price_low">Price: Low to High</option>
                    <option value="price_high">Price: High to Low</option>
                    <option value="rating">Highest Rated</option>
                  </select>
                </div>

                {/* Mobile Filter Drawer / Popover */}
                {mobileFilterOpen && (
                  <div className="lg:hidden col-span-1">
                    <FilterSidebar
                      filters={filters}
                      onChange={handleFilterUpdate}
                      onReset={handleResetFilters}
                      resultCount={filteredProviders.length}
                    />
                  </div>
                )}

                {/* Companions Card Grid */}
                <div className="lg:col-span-3 space-y-6">
                  
                  {/* Top sort and results header */}
                  <div className="hidden lg:flex items-center justify-between pb-2 border-b border-stone-200/60 text-xs">
                    <span className="text-stone-500 font-medium">
                      Showing <strong className="text-stone-900">{filteredProviders.length}</strong> vetted companions in Dhaka
                    </span>

                    <div className="flex items-center gap-2">
                      <span className="text-stone-400 font-medium flex items-center gap-1">
                        <ArrowUpDown className="w-3.5 h-3.5" />
                        Sort by:
                      </span>
                      <select
                        value={filters.sortBy}
                        onChange={(e) => handleFilterUpdate({ sortBy: e.target.value as any })}
                        className="bg-transparent border-0 font-semibold text-stone-800 focus:outline-none cursor-pointer"
                      >
                        <option value="recommended">Recommended</option>
                        <option value="price_low">Price: Low to High</option>
                        <option value="price_high">Price: High to Low</option>
                        <option value="rating">Highest Rated</option>
                      </select>
                    </div>
                  </div>

                  {/* Empty state */}
                  {filteredProviders.length === 0 ? (
                    <div className="text-center py-20 bg-white rounded-3xl border border-stone-200/90 p-8 space-y-4 shadow-xs">
                      <Sparkles className="w-10 h-10 text-stone-300 mx-auto" />
                      <h3 className="font-serif text-xl font-bold text-stone-800">No companions match your criteria</h3>
                      <p className="text-xs text-stone-500 max-w-md mx-auto">
                        Try resetting your filters or adjusting your budget and neighborhood parameters.
                      </p>
                      <button
                        onClick={handleResetFilters}
                        className="px-5 py-2.5 bg-[#721C38] text-white text-xs font-semibold rounded-xl hover:bg-[#58152B] transition-colors"
                      >
                        Reset All Filters
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filteredProviders.map(companion => (
                        <CompanionCard
                          key={companion.id}
                          companion={companion}
                          onSelect={(id) => setSelectedProviderId(id)}
                        />
                      ))}
                    </div>
                  )}

                </div>

              </div>

            </div>
          </div>
        )}

        {/* How It Works View */}
        {activeView === 'how_it_works' && (
          <HowItWorksView
            onExplore={() => setActiveView('explore')}
            onBecomeCompanion={activateProviderStatus}
          />
        )}

        {/* Customer Dashboard View */}
        {activeView === 'customer_dashboard' && (
          <CustomerDashboard
            onOpenMessages={handleOpenDirectChat}
            onExplore={() => setActiveView('explore')}
          />
        )}

        {/* Provider Dashboard View */}
        {activeView === 'provider_dashboard' && (
          <ProviderDashboard
            onOpenMessages={handleOpenDirectChat}
          />
        )}

        {/* Referral Program View */}
        {activeView === 'referral_program' && (
          <ReferralProgramModule
            onExplore={() => setActiveView('explore')}
            onBookWithCredits={() => {
              setActiveView('explore');
              const el = document.getElementById('explore-listings');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
          />
        )}

        {/* Admin Dashboard View */}
        {activeView === 'admin_dashboard' && (
          <AdminDashboard />
        )}

      </main>

      {/* Footer */}
      <Footer
        onOpenSafetyModal={() => {
          setReportTargetUserId(null);
          setSafetyModalOpen(true);
        }}
      />

      {/* COMPANION DETAIL MODAL (Profile & Published Services) */}
      {selectedProviderId && (
        <CompanionDetailModal
          companionId={selectedProviderId}
          onClose={() => setSelectedProviderId(null)}
          onStartBooking={(serviceId) => {
            setBookingServiceId(serviceId);
          }}
          onOpenMessage={(recipientId) => {
            setSelectedProviderId(null);
            handleOpenDirectChat(recipientId);
          }}
          onReport={(reportedId) => {
            handleOpenReport(reportedId);
          }}
        />
      )}

      {/* BOOKING ENGINE MODAL */}
      {bookingServiceId && (
        <BookingFlowModal
          serviceId={bookingServiceId}
          onClose={() => setBookingServiceId(null)}
          onSuccess={(bookingId) => {
            setBookingServiceId(null);
            setSelectedProviderId(null);
            setActiveView('customer_dashboard');
          }}
        />
      )}

      {/* SAFETY & BOUNDARIES / REPORT MODAL */}
      <SafetyModal
        isOpen={safetyModalOpen}
        onClose={() => {
          setSafetyModalOpen(false);
          setReportTargetUserId(null);
        }}
        targetReportUserId={reportTargetUserId}
      />

      {/* IN-APP MESSAGING DRAWER */}
      <MessagingDrawer
        isOpen={messagesDrawerOpen}
        onClose={() => {
          setMessagesDrawerOpen(false);
          setInitialChatPartnerId(null);
        }}
        initialRecipientId={initialChatPartnerId}
      />

      {/* LIVE MEETUP HUD & SOS TRACKER */}
      <LiveMeetupModal />

      {/* MASKED ENCRYPTED IN-APP VOICE CALL */}
      <VoiceCallModal />

      {/* SIGN UP & LOGIN AUTHENTICATION MODAL */}
      <AuthModal />

      {/* PWA MOBILE INSTALL & OFFLINE MODULES */}
      <OfflineBanner />

      <MobileInstallBar 
        deferredPrompt={deferredPrompt}
        setDeferredPrompt={setDeferredPrompt}
        onOpenPhoneModal={() => setPhoneInstallModalOpen(true)}
      />

      <PhoneInstallModal 
        isOpen={phoneInstallModalOpen}
        onClose={() => setPhoneInstallModalOpen(false)}
        deferredPrompt={deferredPrompt}
        onInstallDirectly={async () => {
          if (deferredPrompt) {
            try {
              deferredPrompt.prompt();
              await deferredPrompt.userChoice;
              setDeferredPrompt(null);
            } catch (err) {
              console.warn('Install error:', err);
            }
          }
        }}
      />

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
