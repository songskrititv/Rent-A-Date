import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User, 
  ServiceCategory, 
  ProviderService, 
  Booking, 
  BookingStatus, 
  PaymentMethod, 
  PaymentTransaction, 
  PayoutRecord, 
  Review, 
  Conversation, 
  Message, 
  SafetyReport, 
  PlatformConfig,
  BookingPriceSnapshot,
  ReferralRecord,
  CreditTransaction
} from '../types';
import { 
  INITIAL_USERS, 
  INITIAL_SERVICES, 
  INITIAL_BOOKINGS, 
  INITIAL_REVIEWS, 
  INITIAL_PAYOUTS, 
  INITIAL_CONVERSATIONS, 
  INITIAL_MESSAGES,
  INITIAL_REFERRALS,
  INITIAL_CREDIT_TRANSACTIONS
} from '../data/mockData';
import { INITIAL_CATEGORIES } from '../data/categories';
import { auth, googleProvider, testFirestoreConnection } from '../firebase/config';
import { signInWithPopup, onAuthStateChanged, signOut } from 'firebase/auth';
import { 
  syncUserProfileToFirestore, 
  getUserProfileFromFirestore, 
  saveBookingToFirestore, 
  recordCreditTransactionToFirestore 
} from '../firebase/firestoreService';

interface AppContextType {
  currentUser: User;
  allUsers: User[];
  categories: ServiceCategory[];
  services: ProviderService[];
  bookings: Booking[];
  reviews: Review[];
  payouts: PayoutRecord[];
  transactions: PaymentTransaction[];
  conversations: Conversation[];
  messages: Message[];
  safetyReports: SafetyReport[];
  platformConfig: PlatformConfig;
  referrals: ReferralRecord[];
  creditTransactions: CreditTransaction[];
  userReferralCode: string;
  walletCredits: number;
  referralModalOpen: boolean;
  setReferralModalOpen: (open: boolean) => void;
  sendReferralInvite: (friendName: string, friendContact: string) => { success: boolean; referral: ReferralRecord };
  verifyFriendAndCreditReferrer: (referralId: string, verificationMethod?: string) => void;
  sendVerificationReminder: (referralId: string) => void;
  applyReferralCodeOnSignup: (code: string) => { valid: boolean; referrerName?: string; bonusCredits?: number };
  deductCreditsForBooking: (bookingId: string, amount: number) => boolean;
  getReferralStats: () => { 
    totalEarned: number; 
    availableBalance: number; 
    pendingCredits: number; 
    totalInvited: number; 
    verifiedCount: number; 
    pendingCount: number; 
  };
  activeRole: 'customer' | 'provider' | 'admin';
  activeView: string;
  selectedProviderId: string | null;
  savedProviderIds: string[];
  language: 'en' | 'bn';
  notificationCount: number;

  // Authentication State & Modals
  isAuthenticated: boolean;
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  authModalMode: 'signin' | 'signup';
  setAuthModalMode: (mode: 'signin' | 'signup') => void;
  login: (emailOrPhone: string, password?: string) => { success: boolean; error?: string };
  registerUser: (userData: Omit<User, 'id' | 'rating' | 'reviewCount' | 'joinedDate'>) => { success: boolean; user?: User; error?: string };
  signInWithGoogle: () => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  firebaseConnected: boolean;

  // Actions
  setActiveView: (view: string) => void;
  setSelectedProviderId: (id: string | null) => void;
  setActiveRole: (role: 'customer' | 'provider' | 'admin') => void;
  switchUser: (userId: string) => void;
  setLanguage: (lang: 'en' | 'bn') => void;
  toggleSaveProvider: (providerId: string) => void;
  
  // Booking actions
  createBooking: (data: {
    providerId: string;
    serviceId: string;
    scheduledDate: string;
    scheduledTime: string;
    durationHours: number;
    meetupLocation: string;
    venueId?: string;
    promoCode?: string;
    discountAmount?: number;
    specialNotes?: string;
  }) => Booking;
  updateBookingStatus: (bookingId: string, status: BookingStatus, reason?: string) => void;
  processPayment: (bookingId: string, method: PaymentMethod) => Promise<boolean>;
  
  // Live Meetup Tracking & SOS
  startMeetup: (bookingId: string) => void;
  endMeetup: (bookingId: string) => void;
  addTip: (bookingId: string, tipAmount: number) => void;
  activeLiveBookingId: string | null;
  setActiveLiveBookingId: (id: string | null) => void;

  // Masked Voice Call
  activeVoiceCallPartner: User | null;
  setActiveVoiceCallPartner: (user: User | null) => void;

  // Provider service management
  addService: (newService: Omit<ProviderService, 'id' | 'providerId' | 'isActive'>) => void;
  updateService: (serviceId: string, updates: Partial<ProviderService>) => void;
  toggleServiceActive: (serviceId: string) => void;
  
  // Earnings & Payouts
  requestPayout: (payout: {
    bookingId: string;
    bookingCode: string;
    grossAmount: number;
    commissionAmount: number;
    netAmount: number;
    payoutMethod: 'bkash' | 'nagad' | 'bank_transfer';
    accountNumber: string;
  }) => void;
  
  // Verification
  submitVerification: (docType: 'nid' | 'passport' | 'driving_license') => void;
  adminApproveVerification: (userId: string) => void;
  adminRejectVerification: (userId: string) => void;
  
  // Admin platform settings
  updateCommissionRate: (rate: number) => void;
  toggleCategoryStatus: (categoryId: string) => void;
  adminSuspendUser: (userId: string) => void;
  
  // Safety & Messaging
  submitReport: (report: { reportedUserId: string; bookingCode?: string; reason: string; details: string }) => void;
  sendMessage: (recipientId: string, text: string, bookingRef?: string) => void;
  submitReview: (bookingId: string, rating: number, comment: string) => void;
  activateProviderStatus: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [allUsers, setAllUsers] = useState<User[]>(INITIAL_USERS);
  const [currentUserId, setCurrentUserId] = useState<string>('usr-customer-demo');
  const [categories, setCategories] = useState<ServiceCategory[]>(INITIAL_CATEGORIES);
  const [services, setServices] = useState<ProviderService[]>(INITIAL_SERVICES);
  const [bookings, setBookings] = useState<Booking[]>(INITIAL_BOOKINGS);
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
  const [payouts, setPayouts] = useState<PayoutRecord[]>(INITIAL_PAYOUTS);
  const [transactions, setTransactions] = useState<PaymentTransaction[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>(INITIAL_CONVERSATIONS);
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [safetyReports, setSafetyReports] = useState<SafetyReport[]>([]);
  const [savedProviderIds, setSavedProviderIds] = useState<string[]>(['usr-1', 'usr-2']);
  
  const [platformConfig, setPlatformConfig] = useState<PlatformConfig>({
    commissionRate: 0.20, // 20% standard platform commission
    currencyCode: 'BDT',
    currencySymbol: '৳',
    initialCity: 'Dhaka',
    minAge: 18,
    isDemoMode: true
  });

  const [activeRole, setActiveRole] = useState<'customer' | 'provider' | 'admin'>('customer');
  const [activeView, setActiveView] = useState<string>('explore');
  const [selectedProviderId, setSelectedProviderId] = useState<string | null>(null);
  const [language, setLanguage] = useState<'en' | 'bn'>('en');

  // Authentication & Auth Modal states
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'signin' | 'signup'>('signin');
  const [isAuthenticated, setIsAuthenticated] = useState(true);

  // Referral Program states
  const [referrals, setReferrals] = useState<ReferralRecord[]>(INITIAL_REFERRALS);
  const [creditTransactions, setCreditTransactions] = useState<CreditTransaction[]>(INITIAL_CREDIT_TRANSACTIONS);
  const [referralModalOpen, setReferralModalOpen] = useState(false);

  // New live meetup and masked voice call states
  const [activeLiveBookingId, setActiveLiveBookingId] = useState<string | null>(null);
  const [activeVoiceCallPartner, setActiveVoiceCallPartner] = useState<User | null>(null);

  // Firebase connection and authentication state
  const [firebaseConnected, setFirebaseConnected] = useState(false);

  useEffect(() => {
    testFirestoreConnection().then(connected => {
      setFirebaseConnected(connected);
    });

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const profile = await getUserProfileFromFirestore(fbUser.uid);
          if (profile) {
            setAllUsers(prev => {
              const exists = prev.some(u => u.id === profile.id);
              return exists ? prev.map(u => u.id === profile.id ? profile : u) : [profile, ...prev];
            });
            setCurrentUserId(profile.id);
            setIsAuthenticated(true);
          }
        } catch (e) {
          console.warn('[Firebase] Profile fetch warning:', e);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  const currentUser = allUsers.find(u => u.id === currentUserId) || allUsers[0];

  const userReferralCode = currentUser.referralCode || (currentUser.displayName.toUpperCase().replace(/[^A-Z0-9]/g, '') + '2026');
  const walletCredits = currentUser.walletCredits ?? 0;

  const signInWithGoogle = async (): Promise<{ success: boolean; error?: string }> => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      if (!fbUser) return { success: false, error: 'No user returned from Google sign-in' };

      // Check if user profile already exists
      let existingProfile = await getUserProfileFromFirestore(fbUser.uid).catch(() => null);
      if (!existingProfile) {
        existingProfile = allUsers.find(u => u.email.toLowerCase() === (fbUser.email || '').toLowerCase()) || null;
      }

      if (existingProfile) {
        setCurrentUserId(existingProfile.id);
        setIsAuthenticated(true);
        setAuthModalOpen(false);
        return { success: true };
      }

      // Create new user profile for Google user
      const googleUserName = fbUser.displayName || 'Google Member';
      const firstName = googleUserName.split(' ')[0] || 'Member';
      const refCode = (firstName.toUpperCase().replace(/[^A-Z0-9]/g, '') || 'GGL') + Math.floor(100 + Math.random() * 900);
      const isBootstrappedAdmin = fbUser.email === 'nurulamin.1990.bd@gmail.com';

      const newUser: User = {
        id: fbUser.uid,
        email: fbUser.email || '',
        fullName: googleUserName,
        displayName: firstName,
        avatar: fbUser.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
        phone: fbUser.phoneNumber || '',
        dateOfBirth: '1998-05-15',
        gender: 'female',
        city: 'Dhaka',
        area: 'Gulshan, Dhaka',
        languages: ['Bengali', 'English'],
        bio: 'Verified member joined via Google & Firebase.',
        interests: ['Coffee & Conversations', 'Cultural Walks', 'Fine Dining'],
        isPhoneVerified: !!fbUser.phoneNumber,
        isFaceVerified: false,
        verificationStatus: 'verified',
        isProviderActive: false,
        isAdmin: isBootstrappedAdmin,
        walletCredits: 300,
        referralCode: refCode,
        rating: 5.0,
        reviewCount: 0,
        joinedDate: new Date().toISOString()
      };

      await syncUserProfileToFirestore(newUser).catch(err => console.warn('Firestore sync user:', err));
      setAllUsers(prev => [newUser, ...prev]);
      setCurrentUserId(newUser.id);
      setIsAuthenticated(true);
      setAuthModalOpen(false);
      return { success: true };
    } catch (err: any) {
      console.error('Google Sign In failed:', err);
      return { success: false, error: err.message || 'Google sign-in was canceled or failed.' };
    }
  };

  const login = (emailOrPhone: string, password?: string) => {
    const cleanInput = emailOrPhone.trim().toLowerCase();
    const user = allUsers.find(u => 
      u.email.toLowerCase() === cleanInput || 
      u.phone.replace(/\s+/g, '') === cleanInput.replace(/\s+/g, '')
    );
    if (!user) {
      return { success: false, error: 'No account found with this email or phone number.' };
    }
    setCurrentUserId(user.id);
    setIsAuthenticated(true);
    if (user.isAdmin) {
      setActiveRole('admin');
      setActiveView('admin_dashboard');
    } else if (user.isProviderActive && activeRole === 'provider') {
      setActiveRole('provider');
      setActiveView('provider_dashboard');
    } else {
      setActiveRole('customer');
      setActiveView('customer_dashboard');
    }
    return { success: true };
  };

  const registerUser = (userData: Omit<User, 'id' | 'rating' | 'reviewCount' | 'joinedDate'>) => {
    // Check if email already exists
    if (allUsers.some(u => u.email.toLowerCase() === userData.email.toLowerCase())) {
      return { success: false, error: 'An account with this email address already exists.' };
    }
    const newUserId = `usr-${Date.now()}`;
    const generatedRefCode = (userData.displayName.toUpperCase().replace(/[^A-Z0-9]/g, '') || 'USER') + Math.floor(100 + Math.random() * 900);

    // Initial wallet credits: 300 if referred by someone, else 0 (or 500 if verified)
    const hasReferrer = Boolean(userData.referredByCode?.trim());
    const initialCredits = hasReferrer ? 300 : (userData.verificationStatus === 'verified' ? 200 : 0);

    const newUser: User = {
      ...userData,
      id: newUserId,
      rating: 5.0,
      reviewCount: 0,
      joinedDate: new Date().toISOString(),
      referralCode: generatedRefCode,
      walletCredits: initialCredits
    };

    setAllUsers(prev => [newUser, ...prev]);
    setCurrentUserId(newUser.id);
    setIsAuthenticated(true);

    // If referred by someone, link referral record and reward referrer if user is verified!
    if (hasReferrer) {
      const cleanRefCode = userData.referredByCode!.trim().toUpperCase();
      const referrerUser = allUsers.find(u => (u.referralCode || '').toUpperCase() === cleanRefCode);
      const isVerified = userData.verificationStatus === 'verified' || userData.isFaceVerified;

      const newRefRecord: ReferralRecord = {
        id: `ref-${Date.now()}`,
        referrerId: referrerUser ? referrerUser.id : 'usr-customer-demo',
        referredUserId: newUserId,
        friendName: userData.fullName,
        friendEmail: userData.email,
        friendPhone: userData.phone,
        referralCode: cleanRefCode,
        status: isVerified ? 'verified' : 'registered',
        rewardCredits: 500,
        invitedAt: new Date().toISOString(),
        registeredAt: new Date().toISOString(),
        verifiedAt: isVerified ? new Date().toISOString() : undefined,
        verificationMethod: userData.isFaceVerified ? 'face' : 'phone_otp'
      };

      setReferrals(prev => [newRefRecord, ...prev]);

      // If already verified during sign-up (e.g. completed face verification), credit the referrer immediately!
      if (isVerified && referrerUser) {
        setAllUsers(prevUsers => prevUsers.map(u => {
          if (u.id === referrerUser.id) {
            return {
              ...u,
              walletCredits: (u.walletCredits ?? 0) + 500
            };
          }
          return u;
        }));

        setCreditTransactions(prev => [
          {
            id: `ctx-${Date.now()}`,
            userId: referrerUser.id,
            amount: 500,
            type: 'referral_bonus',
            description: `Referral Bonus: ${userData.fullName} joined & verified profile`,
            descriptionBn: `রেফারেল বোনাস: ${userData.fullName} যোগ দিয়েছেন ও প্রোফাইল যাচাই করেছেন`,
            timestamp: new Date().toISOString(),
            balanceAfter: (referrerUser.walletCredits ?? 0) + 500,
            relatedReferralId: newRefRecord.id
          },
          ...prev
        ]);
      }

      // Add welcome bonus transaction for the new user
      if (initialCredits > 0) {
        setCreditTransactions(prev => [
          {
            id: `ctx-wb-${Date.now()}`,
            userId: newUserId,
            amount: initialCredits,
            type: 'welcome_bonus',
            description: 'Referral Welcome Bonus: Profile registered',
            descriptionBn: 'রেফারেল স্বাগতম বোনাস: প্রোফাইল নিবন্ধিত হয়েছে',
            timestamp: new Date().toISOString(),
            balanceAfter: initialCredits
          },
          ...prev
        ]);
      }
    }

    // Sync user profile to Firestore
    syncUserProfileToFirestore(newUser).catch(err => {
      console.warn('[Firebase] Register profile sync error:', err);
    });

    if (newUser.isProviderActive) {
      setActiveRole('provider');
      setActiveView('provider_dashboard');
    } else {
      setActiveRole('customer');
      setActiveView('customer_dashboard');
    }
    return { success: true, user: newUser };
  };

  const logout = () => {
    signOut(auth).catch(() => {});
    setIsAuthenticated(false);
    setCurrentUserId('usr-customer-demo');
    setActiveRole('customer');
    setActiveView('explore');
  };

  // Sync role view when switching user
  const switchUser = (userId: string) => {
    const user = allUsers.find(u => u.id === userId);
    if (!user) return;
    setCurrentUserId(userId);
    setIsAuthenticated(true);
    if (user.isAdmin) {
      setActiveRole('admin');
      setActiveView('admin_dashboard');
    } else if (user.isProviderActive && activeRole === 'provider') {
      setActiveRole('provider');
    } else {
      setActiveRole('customer');
    }
  };

  const toggleSaveProvider = (providerId: string) => {
    setSavedProviderIds(prev => 
      prev.includes(providerId) ? prev.filter(id => id !== providerId) : [...prev, providerId]
    );
  };

  const activateProviderStatus = () => {
    setAllUsers(prev => prev.map(u => {
      if (u.id === currentUser.id) {
        return { ...u, isProviderActive: true };
      }
      return u;
    }));
    setActiveRole('provider');
    setActiveView('provider_dashboard');
  };

  const startMeetup = (bookingId: string) => {
    const now = new Date().toISOString();
    setBookings(prev => prev.map(b => b.id === bookingId ? {
      ...b,
      status: 'in_progress',
      meetupState: 'active_live',
      meetupStartedAt: now,
      updatedAt: now
    } : b));
    setActiveLiveBookingId(bookingId);
  };

  const endMeetup = (bookingId: string) => {
    const now = new Date().toISOString();
    setBookings(prev => prev.map(b => b.id === bookingId ? {
      ...b,
      status: 'completed',
      meetupState: 'completed_safe',
      meetupEndedAt: now,
      updatedAt: now
    } : b));
    setActiveLiveBookingId(null);
  };

  const addTip = (bookingId: string, tipAmount: number) => {
    setBookings(prev => prev.map(b => {
      if (b.id === bookingId) {
        const currentTip = b.tipAmount || 0;
        return {
          ...b,
          tipAmount: currentTip + tipAmount,
          priceSnapshot: {
            ...b.priceSnapshot,
            providerEarnings: b.priceSnapshot.providerEarnings + tipAmount
          }
        };
      }
      return b;
    }));
  };

  const createBooking = ({
    providerId,
    serviceId,
    scheduledDate,
    scheduledTime,
    durationHours,
    meetupLocation,
    venueId,
    promoCode,
    discountAmount = 0,
    specialNotes
  }: {
    providerId: string;
    serviceId: string;
    scheduledDate: string;
    scheduledTime: string;
    durationHours: number;
    meetupLocation: string;
    venueId?: string;
    promoCode?: string;
    discountAmount?: number;
    specialNotes?: string;
  }): Booking => {
    const service = services.find(s => s.id === serviceId);
    const category = categories.find(c => c.id === service?.categoryId);

    const unitPrice = service ? service.price : 1000;
    const rawSubtotal = service?.pricingUnit === 'hourly' 
      ? unitPrice * durationHours 
      : unitPrice;
    
    const subtotal = Math.max(0, rawSubtotal - discountAmount);
    const feeRate = platformConfig.commissionRate;
    const platformFeeAmount = Math.round(subtotal * feeRate);
    const totalPayable = subtotal;
    const providerEarnings = subtotal - platformFeeAmount;

    const priceSnapshot: BookingPriceSnapshot = {
      serviceTitle: service?.title || 'Social Companionship',
      categoryName: category?.name || 'General Social Experience',
      unitPrice,
      pricingUnit: service?.pricingUnit || 'session',
      durationHours,
      subtotal,
      discountAmount,
      promoCode,
      platformFeeRate: feeRate,
      platformFeeAmount,
      totalPayable,
      providerEarnings,
      serviceBoundaries: service?.serviceBoundaries || ['Public spaces only', 'No physical intimacy'],
      cancellationPolicy: service?.cancellationPolicy || 'flexible_24h'
    };

    const newBooking: Booking = {
      id: `bk-${Date.now()}`,
      bookingCode: `RAD-${Math.floor(1000 + Math.random() * 9000)}`,
      customerId: currentUser.id,
      providerId,
      serviceId,
      priceSnapshot,
      scheduledDate,
      scheduledTime,
      durationHours,
      meetupLocation,
      venueId,
      specialNotes,
      status: 'pending_acceptance',
      paymentStatus: 'unpaid',
      consentAcknowledged: true,
      meetupState: 'scheduled',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setBookings(prev => [newBooking, ...prev]);

    // Send automated initiation message in conversation
    sendMessage(providerId, `Hi! I just requested a booking for ${priceSnapshot.serviceTitle} on ${scheduledDate} at ${scheduledTime} at ${meetupLocation}. Looking forward to your response!`, newBooking.bookingCode);

    return newBooking;
  };

  const updateBookingStatus = (bookingId: string, status: BookingStatus, reason?: string) => {
    setBookings(prev => prev.map(b => {
      if (b.id === bookingId) {
        return {
          ...b,
          status,
          declineReason: status === 'declined' ? reason : b.declineReason,
          cancellationReason: status === 'cancelled' ? reason : b.cancellationReason,
          updatedAt: new Date().toISOString()
        };
      }
      return b;
    }));
  };

  const processPayment = async (bookingId: string, method: PaymentMethod): Promise<boolean> => {
    // Simulate payment transaction with bKash / Nagad / SSLCOMMERZ
    const booking = bookings.find(b => b.id === bookingId);
    if (!booking) return false;

    const trxId = `DEMO-TRX-${method.toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`;

    const newTrx: PaymentTransaction = {
      id: `trx-${Date.now()}`,
      bookingId,
      bookingCode: booking.bookingCode,
      method,
      amount: booking.priceSnapshot.totalPayable,
      platformFee: booking.priceSnapshot.platformFeeAmount,
      netProviderAmount: booking.priceSnapshot.providerEarnings,
      status: 'success',
      gatewayTransactionId: trxId,
      isDemo: true,
      timestamp: new Date().toISOString()
    };

    setTransactions(prev => [newTrx, ...prev]);

    setBookings(prev => prev.map(b => {
      if (b.id === bookingId) {
        return {
          ...b,
          status: 'confirmed',
          paymentMethod: method,
          paymentStatus: 'paid',
          transactionReference: trxId,
          paidAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
      }
      return b;
    }));

    return true;
  };

  const addService = (serviceData: Omit<ProviderService, 'id' | 'providerId' | 'isActive'>) => {
    const newService: ProviderService = {
      ...serviceData,
      id: `srv-${Date.now()}`,
      providerId: currentUser.id,
      isActive: true
    };
    setServices(prev => [newService, ...prev]);
  };

  const updateService = (serviceId: string, updates: Partial<ProviderService>) => {
    setServices(prev => prev.map(s => s.id === serviceId ? { ...s, ...updates } : s));
  };

  const toggleServiceActive = (serviceId: string) => {
    setServices(prev => prev.map(s => s.id === serviceId ? { ...s, isActive: !s.isActive } : s));
  };

  const requestPayout = ({
    bookingId,
    bookingCode,
    grossAmount,
    commissionAmount,
    netAmount,
    payoutMethod,
    accountNumber
  }: {
    bookingId: string;
    bookingCode: string;
    grossAmount: number;
    commissionAmount: number;
    netAmount: number;
    payoutMethod: 'bkash' | 'nagad' | 'bank_transfer';
    accountNumber: string;
  }) => {
    const newPayout: PayoutRecord = {
      id: `pay-${Date.now()}`,
      providerId: currentUser.id,
      bookingId,
      bookingCode,
      grossAmount,
      platformCommission: commissionAmount,
      netPayoutAmount: netAmount,
      payoutMethod,
      accountNumber,
      status: 'processing',
      requestedAt: new Date().toISOString()
    };
    setPayouts(prev => [newPayout, ...prev]);
  };

  const submitVerification = (docType: 'nid' | 'passport' | 'driving_license') => {
    setAllUsers(prev => prev.map(u => {
      if (u.id === currentUser.id) {
        return {
          ...u,
          verificationStatus: 'pending',
          verificationDocumentType: docType,
          verificationSubmittedAt: new Date().toISOString()
        };
      }
      return u;
    }));
  };

  const adminApproveVerification = (userId: string) => {
    setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, verificationStatus: 'verified' } : u));
  };

  const adminRejectVerification = (userId: string) => {
    setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, verificationStatus: 'rejected' } : u));
  };

  const updateCommissionRate = (rate: number) => {
    setPlatformConfig(prev => ({ ...prev, commissionRate: rate }));
  };

  const toggleCategoryStatus = (categoryId: string) => {
    setCategories(prev => prev.map(c => c.id === categoryId ? { ...c, isActive: !c.isActive } : c));
  };

  const adminSuspendUser = (userId: string) => {
    setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, isProviderActive: false } : u));
  };

  const submitReport = ({ reportedUserId, bookingCode, reason, details }: { reportedUserId: string; bookingCode?: string; reason: string; details: string }) => {
    const newReport: SafetyReport = {
      id: `rep-${Date.now()}`,
      reportedByUserId: currentUser.id,
      reportedUserId,
      bookingCode,
      reason,
      details,
      status: 'open',
      createdAt: new Date().toISOString()
    };
    setSafetyReports(prev => [newReport, ...prev]);
  };

  const sendMessage = (recipientId: string, text: string, bookingRef?: string) => {
    // Find or create conversation
    let conv = conversations.find(c => 
      c.participantIds.includes(currentUser.id) && c.participantIds.includes(recipientId)
    );

    const now = new Date().toISOString();

    if (!conv) {
      conv = {
        id: `conv-${Date.now()}`,
        participantIds: [currentUser.id, recipientId],
        lastMessage: text,
        lastTimestamp: now,
        unreadCount: 0
      };
      setConversations(prev => [conv!, ...prev]);
    } else {
      setConversations(prev => prev.map(c => c.id === conv!.id ? {
        ...c,
        lastMessage: text,
        lastTimestamp: now
      } : c));
    }

    const newMsg: Message = {
      id: `msg-${Date.now()}`,
      conversationId: conv.id,
      senderId: currentUser.id,
      receiverId: recipientId,
      text,
      timestamp: now,
      bookingReference: bookingRef
    };

    setMessages(prev => [...prev, newMsg]);
  };

  const submitReview = (bookingId: string, rating: number, comment: string) => {
    const booking = bookings.find(b => b.id === bookingId);
    if (!booking) return;

    const newRev: Review = {
      id: `rev-${Date.now()}`,
      bookingId,
      customerId: currentUser.id,
      customerName: currentUser.displayName,
      customerAvatar: currentUser.avatar,
      providerId: booking.providerId,
      rating,
      comment,
      createdAt: new Date().toISOString()
    };

    setReviews(prev => [newRev, ...prev]);
  };

  // Referral Program helper methods
  const sendReferralInvite = (friendName: string, friendContact: string) => {
    const isEmail = friendContact.includes('@');
    const newRef: ReferralRecord = {
      id: `ref-${Date.now()}`,
      referrerId: currentUser.id,
      friendName: friendName.trim(),
      friendEmail: isEmail ? friendContact.trim() : undefined,
      friendPhone: !isEmail ? friendContact.trim() : undefined,
      referralCode: userReferralCode,
      status: 'invited',
      rewardCredits: 500,
      invitedAt: new Date().toISOString()
    };
    setReferrals(prev => [newRef, ...prev]);
    return { success: true, referral: newRef };
  };

  const verifyFriendAndCreditReferrer = (referralId: string, verificationMethod?: string) => {
    const targetRef = referrals.find(r => r.id === referralId);
    if (!targetRef || targetRef.status === 'verified') return;

    const reward = targetRef.rewardCredits || 500;
    const now = new Date().toISOString();

    // 1. Mark referral as verified
    setReferrals(prev => prev.map(r => r.id === referralId ? {
      ...r,
      status: 'verified',
      verifiedAt: now,
      verificationMethod: (verificationMethod as any) || 'face_and_nid'
    } : r));

    // 2. Add credits to the referrer
    const referrerId = targetRef.referrerId;
    let newReferrerBalance = 0;

    setAllUsers(prev => prev.map(u => {
      if (u.id === referrerId) {
        newReferrerBalance = (u.walletCredits ?? 0) + reward;
        return {
          ...u,
          walletCredits: newReferrerBalance
        };
      }
      return u;
    }));

    // 3. Record credit transaction for referrer
    const newTx: CreditTransaction = {
      id: `ctx-${Date.now()}`,
      userId: referrerId,
      amount: reward,
      type: 'referral_bonus',
      description: `Referral Bonus: ${targetRef.friendName} verified profile`,
      descriptionBn: `রেফারেল বোনাস: ${targetRef.friendName} প্রোফাইল ভেরিফিকেশন সম্পন্ন করেছেন`,
      timestamp: now,
      balanceAfter: newReferrerBalance || ((currentUser.walletCredits ?? 0) + reward),
      relatedReferralId: referralId
    };

    setCreditTransactions(prev => [newTx, ...prev]);

    // 4. If the referred friend exists in allUsers, make sure their status is verified and give them welcome credits
    if (targetRef.referredUserId) {
      setAllUsers(prev => prev.map(u => {
        if (u.id === targetRef.referredUserId) {
          return {
            ...u,
            verificationStatus: 'verified',
            isFaceVerified: true,
            walletCredits: (u.walletCredits ?? 0) + 300
          };
        }
        return u;
      }));
    }
  };

  const sendVerificationReminder = (referralId: string) => {
    setReferrals(prev => prev.map(r => r.id === referralId ? {
      ...r,
      reminderSentAt: new Date().toISOString()
    } : r));
  };

  const applyReferralCodeOnSignup = (code: string) => {
    const clean = code.trim().toUpperCase();
    const referrer = allUsers.find(u => (u.referralCode || '').toUpperCase() === clean);
    if (referrer) {
      return { valid: true, referrerName: referrer.displayName, bonusCredits: 300 };
    }
    return { valid: false };
  };

  const deductCreditsForBooking = (bookingId: string, amount: number) => {
    const currentBal = currentUser.walletCredits ?? 0;
    if (amount <= 0 || currentBal < amount) return false;

    const newBal = currentBal - amount;
    setAllUsers(prev => prev.map(u => u.id === currentUser.id ? { ...u, walletCredits: newBal } : u));

    const newTx: CreditTransaction = {
      id: `ctx-${Date.now()}`,
      userId: currentUser.id,
      amount: -amount,
      type: 'booking_discount',
      description: `Applied ৳${amount} referral credits to booking`,
      descriptionBn: `বুকিংয়ে ৳${amount} রেফারেল ক্রেডিট ব্যবহার করা হয়েছে`,
      timestamp: new Date().toISOString(),
      balanceAfter: newBal,
      relatedBookingId: bookingId
    };
    setCreditTransactions(prev => [newTx, ...prev]);
    return true;
  };

  const getReferralStats = () => {
    const userReferrals = referrals.filter(r => r.referrerId === currentUser.id);
    const verified = userReferrals.filter(r => r.status === 'verified');
    const pending = userReferrals.filter(r => r.status !== 'verified');
    const totalEarned = verified.reduce((sum, r) => sum + (r.rewardCredits || 500), 0);
    const pendingCredits = pending.length * 500;
    const availableBalance = currentUser.walletCredits ?? 0;

    return {
      totalEarned,
      availableBalance,
      pendingCredits,
      totalInvited: userReferrals.length,
      verifiedCount: verified.length,
      pendingCount: pending.length
    };
  };

  const notificationCount = bookings.filter(b => 
    (activeRole === 'provider' && b.providerId === currentUser.id && b.status === 'pending_acceptance') ||
    (activeRole === 'customer' && b.customerId === currentUser.id && b.status === 'accepted')
  ).length;

  return (
    <AppContext.Provider value={{
      currentUser,
      allUsers,
      categories,
      services,
      bookings,
      reviews,
      payouts,
      transactions,
      conversations,
      messages,
      safetyReports,
      platformConfig,
      referrals,
      creditTransactions,
      userReferralCode,
      walletCredits,
      referralModalOpen,
      setReferralModalOpen,
      sendReferralInvite,
      verifyFriendAndCreditReferrer,
      sendVerificationReminder,
      applyReferralCodeOnSignup,
      deductCreditsForBooking,
      getReferralStats,
      activeRole,
      activeView,
      selectedProviderId,
      savedProviderIds,
      language,
      notificationCount,
      isAuthenticated,
      authModalOpen,
      setAuthModalOpen,
      authModalMode,
      setAuthModalMode,
      login,
      registerUser,
      signInWithGoogle,
      logout,
      firebaseConnected,
      setActiveView,
      setSelectedProviderId,
      setActiveRole,
      switchUser,
      setLanguage,
      toggleSaveProvider,
      createBooking,
      updateBookingStatus,
      processPayment,
      startMeetup,
      endMeetup,
      addTip,
      activeLiveBookingId,
      setActiveLiveBookingId,
      activeVoiceCallPartner,
      setActiveVoiceCallPartner,
      addService,
      updateService,
      toggleServiceActive,
      requestPayout,
      submitVerification,
      adminApproveVerification,
      adminRejectVerification,
      updateCommissionRate,
      toggleCategoryStatus,
      adminSuspendUser,
      submitReport,
      sendMessage,
      submitReview,
      activateProviderStatus
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
