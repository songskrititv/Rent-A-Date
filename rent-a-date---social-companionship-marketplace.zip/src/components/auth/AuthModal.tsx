import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { Gender } from '../../types';
import { 
  X, 
  Lock, 
  Mail, 
  Phone, 
  User as UserIcon, 
  Calendar, 
  MapPin, 
  ShieldCheck, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  Eye, 
  EyeOff,
  Heart,
  Layers,
  ArrowRight,
  KeyRound,
  Check,
  ShieldAlert,
  Smartphone,
  Compass,
  Camera,
  CameraOff,
  ScanFace,
  Upload,
  RefreshCw,
  Clock,
  Send,
  CheckCircle,
  HelpCircle,
  Smile,
  BadgeCheck,
  Gift
} from 'lucide-react';

const PRESET_AVATARS = [
  { url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400', label: 'Zarin style' },
  { url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400', label: 'Rayhan style' },
  { url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=400', label: 'Samira style' },
  { url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=400', label: 'Farhan style' },
  { url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400', label: 'Nusrat style' },
  { url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=400', label: 'Casual style' }
];

const SAMPLE_VERIFIED_FACES = [
  { url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400', label: 'Female Portrait (Verified)' },
  { url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400', label: 'Male Portrait (Verified)' },
  { url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=400', label: 'Natural Portrait (Verified)' }
];

const DHAKA_AREAS = [
  'Gulshan 1',
  'Gulshan 2',
  'Banani',
  'Dhanmondi',
  'Uttara',
  'Bashundhara R/A',
  'Mohakhali DOHS',
  'Old Dhaka',
  'Mirpur',
  'Baridhara'
];

export const AuthModal: React.FC = () => {
  const { 
    authModalOpen, 
    setAuthModalOpen, 
    authModalMode, 
    setAuthModalMode,
    login,
    registerUser,
    signInWithGoogle,
    language
  } = useApp();

  const isBn = language === 'bn';

  // Sub-modes: signin | signup | forgot
  const [internalMode, setInternalMode] = useState<'signin' | 'signup' | 'forgot'>(authModalMode);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);

  // Sync internal mode when external prop changes
  useEffect(() => {
    setInternalMode(authModalMode);
  }, [authModalMode]);

  // Sign in form state
  const [signInIdentifier, setSignInIdentifier] = useState('');
  const [signInPassword, setSignInPassword] = useState('password123');
  const [showSignInPassword, setShowSignInPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [signInError, setSignInError] = useState<string | null>(null);

  // Forgot Password state
  const [forgotIdentifier, setForgotIdentifier] = useState('');
  const [forgotOtpSent, setForgotOtpSent] = useState(false);
  const [forgotOtpCode, setForgotOtpCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState(false);
  const [forgotError, setForgotError] = useState<string | null>(null);

  // Sign up form state
  const [accountGoal, setAccountGoal] = useState<'customer' | 'provider'>('customer');
  const [fullName, setFullName] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('+880 1712 345678');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [dob, setDob] = useState('1998-05-15');
  const [gender, setGender] = useState<Gender>('female');
  const [area, setArea] = useState('Dhanmondi');
  const [bio, setBio] = useState('');
  const [interestsInput, setInterestsInput] = useState('Coffee, Art, Fine Dining, Books');
  const [selectedAvatar, setSelectedAvatar] = useState(PRESET_AVATARS[0].url);
  const [customAvatarUrl, setCustomAvatarUrl] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [referralCodeInput, setReferralCodeInput] = useState(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      return params.get('ref') || '';
    } catch {
      return '';
    }
  });
  const [signUpError, setSignUpError] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // ===== PHONE OTP VERIFICATION STATE =====
  const [isPhoneVerified, setIsPhoneVerified] = useState(false);
  const [phoneOtpSent, setPhoneOtpSent] = useState(false);
  const [phoneOtpCode, setPhoneOtpCode] = useState('');
  const [phoneOtpInput, setPhoneOtpInput] = useState('');
  const [phoneOtpTimer, setPhoneOtpTimer] = useState(60);
  const [phoneOtpError, setPhoneOtpError] = useState<string | null>(null);
  const [simulatedSmsToast, setSimulatedSmsToast] = useState<string | null>(null);

  // ===== FACE VERIFICATION STATE =====
  const [showFaceVerificationSection, setShowFaceVerificationSection] = useState(false);
  const [faceVerificationMethod, setFaceVerificationMethod] = useState<'camera' | 'upload' | 'samples'>('camera');
  const [isFaceVerified, setIsFaceVerified] = useState(false);
  const [verifiedFacePhoto, setVerifiedFacePhoto] = useState<string | null>(null);
  const [isScanningFace, setIsScanningFace] = useState(false);
  const [scanStepMessage, setScanStepMessage] = useState('');
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [syncFaceAsAvatar, setSyncFaceAsAvatar] = useState(true);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Phone OTP Countdown Timer
  useEffect(() => {
    let interval: any = null;
    if (phoneOtpSent && phoneOtpTimer > 0) {
      interval = setInterval(() => {
        setPhoneOtpTimer(prev => prev - 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [phoneOtpSent, phoneOtpTimer]);

  // Cleanup camera stream on close / unmount
  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  useEffect(() => {
    return () => {
      stopCameraStream();
    };
  }, []);

  // Stop camera if modal closes or changes mode
  useEffect(() => {
    if (!authModalOpen || internalMode !== 'signup') {
      stopCameraStream();
    }
  }, [authModalOpen, internalMode]);

  if (!authModalOpen) return null;

  // ===== PHONE OTP HANDLERS =====
  const handleSendPhoneOtp = () => {
    setPhoneOtpError(null);
    const cleanedPhone = phone.replace(/[^0-9+]/g, '');
    if (cleanedPhone.length < 10) {
      setPhoneOtpError(isBn ? 'অনুগ্রহ করে সঠিক মোবাইল নম্বর লিখুন (ন্যূনতম ১০ সংখ্যা)।' : 'Please enter a valid mobile number with at least 10 digits.');
      return;
    }

    // Generate random 4-digit OTP code
    const generatedCode = Math.floor(1000 + Math.random() * 9000).toString();
    setPhoneOtpCode(generatedCode);
    setPhoneOtpSent(true);
    setPhoneOtpTimer(60);
    setPhoneOtpInput('');

    // Trigger realistic SMS notification banner
    setSimulatedSmsToast(`[SMS Simulation] আপনার রেন্ট আ ডেট ভেরিফিকেশন ওটিপি: ${generatedCode}`);
    setTimeout(() => {
      setSimulatedSmsToast(null);
    }, 9000);
  };

  const handleVerifyPhoneOtp = () => {
    setPhoneOtpError(null);
    if (!phoneOtpInput.trim()) {
      setPhoneOtpError(isBn ? 'ওটিপি কোড লিখুন।' : 'Please enter the OTP code.');
      return;
    }

    if (phoneOtpInput.trim() === phoneOtpCode) {
      setIsPhoneVerified(true);
      setPhoneOtpError(null);
      setSimulatedSmsToast(null);
    } else {
      setPhoneOtpError(isBn ? 'ওটিপি কোড সঠিক নয়। দয়া করে পুনরায় চেক করুন।' : 'Invalid OTP code. Please check and try again.');
    }
  };

  const handleAutoFillOtp = () => {
    if (phoneOtpCode) {
      setPhoneOtpInput(phoneOtpCode);
      setPhoneOtpError(null);
    }
  };

  const handleResetPhone = () => {
    setIsPhoneVerified(false);
    setPhoneOtpSent(false);
    setPhoneOtpCode('');
    setPhoneOtpInput('');
    setPhoneOtpError(null);
  };

  // ===== FACE VERIFICATION HANDLERS =====
  const handleStartCamera = async () => {
    setCameraError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Webcam API is not available on this browser');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user'
        },
        audio: false
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setCameraActive(true);
    } catch (err: any) {
      console.warn('Camera access denied or unavailable:', err);
      setCameraError(
        isBn 
          ? 'ক্যামেরা চালু করা সম্ভব হয়নি (অনুমতি দিন অথবা সেলফি ছবি আপলোড অপশন বেছে নিন)।' 
          : 'Could not access camera. Please allow permission or upload a selfie photo instead.'
      );
      setFaceVerificationMethod('upload');
    }
  };

  const handleCaptureFaceSnapshot = () => {
    if (!videoRef.current) return;
    setIsScanningFace(true);
    setScanStepMessage(isBn ? 'মুখমণ্ডল স্ক্যান করা হচ্ছে... লেন্সের দিকে তাকিয়ে থাকুন' : 'Scanning face... Looking directly at the lens');

    const video = videoRef.current;
    const canvas = canvasRef.current || document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');

    if (ctx) {
      // Mirror horizontally for natural front-camera selfie preview
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.88);

      setTimeout(() => {
        setScanStepMessage(isBn ? 'বায়োমেট্রিক কনট্যুর ও লাইভনেস যাচাই সম্পন্ন হচ্ছে...' : 'Verifying biometric contour & liveness...');
      }, 700);

      setTimeout(() => {
        setIsScanningFace(false);
        setIsFaceVerified(true);
        setVerifiedFacePhoto(dataUrl);
        if (syncFaceAsAvatar) {
          setCustomAvatarUrl(dataUrl);
        }
        stopCameraStream();
      }, 1500);
    } else {
      setIsScanningFace(false);
    }
  };

  const handleFileUploadFace = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsScanningFace(true);
    setScanStepMessage(isBn ? 'সেলফি ছবি বিশ্লেষণ ও বায়োমেট্রিক ভ্যালিডেশন হচ্ছে...' : 'Analyzing selfie and validating biometric features...');

    const reader = new FileReader();
    reader.onload = (event) => {
      const resultUrl = event.target?.result as string;
      setTimeout(() => {
        setIsScanningFace(false);
        setIsFaceVerified(true);
        setVerifiedFacePhoto(resultUrl);
        if (syncFaceAsAvatar) {
          setCustomAvatarUrl(resultUrl);
        }
      }, 1200);
    };
    reader.readAsDataURL(file);
  };

  const handleSelectSampleFace = (sampleUrl: string) => {
    setIsScanningFace(true);
    setScanStepMessage(isBn ? 'ডেমো সেলফি বায়োমেট্রিক ফ্রেম যাচাই হচ্ছে...' : 'Validating demo biometric selfie frame...');
    setTimeout(() => {
      setIsScanningFace(false);
      setIsFaceVerified(true);
      setVerifiedFacePhoto(sampleUrl);
      if (syncFaceAsAvatar) {
        setCustomAvatarUrl(sampleUrl);
      }
    }, 1000);
  };

  const handleRetakeFaceVerification = () => {
    setIsFaceVerified(false);
    setVerifiedFacePhoto(null);
    stopCameraStream();
  };

  // ===== SIGN IN & SIGN UP SUBMISSION =====
  const handleSignInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSignInError(null);
    if (!signInIdentifier.trim()) {
      setSignInError(isBn ? 'ইমেইল বা মোবাইল নম্বর দিন।' : 'Please enter your email or phone number.');
      return;
    }
    const result = login(signInIdentifier, signInPassword);
    if (result.success) {
      setSuccessToast(isBn ? 'সফলভাবে লগইন হয়েছে!' : 'Successfully signed in!');
      setTimeout(() => {
        setSuccessToast(null);
        setAuthModalOpen(false);
      }, 700);
    } else {
      setSignInError(result.error || (isBn ? 'লগইন তথ্য সঠিক নয়।' : 'Invalid credentials. Please verify your email or phone.'));
    }
  };

  const handleQuickDemoLogin = (emailPreset: string) => {
    setSignInError(null);
    const result = login(emailPreset);
    if (result.success) {
      setSuccessToast(isBn ? 'ডেমো অ্যাকাউন্টে লগইন হয়েছে!' : 'Signed in with demo persona!');
      setTimeout(() => {
        setSuccessToast(null);
        setAuthModalOpen(false);
      }, 500);
    }
  };

  const handleGoogleSignIn = async () => {
    setIsGoogleLoading(true);
    setSignInError(null);
    setSignUpError(null);
    const result = await signInWithGoogle();
    setIsGoogleLoading(false);
    if (!result.success && result.error) {
      if (internalMode === 'signin') {
        setSignInError(result.error);
      } else {
        setSignUpError(result.error);
      }
    }
  };

  const handleSignUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSignUpError(null);

    if (!fullName.trim()) {
      setSignUpError(isBn ? 'অনুগ্রহ করে আপনার পুরো নাম লিখুন।' : 'Please enter your full name.');
      return;
    }

    if (!email.trim() || !email.includes('@')) {
      setSignUpError(isBn ? 'অনুগ্রহ করে সঠিক ইমেইল ঠিকানা দিন।' : 'Please enter a valid email address.');
      return;
    }

    // Mobile Number OTP Verification Check
    if (!isPhoneVerified) {
      setSignUpError(
        isBn 
          ? 'অনুগ্রহ করে ওটিপি (OTP) কোড পাঠিয়ে মোবাইল নম্বরটি ভেরিফাই সম্পন্ন করুন।' 
          : 'Please verify your mobile number with OTP code before proceeding.'
      );
      // Auto-trigger send OTP if not sent yet
      if (!phoneOtpSent) {
        handleSendPhoneOtp();
      }
      return;
    }

    if (password.length < 6) {
      setSignUpError(isBn ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.');
      return;
    }

    if (confirmPassword && password !== confirmPassword) {
      setSignUpError(isBn ? 'পাসওয়ার্ড দুটি মিলছে না।' : 'Passwords do not match.');
      return;
    }

    // Validate 18+ age
    const birthYear = new Date(dob).getFullYear();
    const currentYear = new Date().getFullYear();
    if (currentYear - birthYear < 18) {
      setSignUpError(isBn ? 'নিবন্ধনের জন্য ন্যূনতম ১৮ বছর বয়স হতে হবে।' : 'You must be at least 18 years of age to register.');
      return;
    }

    if (!termsAccepted) {
      setSignUpError(isBn ? 'নিরাপত্তা নীতিমালা ও সেবার শর্তাবলীতে সম্মতি দিন।' : 'Please confirm agreement to safety policy and terms of service.');
      return;
    }

    const interestsList = interestsInput
      .split(',')
      .map(i => i.trim())
      .filter(i => i.length > 0);

    const finalAvatar = customAvatarUrl.trim() || (isFaceVerified && verifiedFacePhoto ? verifiedFacePhoto : selectedAvatar);

    const result = registerUser({
      fullName: fullName.trim(),
      displayName: displayName.trim() || fullName.trim().split(' ')[0],
      email: email.trim(),
      phone: phone.trim(),
      password,
      dateOfBirth: dob,
      gender,
      city: 'Dhaka',
      area,
      bio: bio.trim() || (isBn ? 'ঢাকায় রুচিশীল মানুষের সাথে কফি ও ইতিবাচক আড্ডা উপভোগ করি।' : 'Excited to discover thoughtful company and great conversations in Dhaka.'),
      languages: ['Bengali', 'English'],
      interests: interestsList.length > 0 ? interestsList : ['Coffee', 'Conversation', 'Dining'],
      avatar: finalAvatar,
      isProviderActive: accountGoal === 'provider',
      isAdmin: false,
      verificationStatus: isFaceVerified ? 'verified' : 'unverified',
      isPhoneVerified: true,
      isFaceVerified: isFaceVerified,
      faceVerificationPhoto: verifiedFacePhoto || undefined,
      faceVerifiedAt: isFaceVerified ? new Date().toISOString() : undefined,
      referredByCode: referralCodeInput.trim() || undefined
    });

    if (result.success) {
      setSuccessToast(
        isFaceVerified 
          ? (isBn ? 'অ্যাকাউন্ট তৈরি ও ফেস ভেরিফিকেশন সফল! ভেরিফাইড প্রোফাইলে স্বাগতম।' : 'Account created & Face Verified! Welcome to Rent a Date.')
          : (isBn ? 'অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে! স্বাগতম।' : 'Account created successfully! Welcome to Rent a Date.')
      );
      setTimeout(() => {
        setSuccessToast(null);
        setAuthModalOpen(false);
      }, 1000);
    } else {
      setSignUpError(result.error || (isBn ? 'অ্যাকাউন্ট তৈরি করতে সমস্যা হয়েছে।' : 'Failed to register account.'));
    }
  };

  const handleSendForgotOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);
    if (!forgotIdentifier.trim()) {
      setForgotError(isBn ? 'ইমেইল বা মোবাইল নম্বর দিন।' : 'Please enter your email or phone.');
      return;
    }
    setForgotOtpSent(true);
    setForgotOtpCode('8492'); // Simulated demo OTP
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      setForgotError(isBn ? 'নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.');
      return;
    }
    setForgotSuccess(true);
    setTimeout(() => {
      setInternalMode('signin');
      setSignInIdentifier(forgotIdentifier);
      setSignInPassword(newPassword);
      setForgotSuccess(false);
      setForgotOtpSent(false);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-xl rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[94vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="bg-gradient-to-r from-[#FAF7F5] via-[#F6EDE9] to-[#FAF7F5] border-b border-stone-200/90 p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#721C38] to-[#4A0E22] flex items-center justify-center text-rose-100 shadow-sm">
              <Heart className="w-5 h-5 fill-rose-300/30 text-rose-200" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-stone-900 flex items-center gap-2">
                <span>{isBn ? 'রেন্ট আ ডেট বাংলাদেশ' : 'Rent a Date Bangladesh'}</span>
                <span className="text-[10px] font-sans font-semibold bg-rose-100 text-[#721C38] px-2 py-0.5 rounded-full">
                  {isBn ? 'নিরাপদ প্ল্যাটফর্ম' : 'Verified'}
                </span>
              </h2>
              <p className="text-xs text-stone-500">
                {isBn ? 'অভিজাত ও বিশ্বাসযোগ্য সামাজিক সাহচর্যের নেটওয়ার্ক' : 'Trusted Social Companionship Network'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              stopCameraStream();
              setAuthModalOpen(false);
            }}
            className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Global Toast Banner for SMS or Feedback */}
        {simulatedSmsToast && (
          <div className="bg-amber-500 text-stone-950 px-4 py-2.5 text-xs font-medium flex items-center justify-between border-b border-amber-600 animate-in slide-in-from-top">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 shrink-0" />
              <span>{simulatedSmsToast}</span>
            </div>
            <button
              type="button"
              onClick={handleAutoFillOtp}
              className="px-2 py-0.5 bg-stone-950 text-amber-300 text-[11px] font-bold rounded hover:bg-stone-800 transition-colors cursor-pointer"
            >
              {isBn ? 'স্বয়ংক্রিয় পূরণ' : 'Auto-fill'}
            </button>
          </div>
        )}

        {/* Success Toast */}
        {successToast && (
          <div className="bg-emerald-600 text-white px-4 py-3 text-xs font-bold flex items-center gap-2 justify-center animate-in fade-in">
            <CheckCircle2 className="w-4 h-4" />
            <span>{successToast}</span>
          </div>
        )}

        {/* Modal Navigation Tabs */}
        <div className="flex border-b border-stone-200 bg-stone-50/70 p-1.5 gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => {
              setInternalMode('signin');
              setSignUpError(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              internalMode === 'signin'
                ? 'bg-white text-[#721C38] shadow-xs border border-stone-200/80'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100/60'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>{isBn ? 'লগইন (Sign In)' : 'Sign In'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setInternalMode('signup');
              setSignInError(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              internalMode === 'signup'
                ? 'bg-white text-[#721C38] shadow-xs border border-stone-200/80'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100/60'
            }`}
          >
            <UserIcon className="w-3.5 h-3.5" />
            <span>{isBn ? 'নতুন অ্যাকাউন্ট (Sign Up)' : 'Sign Up'}</span>
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 flex-1">

          {/* ==================== SIGN IN TAB ==================== */}
          {internalMode === 'signin' && (
            <div className="space-y-5">
              {signInError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{signInError}</span>
                </div>
              )}

              {/* Demo Accounts Quick Fill Helper */}
              <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-stone-700 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    {isBn ? 'দ্রুত টেস্ট লগইন (১-ক্লিক ডেমো)' : '1-Click Quick Demo Sign In'}
                  </span>
                  <span className="text-[10px] text-stone-500">{isBn ? 'টেস্টের জন্য প্রস্তুত' : 'Ready to test'}</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleQuickDemoLogin('khalid.mahfuz@example.com')}
                    className="p-2 text-left bg-white hover:bg-rose-50/50 border border-stone-200 rounded-xl transition-colors cursor-pointer group"
                  >
                    <div className="text-xs font-semibold text-stone-900 group-hover:text-[#721C38]">
                      খালিদ মাহফুজ (ক্লায়েন্ট)
                    </div>
                    <div className="text-[10px] text-stone-500">khalid.mahfuz@example.com</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickDemoLogin('zarin.subah@example.com')}
                    className="p-2 text-left bg-white hover:bg-rose-50/50 border border-stone-200 rounded-xl transition-colors cursor-pointer group"
                  >
                    <div className="text-xs font-semibold text-stone-900 group-hover:text-[#721C38] flex items-center gap-1">
                      <span>জারিন সুবাহ (কম্প্যানিয়ন)</span>
                      <ShieldCheck className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-[10px] text-stone-500">zarin.subah@example.com</div>
                  </button>
                </div>
              </div>

              {/* Google Sign In with Firebase */}
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={isGoogleLoading}
                  className="w-full py-2.5 px-4 bg-white hover:bg-stone-50 active:scale-[0.99] text-stone-800 text-xs font-bold rounded-xl border border-stone-300 shadow-2xs transition-all flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50"
                >
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>
                    {isGoogleLoading
                      ? (isBn ? 'গুগল সংযোগ হচ্ছে...' : 'Connecting with Google...')
                      : (isBn ? 'গুগল দিয়ে সাইন ইন করুন (Firebase)' : 'Continue with Google')}
                  </span>
                </button>
                <div className="relative my-2 text-center">
                  <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-stone-200"></div></div>
                  <span className="relative bg-white px-2 text-[10px] uppercase tracking-wider font-semibold text-stone-400">
                    {isBn ? 'অথবা ইমেইল দিয়ে লগইন' : 'or continue with email'}
                  </span>
                </div>
              </div>

              <form onSubmit={handleSignInSubmit} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-stone-700 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-[#721C38]" />
                    {isBn ? 'ইমেইল অথবা মোবাইল নম্বর' : 'Email or Mobile Number'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder={isBn ? 'যেমন: user@example.com অথবা ০১৭...' : 'e.g. user@example.com or +88017...'}
                    value={signInIdentifier}
                    onChange={(e) => setSignInIdentifier(e.target.value)}
                    className="w-full text-xs p-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                  />
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-stone-700 flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-[#721C38]" />
                      {isBn ? 'পাসওয়ার্ড' : 'Password'}
                    </label>
                    <button
                      type="button"
                      onClick={() => setInternalMode('forgot')}
                      className="text-[11px] text-[#721C38] hover:underline cursor-pointer"
                    >
                      {isBn ? 'পাসওয়ার্ড ভুলে গেছেন?' : 'Forgot Password?'}
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showSignInPassword ? 'text' : 'password'}
                      required
                      placeholder="••••••••"
                      value={signInPassword}
                      onChange={(e) => setSignInPassword(e.target.value)}
                      className="w-full text-xs p-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38] pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowSignInPassword(!showSignInPassword)}
                      className="absolute right-3 top-3 text-stone-400 hover:text-stone-600"
                    >
                      {showSignInPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-stone-600">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="rounded border-stone-300 text-[#721C38] focus:ring-[#721C38] w-4 h-4 accent-[#721C38]"
                    />
                    <span>{isBn ? 'মনে রাখুন' : 'Remember me'}</span>
                  </label>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-bold rounded-xl transition-all shadow-sm hover:shadow-md cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>{isBn ? 'সাইন ইন করুন' : 'Sign In to Account'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              <div className="text-center pt-2 border-t border-stone-100">
                <span className="text-xs text-stone-500">
                  {isBn ? 'অ্যাকাউন্ট নেই?' : "Don't have an account?"}{' '}
                </span>
                <button
                  type="button"
                  onClick={() => setInternalMode('signup')}
                  className="text-xs font-bold text-[#721C38] hover:underline cursor-pointer"
                >
                  {isBn ? 'নতুন অ্যাকাউন্ট খুলুন' : 'Create Free Account'}
                </button>
              </div>
            </div>
          )}

          {/* ==================== FORGOT PASSWORD TAB ==================== */}
          {internalMode === 'forgot' && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <h3 className="font-serif text-base font-bold text-stone-900">
                  {isBn ? 'পাসওয়ার্ড পুনরুদ্ধার' : 'Reset Account Password'}
                </h3>
                <p className="text-xs text-stone-500">
                  {isBn ? 'আপনার নিবন্ধিত ইমেইল বা মোবাইল নম্বর দিন। একটি ওটিপি কোড পাঠানো হবে।' : 'Enter your registered email or phone number to receive a verification OTP.'}
                </p>
              </div>

              {forgotError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{forgotError}</span>
                </div>
              )}

              {forgotSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{isBn ? 'পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে! রিডাইরেক্ট করা হচ্ছে...' : 'Password reset successfully! Redirecting to sign in...'}</span>
                </div>
              )}

              {!forgotOtpSent ? (
                <form onSubmit={handleSendForgotOtp} className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-stone-700">
                      {isBn ? 'ইমেইল বা মোবাইল নম্বর' : 'Email or Phone Number'}
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. khalid.mahfuz@example.com"
                      value={forgotIdentifier}
                      onChange={(e) => setForgotIdentifier(e.target.value)}
                      className="w-full text-xs p-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-3 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-bold rounded-xl transition-all cursor-pointer"
                  >
                    {isBn ? 'ওটিপি কোড পাঠান' : 'Send Verification OTP'}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleResetPassword} className="space-y-3">
                  <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-center justify-between">
                    <span>{isBn ? 'পরীক্ষামূলক ওটিপি কোড:' : 'Demo Test OTP:'} <strong>8492</strong></span>
                    <span className="text-[10px] text-amber-700">{isBn ? 'স্বয়ংক্রিয় যুক্ত' : 'Auto-filled'}</span>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-stone-700">
                      {isBn ? '৪-সংখ্যার ওটিপি কোড' : '4-Digit OTP Code'}
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={4}
                      value={forgotOtpCode}
                      onChange={(e) => setForgotOtpCode(e.target.value)}
                      className="w-full text-xs p-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38] text-center tracking-widest font-mono text-base font-bold"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-stone-700">
                      {isBn ? 'নতুন পাসওয়ার্ড' : 'Enter New Password'}
                    </label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      placeholder="••••••••"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full text-xs p-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-bold rounded-xl transition-all cursor-pointer"
                  >
                    {isBn ? 'পাসওয়ার্ড পরিবর্তন করুন' : 'Confirm & Update Password'}
                  </button>
                </form>
              )}

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => setInternalMode('signin')}
                  className="text-xs text-stone-600 hover:text-stone-900 underline cursor-pointer"
                >
                  {isBn ? 'লগইনে ফিরে যান' : 'Back to Sign In'}
                </button>
              </div>
            </div>
          )}

          {/* ==================== SIGN UP TAB ==================== */}
          {internalMode === 'signup' && (
            <form onSubmit={handleSignUpSubmit} className="space-y-5">
              {signUpError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{signUpError}</span>
                </div>
              )}

              {/* 1-Tap Google Sign Up */}
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={isGoogleLoading}
                  className="w-full py-2.5 px-4 bg-white hover:bg-stone-50 active:scale-[0.99] text-stone-800 text-xs font-bold rounded-xl border border-stone-300 shadow-2xs transition-all flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50"
                >
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>
                    {isGoogleLoading
                      ? (isBn ? 'গুগল সংযোগ হচ্ছে...' : 'Connecting with Google...')
                      : (isBn ? 'গুগল দিয়ে দ্রুত সাইন আপ করুন (Firebase)' : '1-Tap Sign Up with Google')}
                  </span>
                </button>
                <div className="relative my-2 text-center">
                  <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-stone-200"></div></div>
                  <span className="relative bg-white px-2 text-[10px] uppercase tracking-wider font-semibold text-stone-400">
                    {isBn ? 'অথবা মোবাইল ও মুখমণ্ডল ভেরিফিকেশন দিয়ে সাইন আপ' : 'or sign up manually with OTP & Face Verification'}
                  </span>
                </div>
              </div>

              {/* Account Purpose Toggle */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 flex items-center justify-between">
                  <span>{isBn ? 'অ্যাকাউন্টের ধরন নির্বাচন করুন' : 'Select Account Purpose'}</span>
                  <span className="text-[10px] text-stone-500 font-normal">{isBn ? 'পরে পরিবর্তনযোগ্য' : 'Can switch later'}</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setAccountGoal('customer')}
                    className={`p-3 text-left rounded-2xl border transition-all cursor-pointer flex flex-col gap-1 ${
                      accountGoal === 'customer'
                        ? 'border-[#721C38] bg-rose-50/70 text-[#721C38] shadow-xs ring-1 ring-[#721C38]'
                        : 'border-stone-200 bg-white text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs flex items-center gap-1.5 text-stone-900">
                        <UserIcon className="w-3.5 h-3.5 text-[#721C38]" />
                        {isBn ? 'সঙ্গী বুক করুন (ক্লায়েন্ট)' : 'Client Account'}
                      </span>
                      {accountGoal === 'customer' && <Check className="w-4 h-4 text-[#721C38]" />}
                    </div>
                    <span className="text-[10px] text-stone-500">
                      {isBn ? 'কফি, ডিনার ও সামাজিক ইভেন্টের জন্য বিশ্বস্ত সঙ্গী খুঁজুন' : 'Book verified companions for dining, events, and cafe talks'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setAccountGoal('provider')}
                    className={`p-3 text-left rounded-2xl border transition-all cursor-pointer flex flex-col gap-1 ${
                      accountGoal === 'provider'
                        ? 'border-[#721C38] bg-rose-50/70 text-[#721C38] shadow-xs ring-1 ring-[#721C38]'
                        : 'border-stone-200 bg-white text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs flex items-center gap-1.5 text-stone-900">
                        <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                        {isBn ? 'সার্ভিস প্রদানকারী (কম্প্যানিয়ন)' : 'Companion Provider'}
                      </span>
                      {accountGoal === 'provider' && <Check className="w-4 h-4 text-[#721C38]" />}
                    </div>
                    <span className="text-[10px] text-stone-500">
                      {isBn ? 'ঘণ্টাপ্রতি রেট নির্ধারণ করে সামাজিক সাহচর্যে আয় করুন' : 'List services, set rates in BDT, and earn safely in Dhaka'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Full Name & Display Name */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-stone-700">
                    {isBn ? 'পুরো নাম *' : 'Full Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder={isBn ? 'যেমন: নুসরাত জাহান' : 'e.g. Nusrat Jahan'}
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-stone-700">
                    {isBn ? 'প্রোফাইল নাম / ডাকনাম' : 'Display Name / Nickname'}
                  </label>
                  <input
                    type="text"
                    placeholder={isBn ? 'যেমন: নুসরাত' : 'e.g. Nusrat'}
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                  />
                </div>
              </div>

              {/* Email */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-stone-700 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-[#721C38]" />
                  {isBn ? 'ইমেইল ঠিকানা *' : 'Email Address *'}
                </label>
                <input
                  type="email"
                  required
                  placeholder="nusrat@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                />
              </div>

              {/* ========================================================================= */}
              {/* MOBILE NUMBER & OTP VERIFICATION SECTION */}
              {/* ========================================================================= */}
              <div className="p-3.5 bg-gradient-to-br from-stone-50 to-rose-50/30 rounded-2xl border border-stone-200/90 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-[#721C38]" />
                    <span>{isBn ? 'মোবাইল নম্বর ও ওটিপি ভেরিফিকেশন *' : 'Mobile Number & OTP Verification *'}</span>
                  </label>
                  {isPhoneVerified ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                      <CheckCircle className="w-3 h-3 text-emerald-600" />
                      <span>{isBn ? 'ওটিপি ভেরিফাইড ✓' : 'OTP Verified ✓'}</span>
                    </span>
                  ) : (
                    <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200 font-medium">
                      {isBn ? 'ওটিপি যাচাই আবশ্যক' : 'OTP Verification Required'}
                    </span>
                  )}
                </div>

                {/* Phone Input Row */}
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <input
                      type="tel"
                      disabled={isPhoneVerified}
                      required
                      placeholder="+880 1712 345678"
                      value={phone}
                      onChange={(e) => {
                        setPhone(e.target.value);
                        if (isPhoneVerified) setIsPhoneVerified(false);
                      }}
                      className={`w-full text-xs p-2.5 bg-white border rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38] font-mono ${
                        isPhoneVerified ? 'border-emerald-300 bg-emerald-50/40 text-emerald-900 font-semibold' : 'border-stone-200'
                      }`}
                    />
                    {isPhoneVerified && (
                      <span className="absolute right-3 top-2.5 text-emerald-600">
                        <Check className="w-4 h-4" />
                      </span>
                    )}
                  </div>

                  {!isPhoneVerified ? (
                    <button
                      type="button"
                      onClick={handleSendPhoneOtp}
                      disabled={phoneOtpSent && phoneOtpTimer > 0}
                      className={`px-3 py-2 text-xs font-bold rounded-xl transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                        phoneOtpSent && phoneOtpTimer > 0
                          ? 'bg-stone-200 text-stone-500 cursor-not-allowed'
                          : 'bg-[#721C38] hover:bg-[#58152B] text-white shadow-xs'
                      }`}
                    >
                      <Send className="w-3 h-3" />
                      <span>
                        {phoneOtpSent 
                          ? (phoneOtpTimer > 0 ? `${phoneOtpTimer}s` : (isBn ? 'পুনরায় পাঠান' : 'Resend'))
                          : (isBn ? 'ওটিপি পাঠান' : 'Send OTP')}
                      </span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleResetPhone}
                      className="px-3 py-2 text-xs font-medium text-stone-600 hover:text-stone-900 bg-white border border-stone-200 rounded-xl hover:bg-stone-100 transition-colors shrink-0 cursor-pointer"
                    >
                      {isBn ? 'নম্বর পরিবর্তন' : 'Change'}
                    </button>
                  )}
                </div>

                {/* OTP Input and Verification Box */}
                {!isPhoneVerified && phoneOtpSent && (
                  <div className="p-3 bg-white rounded-xl border border-stone-200 space-y-2.5 animate-in fade-in">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-stone-600 font-medium">
                        {isBn ? '৪-সংখ্যার কোডটি প্রবেশ করান:' : 'Enter 4-digit code sent via SMS:'}
                      </span>
                      <button
                        type="button"
                        onClick={handleAutoFillOtp}
                        className="text-[11px] text-[#721C38] hover:underline font-semibold cursor-pointer"
                      >
                        {isBn ? 'কোড টেস্ট অটো-ফিল' : 'Auto-fill test code'}
                      </button>
                    </div>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        maxLength={4}
                        placeholder="••••"
                        value={phoneOtpInput}
                        onChange={(e) => setPhoneOtpInput(e.target.value.replace(/[^0-9]/g, ''))}
                        className="flex-1 text-center font-mono text-base font-bold tracking-widest p-2 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                      />
                      <button
                        type="button"
                        onClick={handleVerifyPhoneOtp}
                        className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{isBn ? 'যাচাই করুন' : 'Verify'}</span>
                      </button>
                    </div>

                    {phoneOtpError && (
                      <p className="text-[11px] text-rose-600 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3 shrink-0" />
                        <span>{phoneOtpError}</span>
                      </p>
                    )}

                    <div className="text-[11px] text-stone-500 flex items-center justify-between">
                      <span>{isBn ? 'সিমুলেশন কোড:' : 'Demo Code:'} <strong className="font-mono text-stone-800">{phoneOtpCode}</strong></span>
                      {phoneOtpTimer > 0 && (
                        <span className="text-stone-400">
                          {isBn ? `পুনরায় পাঠাতে বাকি: ${phoneOtpTimer} সেকেন্ড` : `Resend in ${phoneOtpTimer}s`}
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Password & Confirm */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-stone-700 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-[#721C38]" />
                      {isBn ? 'পাসওয়ার্ড *' : 'Password *'}
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-[11px] text-stone-400 hover:text-stone-700"
                    >
                      {showPassword ? (isBn ? 'লুকান' : 'Hide') : (isBn ? 'দেখান' : 'Show')}
                    </button>
                  </label>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    placeholder="At least 6 characters"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-stone-700">
                    {isBn ? 'পাসওয়ার্ড নিশ্চিত করুন *' : 'Confirm Password *'}
                  </label>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    placeholder="Repeat password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                  />
                </div>
              </div>

              {/* DOB, Gender & Area */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-stone-700">
                    {isBn ? 'জন্ম তারিখ (১৮+)' : 'Date of Birth (18+)'}
                  </label>
                  <input
                    type="date"
                    required
                    max="2008-01-01"
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-stone-700">
                    {isBn ? 'লিঙ্গ' : 'Gender'}
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as Gender)}
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                  >
                    <option value="female">{isBn ? 'নারী (Female)' : 'Female'}</option>
                    <option value="male">{isBn ? 'পুরুষ (Male)' : 'Male'}</option>
                    <option value="other">{isBn ? 'অন্যান্য (Other)' : 'Other'}</option>
                    <option value="prefer_not_to_say">{isBn ? 'অপ্রকাশিত' : 'Prefer not to say'}</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-stone-700">
                    {isBn ? 'ঢাকার এলাকা' : 'Dhaka Area'}
                  </label>
                  <select
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                  >
                    {DHAKA_AREAS.map(a => (
                      <option key={a} value={a}>{a}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Bio & Interests */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-stone-700">
                  {isBn ? 'সংক্ষিপ্ত বায়ো / পরিচয়' : 'Short Bio / About You'}
                </label>
                <textarea
                  rows={2}
                  placeholder={isBn ? 'আপনার ব্যক্তিত্ব, পছন্দ ও সামাজিক চিন্তাধারা সম্পর্কে লিখুন...' : 'Share a few words about your personality, background, or social interests...'}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-stone-700">
                  {isBn ? 'আগ্রহের ক্ষেত্র (কমা দিয়ে লিখুন)' : 'Interests (Comma separated)'}
                </label>
                <input
                  type="text"
                  placeholder={isBn ? 'যেমন: কফি, ফাইন ডাইনিং, বই, শিল্পকলা' : 'e.g. Fine Dining, Art Galleries, Jazz, Heritage Walks'}
                  value={interestsInput}
                  onChange={(e) => setInterestsInput(e.target.value)}
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                />
              </div>

              {/* ========================================================================= */}
              {/* BIOMETRIC FACE VERIFICATION OPTION */}
              {/* ========================================================================= */}
              <div className="p-4 bg-gradient-to-br from-stone-50 via-rose-50/20 to-amber-50/20 rounded-2xl border border-stone-200/90 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-[#721C38] text-white flex items-center justify-center shrink-0">
                      <ScanFace className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-stone-900 flex items-center gap-1.5">
                        <span>{isBn ? 'বায়োমেট্রিক ফেস ভেরিফিকেশন' : 'Biometric Face Verification'}</span>
                        <span className="text-[10px] font-normal text-rose-800 bg-rose-100/70 px-1.5 py-0.2 rounded font-mono">
                          {isBn ? 'ঐচ্ছিক · ট্রাস্ট ব্যাজ' : 'Optional · Trust Badge'}
                        </span>
                      </h4>
                      <p className="text-[10px] text-stone-500">
                        {isBn ? 'সেলফি ভেরিফাই করলে প্রোফাইলে অফিসিয়াল ভেরিফাইড ব্যাজ পাবেন।' : 'Get official Verified Profile Badge by verifying your real selfie.'}
                      </p>
                    </div>
                  </div>

                  {isFaceVerified ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{isBn ? 'ফেস ভেরিফাইড ✓' : 'Face Verified ✓'}</span>
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setShowFaceVerificationSection(!showFaceVerificationSection)}
                      className="px-3 py-1.5 text-xs font-semibold text-[#721C38] bg-white hover:bg-rose-50 border border-[#721C38]/30 rounded-xl transition-all cursor-pointer shrink-0"
                    >
                      {showFaceVerificationSection 
                        ? (isBn ? 'প্যানেল লুকান' : 'Collapse') 
                        : (isBn ? 'এখনই ভেরিফাই করুন' : 'Verify Now')}
                    </button>
                  )}
                </div>

                {/* If Face is Verified: Show the Verified Badge & Preview */}
                {isFaceVerified && verifiedFacePhoto && (
                  <div className="p-3 bg-white rounded-xl border border-emerald-200 shadow-2xs flex items-center justify-between gap-3 animate-in fade-in">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img
                          src={verifiedFacePhoto}
                          alt="Verified Face"
                          className="w-12 h-12 rounded-full object-cover border-2 border-emerald-500 shadow-xs"
                        />
                        <span className="absolute -bottom-1 -right-1 bg-emerald-600 text-white rounded-full p-0.5 border border-white">
                          <Check className="w-2.5 h-2.5" />
                        </span>
                      </div>
                      <div className="space-y-0.5">
                        <div className="text-xs font-bold text-stone-900 flex items-center gap-1">
                          <span>{isBn ? 'বায়োমেট্রিক ফেস ভেরিফিকেশন সফল' : 'Face Verification Verified'}</span>
                          <BadgeCheck className="w-4 h-4 text-emerald-600" />
                        </div>
                        <p className="text-[10px] text-emerald-700 font-medium">
                          {isBn ? 'আপনার প্রোফাইল স্বয়ংক্রিয়ভাবে "ভেরিফাইড" হিসেবে তালিকাভুক্ত হবে।' : 'Your profile is officially marked as Verified Companion/User.'}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleRetakeFaceVerification}
                      className="px-2.5 py-1 text-[11px] text-stone-600 hover:text-stone-900 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-lg transition-colors cursor-pointer shrink-0"
                    >
                      {isBn ? 'পুনরায় ছবি তুলুন' : 'Retake'}
                    </button>
                  </div>
                )}

                {/* Face Verification Interactive Panel */}
                {!isFaceVerified && showFaceVerificationSection && (
                  <div className="p-3.5 bg-white rounded-2xl border border-stone-200 space-y-3 animate-in fade-in">
                    {/* Method Tabs */}
                    <div className="flex border-b border-stone-100 pb-2 gap-2 text-xs">
                      <button
                        type="button"
                        onClick={() => {
                          setFaceVerificationMethod('camera');
                          setCameraError(null);
                        }}
                        className={`flex-1 py-1.5 px-2 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                          faceVerificationMethod === 'camera'
                            ? 'bg-[#721C38] text-white shadow-2xs'
                            : 'bg-stone-50 text-stone-600 hover:bg-stone-100'
                        }`}
                      >
                        <Camera className="w-3.5 h-3.5" />
                        <span>{isBn ? 'ওয়েবক্যাম / ক্যামেরা' : 'Live Camera'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          stopCameraStream();
                          setFaceVerificationMethod('upload');
                        }}
                        className={`flex-1 py-1.5 px-2 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                          faceVerificationMethod === 'upload'
                            ? 'bg-[#721C38] text-white shadow-2xs'
                            : 'bg-stone-50 text-stone-600 hover:bg-stone-100'
                        }`}
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>{isBn ? 'সেলফি ছবি আপলোড' : 'Upload Selfie'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          stopCameraStream();
                          setFaceVerificationMethod('samples');
                        }}
                        className={`flex-1 py-1.5 px-2 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                          faceVerificationMethod === 'samples'
                            ? 'bg-[#721C38] text-white shadow-2xs'
                            : 'bg-stone-50 text-stone-600 hover:bg-stone-100'
                        }`}
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>{isBn ? 'ডেমো নমুনা' : 'Demo Samples'}</span>
                      </button>
                    </div>

                    {/* METHOD 1: LIVE WEBCAM CAMERA */}
                    {faceVerificationMethod === 'camera' && (
                      <div className="space-y-3">
                        <div className="relative aspect-video max-w-sm mx-auto bg-stone-900 rounded-2xl overflow-hidden border border-stone-800 flex items-center justify-center text-white">
                          <video
                            ref={videoRef}
                            playsInline
                            muted
                            autoPlay
                            className={`w-full h-full object-cover transform -scale-x-100 ${!cameraActive ? 'hidden' : ''}`}
                          />
                          <canvas ref={canvasRef} className="hidden" />

                          {/* Oval Face Guide Overlay */}
                          {cameraActive && (
                            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                              <div className="w-44 h-56 rounded-[50%] border-2 border-dashed border-rose-300/80 shadow-[0_0_20px_rgba(244,63,94,0.3)] animate-pulse flex items-center justify-center">
                                <span className="text-[10px] text-white/90 bg-stone-950/70 px-2 py-0.5 rounded-full mt-40">
                                  {isBn ? 'মুখমণ্ডল ফ্রেমের মাঝে রাখুন' : 'Center face inside frame'}
                                </span>
                              </div>
                            </div>
                          )}

                          {/* Scanning Indicator Animation */}
                          {isScanningFace && (
                            <div className="absolute inset-0 bg-stone-950/70 backdrop-blur-xs flex flex-col items-center justify-center text-center p-4 z-20 space-y-2">
                              <div className="w-10 h-10 border-3 border-rose-500 border-t-transparent rounded-full animate-spin"></div>
                              <p className="text-xs font-bold text-rose-200 animate-pulse">{scanStepMessage}</p>
                              <p className="text-[10px] text-stone-400">{isBn ? 'অনুগ্রহ করে কয়েক সেকেন্ড অপেক্ষা করুন...' : 'Please hold still for a moment...'}</p>
                            </div>
                          )}

                          {/* Inactive Camera Placeholder */}
                          {!cameraActive && (
                            <div className="text-center p-6 space-y-2">
                              <div className="w-12 h-12 rounded-2xl bg-stone-800 flex items-center justify-center mx-auto text-rose-400">
                                <Camera className="w-6 h-6" />
                              </div>
                              <p className="text-xs font-semibold text-stone-200">
                                {isBn ? 'ক্যামেরা চালু করে লাইভ সেলফি যাচাই করুন' : 'Start camera for live biometric selfie scan'}
                              </p>
                              <p className="text-[10px] text-stone-400 max-w-xs mx-auto">
                                {isBn ? 'আপনার ব্রাউজার থেকে ক্যামেরার অনুমতি দিন। কোনো ছবি সংরক্ষণ ছাড়াই এনক্রিপ্ট হবে।' : 'Browser will request webcam permission. Fast, private and secure.'}
                              </p>
                            </div>
                          )}
                        </div>

                        {cameraError && (
                          <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
                            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                            <span>{cameraError}</span>
                          </div>
                        )}

                        {/* Camera Action Buttons */}
                        <div className="flex items-center justify-center gap-2">
                          {!cameraActive ? (
                            <button
                              type="button"
                              onClick={handleStartCamera}
                              className="px-4 py-2 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
                            >
                              <Camera className="w-3.5 h-3.5" />
                              <span>{isBn ? 'ক্যামেরা চালু করুন' : 'Open Camera'}</span>
                            </button>
                          ) : (
                            <>
                              <button
                                type="button"
                                onClick={handleCaptureFaceSnapshot}
                                disabled={isScanningFace}
                                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer flex items-center gap-2 animate-pulse"
                              >
                                <ScanFace className="w-4 h-4" />
                                <span>{isBn ? 'সেলফি তুলুন ও যাচাই করুন' : 'Capture & Verify Face'}</span>
                              </button>
                              <button
                                type="button"
                                onClick={stopCameraStream}
                                className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-medium rounded-xl transition-colors cursor-pointer"
                              >
                                {isBn ? 'বন্ধ করুন' : 'Stop'}
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    )}

                    {/* METHOD 2: UPLOAD SELFIE FILE */}
                    {faceVerificationMethod === 'upload' && (
                      <div className="space-y-3">
                        <div className="border-2 border-dashed border-stone-200 rounded-2xl p-6 text-center hover:border-[#721C38] transition-colors cursor-pointer bg-stone-50/50">
                          <label className="cursor-pointer space-y-2 block">
                            <div className="w-10 h-10 rounded-full bg-rose-50 text-[#721C38] flex items-center justify-center mx-auto">
                              <Upload className="w-5 h-5" />
                            </div>
                            <div className="text-xs font-bold text-stone-800">
                              {isBn ? 'আপনার ডিভাইসের স্পষ্ট সেলফি নির্বাচন করুন' : 'Select a clear frontal selfie from your device'}
                            </div>
                            <p className="text-[10px] text-stone-500">
                              {isBn ? 'জেপিজি বা পিএনজি ফরম্যাট (সর্বোচ্চ ৫ মেগাবাইট)' : 'JPG, PNG formats up to 5MB'}
                            </p>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleFileUploadFace}
                              className="hidden"
                            />
                            <span className="inline-block px-3 py-1.5 bg-white border border-stone-200 text-xs font-semibold text-stone-700 rounded-xl shadow-2xs hover:bg-stone-100 transition-colors">
                              {isBn ? 'ফাইল ব্রাউজ করুন' : 'Browse File'}
                            </span>
                          </label>
                        </div>

                        {isScanningFace && (
                          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-center space-y-1">
                            <p className="text-xs font-bold text-[#721C38]">{scanStepMessage}</p>
                          </div>
                        )}
                      </div>
                    )}

                    {/* METHOD 3: DEMO SAMPLE FACES */}
                    {faceVerificationMethod === 'samples' && (
                      <div className="space-y-2">
                        <p className="text-[11px] text-stone-600">
                          {isBn ? 'টেস্টিংয়ের সুবিধার্থে নিচের যেকোনো একটি ভেরিফাইড পোর্ট্রেট নির্বাচন করুন:' : 'Select any verified portrait sample below to test immediately:'}
                        </p>
                        <div className="grid grid-cols-3 gap-2.5">
                          {SAMPLE_VERIFIED_FACES.map((sample, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => handleSelectSampleFace(sample.url)}
                              className="group p-2 rounded-xl border border-stone-200 hover:border-[#721C38] bg-stone-50 hover:bg-rose-50/30 transition-all text-center flex flex-col items-center gap-1.5 cursor-pointer"
                            >
                              <img
                                src={sample.url}
                                alt={sample.label}
                                className="w-14 h-14 rounded-full object-cover border border-stone-300 group-hover:scale-105 transition-transform"
                              />
                              <span className="text-[10px] font-medium text-stone-700 group-hover:text-[#721C38] leading-tight">
                                {sample.label}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Sync Face as Profile Avatar Checkbox */}
                    <label className="flex items-center gap-2 pt-1 text-[11px] text-stone-600 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={syncFaceAsAvatar}
                        onChange={(e) => setSyncFaceAsAvatar(e.target.checked)}
                        className="rounded border-stone-300 text-[#721C38] focus:ring-[#721C38] w-3.5 h-3.5 accent-[#721C38]"
                      />
                      <span>{isBn ? 'এই ভেরিফাইড ছবিটিকেই প্রোফাইলের মূল ছবি হিসেবে ব্যবহার করুন' : 'Use this verified face as primary profile avatar'}</span>
                    </label>
                  </div>
                )}
              </div>

              {/* Profile Photo Selector (If not already face verified) */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-stone-700 flex items-center justify-between">
                  <span>{isBn ? 'প্রোফাইল অবতার নির্বাচন করুন' : 'Choose Profile Avatar'}</span>
                  {isFaceVerified && (
                    <span className="text-[10px] text-emerald-700 font-semibold">
                      {isBn ? 'ফেস ভেরিফাইড ছবি নির্বাচিত' : 'Face Verified Photo Selected'}
                    </span>
                  )}
                </label>
                <div className="flex items-center gap-3 overflow-x-auto pb-1">
                  {PRESET_AVATARS.map((av, idx) => (
                    <img
                      key={idx}
                      src={av.url}
                      alt={av.label}
                      onClick={() => {
                        setSelectedAvatar(av.url);
                        setCustomAvatarUrl('');
                      }}
                      className={`w-11 h-11 rounded-full object-cover cursor-pointer border-2 transition-all shrink-0 ${
                        selectedAvatar === av.url && !customAvatarUrl
                          ? 'border-[#721C38] scale-105 shadow-sm ring-2 ring-[#721C38]/20'
                          : 'border-stone-200 opacity-70 hover:opacity-100'
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Referral Code (Optional) */}
              <div className="p-3 bg-rose-50/40 rounded-2xl border border-rose-200/60 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                    <Gift className="w-3.5 h-3.5 text-[#721C38]" />
                    <span>{isBn ? 'রেফারেল কোড (ঐচ্ছিক)' : 'Referral Code (Optional)'}</span>
                  </label>
                  <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    {isBn ? '+৳৩০০ স্বাগতম বোনাস' : '+৳300 Welcome Bonus'}
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    placeholder={isBn ? 'যেমন: KHALID2026' : 'e.g. KHALID2026'}
                    value={referralCodeInput}
                    onChange={(e) => setReferralCodeInput(e.target.value.toUpperCase())}
                    className="w-full text-xs p-2.5 bg-white border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38] font-mono tracking-wider uppercase font-semibold"
                  />
                  {referralCodeInput.trim() && (
                    <span className="absolute right-3 top-2.5 text-emerald-600 flex items-center gap-1 text-[11px] font-bold">
                      <Check className="w-3.5 h-3.5" />
                      <span>{isBn ? 'কোড যুক্ত' : 'Applied'}</span>
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-stone-500">
                  {isBn 
                    ? 'বন্ধুর রেফারেল কোড থাকলে প্রোফাইল ও ফেস ভেরিফিকেশনের পর আপনি ৳৩০০ ক্রেডিট বোনাস পাবেন।'
                    : 'Enter a friend\'s referral code to receive ৳300 welcome credits once you verify your profile.'}
                </p>
              </div>

              {/* Mandatory Policy Consent */}
              <label className="flex items-start gap-2.5 p-3 bg-stone-50 rounded-xl border border-stone-200 cursor-pointer hover:bg-stone-100/60 transition-colors">
                <input
                  type="checkbox"
                  required
                  checked={termsAccepted}
                  onChange={(e) => setTermsAccepted(e.target.checked)}
                  className="mt-0.5 rounded border-stone-300 text-[#721C38] focus:ring-[#721C38] w-4 h-4 accent-[#721C38]"
                />
                <span className="text-[11px] text-stone-700 leading-tight">
                  {isBn ? (
                    <>আমি নিশ্চিত করছি যে আমার বয়স ন্যূনতম <strong>১৮ বছর</strong>। আমি রেন্ট আ ডেট-এর সেবার শর্তাবলী ও আচরণবিধি মেনে চলব এবং স্বীকার করছি যে এই প্ল্যাটফর্মটি কেবলমাত্র প্রকাশ্য স্থানে <strong>অ-যৌন সামাজিক সাহচর্যের</strong> জন্য অনুমোদিত।</>
                  ) : (
                    <>I confirm that I am at least <strong>18 years old</strong>. I accept the Terms of Service and acknowledge that Rent a Date is exclusively for consensual <strong>non-sexual social companionship</strong> in public venues.</>
                  )}
                </span>
              </label>

              <button
                type="submit"
                className="w-full py-3.5 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-bold rounded-xl transition-all shadow-sm hover:shadow-md cursor-pointer flex items-center justify-center gap-2"
              >
                <span>{isBn ? 'রেজিস্ট্রেশন সম্পন্ন করুন' : 'Complete Registration & Open Dashboard'}</span>
                <CheckCircle2 className="w-4 h-4" />
              </button>
            </form>
          )}

        </div>
      </div>
    </div>
  );
};
