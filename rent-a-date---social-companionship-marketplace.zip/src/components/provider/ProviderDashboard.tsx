import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ProviderService, PricingUnit, CancellationPolicy } from '../../types';
import { formatBDT, formatDate, formatTime } from '../../utils/formatters';
import { 
  Layers, 
  Plus, 
  DollarSign, 
  Clock, 
  ShieldCheck, 
  Calendar, 
  Check, 
  X, 
  FileText, 
  AlertCircle, 
  TrendingUp, 
  ArrowUpRight,
  Sparkles,
  Smartphone,
  Eye,
  EyeOff,
  Edit2
} from 'lucide-react';

export const ProviderDashboard: React.FC<{
  onOpenMessages: (recipientId?: string) => void;
}> = ({ onOpenMessages }) => {
  const { 
    currentUser, 
    services, 
    categories, 
    bookings, 
    payouts, 
    addService, 
    updateService, 
    toggleServiceActive, 
    updateBookingStatus, 
    requestPayout,
    submitVerification,
    allUsers,
    platformConfig
  } = useApp();

  const [activeTab, setActiveTab] = useState<'services' | 'requests' | 'earnings' | 'verification'>('services');

  // Service form state (for Add / Edit modal)
  const [isServiceModalOpen, setIsServiceModalOpen] = useState(false);
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);

  const [formCategoryId, setFormCategoryId] = useState(categories[0]?.id || 'cat-1');
  const [formTitle, setFormTitle] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formPrice, setFormPrice] = useState(1500);
  const [formPricingUnit, setFormPricingUnit] = useState<PricingUnit>('session');
  const [formDurationHours, setFormDurationHours] = useState(2);
  const [formLocation, setFormLocation] = useState('Gulshan & Banani public venues');
  const [formAdvanceNotice, setFormAdvanceNotice] = useState(24);
  const [formCancellationPolicy, setFormCancellationPolicy] = useState<CancellationPolicy>('moderate_48h');
  const [formBoundaries, setFormBoundaries] = useState<string>('Public venue only\nNo private home visits\nNo physical intimacy');

  // Payout request modal state
  const [isPayoutModalOpen, setIsPayoutModalOpen] = useState(false);
  const [payoutMethod, setPayoutMethod] = useState<'bkash' | 'nagad' | 'bank_transfer'>('bkash');
  const [payoutAccount, setPayoutAccount] = useState('01712345678');
  const [selectedBookingForPayout, setSelectedBookingForPayout] = useState<string>('');

  // Verification document submit state
  const [docType, setDocType] = useState<'nid' | 'passport' | 'driving_license'>('nid');

  // Filter services and bookings for this provider
  const myServices = services.filter(s => s.providerId === currentUser.id);
  const myBookings = bookings.filter(b => b.providerId === currentUser.id);
  const myPayouts = payouts.filter(p => p.providerId === currentUser.id);

  const pendingRequests = myBookings.filter(b => b.status === 'pending_acceptance');
  const activeBookings = myBookings.filter(b => b.status === 'confirmed' || b.status === 'in_progress');
  const completedBookings = myBookings.filter(b => b.status === 'completed');

  // Calculate earnings
  const grossEarnings = completedBookings.reduce((sum, b) => sum + b.priceSnapshot.subtotal, 0);
  const platformCommissionDeducted = completedBookings.reduce((sum, b) => sum + b.priceSnapshot.platformFeeAmount, 0);
  const netEarnings = grossEarnings - platformCommissionDeducted;

  const eligibleForPayoutBookings = completedBookings.filter(b => 
    !myPayouts.some(p => p.bookingId === b.id && (p.status === 'paid' || p.status === 'processing'))
  );

  const openAddServiceModal = () => {
    setEditingServiceId(null);
    setFormCategoryId(categories[0]?.id || 'cat-1');
    setFormTitle('');
    setFormDescription('');
    setFormPrice(1500);
    setFormPricingUnit('session');
    setFormDurationHours(2);
    setFormLocation(`${currentUser.area} public spots`);
    setFormBoundaries('Public cafes and restaurants only\nZero physical intimacy\nAdvance reservations only');
    setIsServiceModalOpen(true);
  };

  const openEditServiceModal = (service: ProviderService) => {
    setEditingServiceId(service.id);
    setFormCategoryId(service.categoryId);
    setFormTitle(service.title);
    setFormDescription(service.description);
    setFormPrice(service.price);
    setFormPricingUnit(service.pricingUnit);
    setFormDurationHours(service.durationHours);
    setFormLocation(service.generalLocation);
    setFormBoundaries(service.serviceBoundaries.join('\n'));
    setIsServiceModalOpen(true);
  };

  const handleSaveService = (e: React.FormEvent) => {
    e.preventDefault();
    const boundariesArray = formBoundaries
      .split('\n')
      .map(s => s.trim())
      .filter(s => s.length > 0);

    if (editingServiceId) {
      updateService(editingServiceId, {
        categoryId: formCategoryId,
        title: formTitle,
        description: formDescription,
        price: Number(formPrice),
        pricingUnit: formPricingUnit,
        durationHours: Number(formDurationHours),
        generalLocation: formLocation,
        serviceBoundaries: boundariesArray
      });
    } else {
      addService({
        categoryId: formCategoryId,
        title: formTitle,
        description: formDescription,
        price: Number(formPrice),
        currency: 'BDT',
        pricingUnit: formPricingUnit,
        durationHours: Number(formDurationHours),
        availableDurations: [formDurationHours, formDurationHours * 2],
        generalLocation: formLocation,
        advanceNoticeHours: formAdvanceNotice,
        cancellationPolicy: formCancellationPolicy,
        serviceBoundaries: boundariesArray,
        maxParticipants: 1
      });
    }

    setIsServiceModalOpen(false);
  };

  const handleAcceptRequest = (bookingId: string) => {
    updateBookingStatus(bookingId, 'confirmed');
  };

  const handleDeclineRequest = (bookingId: string) => {
    const reason = prompt('State reason for declining request (polite note to client):');
    if (reason) {
      updateBookingStatus(bookingId, 'declined', reason);
    }
  };

  const handleMarkCompleted = (bookingId: string) => {
    updateBookingStatus(bookingId, 'completed');
  };

  const handleRequestPayoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const targetBooking = eligibleForPayoutBookings.find(b => b.id === selectedBookingForPayout) || eligibleForPayoutBookings[0];
    if (!targetBooking) {
      alert('No eligible booking selected for payout.');
      return;
    }

    requestPayout({
      bookingId: targetBooking.id,
      bookingCode: targetBooking.bookingCode,
      grossAmount: targetBooking.priceSnapshot.subtotal,
      commissionAmount: targetBooking.priceSnapshot.platformFeeAmount,
      netAmount: targetBooking.priceSnapshot.providerEarnings,
      payoutMethod,
      accountNumber: payoutAccount
    });

    setIsPayoutModalOpen(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Header bar */}
      <div className="bg-white rounded-3xl border border-stone-200/90 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <img
            src={currentUser.avatar}
            alt={currentUser.displayName}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-rose-100 shadow-xs"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-serif text-2xl font-bold text-stone-900">{currentUser.displayName}</h1>
              <span className="text-[11px] font-semibold bg-rose-50 text-[#721C38] border border-rose-200 px-2 py-0.5 rounded-md">
                Companion Workspace
              </span>
              {currentUser.verificationStatus === 'verified' && (
                <span className="text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  Verified
                </span>
              )}
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              Base: {currentUser.area}, Dhaka · Rating: {currentUser.rating.toFixed(2)} ({currentUser.reviewCount} reviews)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={openAddServiceModal}
            className="px-4 py-2 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Service Listing</span>
          </button>
        </div>
      </div>

      {/* Workspace Tabs */}
      <div className="flex border-b border-stone-200 gap-6 text-sm font-semibold">
        <button
          onClick={() => setActiveTab('services')}
          className={`pb-3 transition-colors ${
            activeTab === 'services'
              ? 'text-[#721C38] border-b-2 border-[#721C38]'
              : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          My Services ({myServices.length})
        </button>
        <button
          onClick={() => setActiveTab('requests')}
          className={`pb-3 transition-colors flex items-center gap-2 ${
            activeTab === 'requests'
              ? 'text-[#721C38] border-b-2 border-[#721C38]'
              : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <span>Booking Requests</span>
          {pendingRequests.length > 0 && (
            <span className="w-5 h-5 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center">
              {pendingRequests.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('earnings')}
          className={`pb-3 transition-colors ${
            activeTab === 'earnings'
              ? 'text-[#721C38] border-b-2 border-[#721C38]'
              : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          Earnings & Payouts
        </button>
        <button
          onClick={() => setActiveTab('verification')}
          className={`pb-3 transition-colors ${
            activeTab === 'verification'
              ? 'text-[#721C38] border-b-2 border-[#721C38]'
              : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          Identity Verification
        </button>
      </div>

      {/* TAB 1: MY SERVICES */}
      {activeTab === 'services' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-serif font-bold text-lg text-stone-900">Manage Published Services</h3>
              <p className="text-xs text-stone-500">
                You can offer multiple services with distinct rates, durations, and boundaries.
              </p>
            </div>
          </div>

          {myServices.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-3xl border border-stone-200 p-8 space-y-3">
              <Layers className="w-12 h-12 text-stone-300 mx-auto" />
              <h4 className="font-serif font-bold text-stone-800">No Services Published Yet</h4>
              <p className="text-xs text-stone-500 max-w-sm mx-auto">
                Create your first social experience (Coffee meetup, gallery tour, dinner date, or cultural companion).
              </p>
              <button
                onClick={openAddServiceModal}
                className="px-4 py-2 bg-[#721C38] text-white text-xs font-semibold rounded-xl"
              >
                Add Your First Service
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {myServices.map(service => {
                const category = categories.find(c => c.id === service.categoryId);
                return (
                  <div
                    key={service.id}
                    className="bg-white rounded-2xl border border-stone-200/90 p-5 shadow-xs flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] uppercase font-semibold text-[#721C38] block">
                            {category?.name || 'Category'}
                          </span>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {service.title}
                          </h4>
                        </div>
                        <div className="text-right">
                          <span className="text-base font-bold text-stone-900 block">
                            {formatBDT(service.price)}
                          </span>
                          <span className="text-[10px] text-stone-500">
                            /{service.pricingUnit === 'hourly' ? 'hour' : 'session'}
                          </span>
                        </div>
                      </div>

                      <p className="text-xs text-stone-600 line-clamp-2">
                        {service.description}
                      </p>

                      <div className="bg-stone-50 p-2.5 rounded-xl border border-stone-100 text-[11px] text-stone-600 space-y-1">
                        <div className="font-semibold text-stone-700">Service Boundaries:</div>
                        {service.serviceBoundaries.map((b, i) => (
                          <div key={i} className="text-stone-500 truncate">✓ {b}</div>
                        ))}
                      </div>
                    </div>

                    <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
                      <button
                        onClick={() => toggleServiceActive(service.id)}
                        className="flex items-center gap-1.5 text-stone-600 hover:text-stone-900"
                      >
                        {service.isActive ? (
                          <>
                            <Eye className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Active in Search</span>
                          </>
                        ) : (
                          <>
                            <EyeOff className="w-3.5 h-3.5 text-stone-400" />
                            <span>Paused (Hidden)</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => openEditServiceModal(service)}
                        className="flex items-center gap-1 text-[#721C38] font-semibold hover:underline"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Edit Pricing & Terms</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: BOOKING REQUESTS */}
      {activeTab === 'requests' && (
        <div className="space-y-6">
          {/* Pending Inquiries */}
          <div className="space-y-3">
            <h3 className="font-serif font-bold text-base text-stone-900">
              Pending Client Requests ({pendingRequests.length})
            </h3>

            {pendingRequests.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-2xl border border-stone-200 text-xs text-stone-500">
                No pending requests. Check back when clients book your services!
              </div>
            ) : (
              <div className="space-y-3">
                {pendingRequests.map(booking => {
                  const customer = allUsers.find(u => u.id === booking.customerId);
                  return (
                    <div
                      key={booking.id}
                      className="bg-white rounded-2xl border-2 border-amber-200 p-5 shadow-xs space-y-3"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <img src={customer?.avatar} alt={customer?.displayName} className="w-12 h-12 rounded-xl object-cover" />
                          <div>
                            <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded">
                              NEEDS YOUR ACCEPTANCE
                            </span>
                            <h4 className="font-serif font-bold text-base text-stone-900 mt-1">
                              {booking.priceSnapshot.serviceTitle} with {customer?.displayName}
                            </h4>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-base font-bold text-[#721C38] block">
                            Net Earnings: {formatBDT(booking.priceSnapshot.providerEarnings)}
                          </span>
                          <span className="text-[10px] text-stone-400">
                            Total {formatBDT(booking.priceSnapshot.totalPayable)} (after 20% commission)
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs bg-stone-50 p-3 rounded-xl">
                        <div><strong>Date:</strong> {formatDate(booking.scheduledDate)} at {formatTime(booking.scheduledTime)}</div>
                        <div><strong>Venue:</strong> {booking.meetupLocation}</div>
                        {booking.specialNotes && (
                          <div className="col-span-2 text-stone-600">
                            <strong>Client Note:</strong> "{booking.specialNotes}"
                          </div>
                        )}
                      </div>

                      <div className="flex items-center justify-end gap-3 pt-2">
                        <button
                          onClick={() => handleDeclineRequest(booking.id)}
                          className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-rose-600"
                        >
                          Decline Request
                        </button>
                        <button
                          onClick={() => handleAcceptRequest(booking.id)}
                          className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shadow-xs"
                        >
                          <Check className="w-4 h-4" />
                          <span>Accept & Confirm Meetup</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Confirmed & Completed Bookings */}
          <div className="space-y-3 pt-6 border-t border-stone-200">
            <h3 className="font-serif font-bold text-base text-stone-900">
              Active & Upcoming Bookings ({activeBookings.length})
            </h3>
            {activeBookings.length === 0 ? (
              <p className="text-xs text-stone-400">No active bookings right now.</p>
            ) : (
              <div className="space-y-3">
                {activeBookings.map(b => {
                  const customer = allUsers.find(u => u.id === b.customerId);
                  return (
                    <div key={b.id} className="bg-white rounded-2xl border border-stone-200 p-4 flex items-center justify-between">
                      <div>
                        <div className="text-xs font-semibold text-stone-900">{b.priceSnapshot.serviceTitle} with {customer?.displayName}</div>
                        <div className="text-[11px] text-stone-500">{formatDate(b.scheduledDate)} at {formatTime(b.scheduledTime)} · {b.meetupLocation}</div>
                      </div>
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => onOpenMessages(b.customerId)}
                          className="text-xs text-stone-700 hover:underline"
                        >
                          Chat
                        </button>
                        <button
                          onClick={() => handleMarkCompleted(b.id)}
                          className="px-3 py-1.5 bg-[#721C38] text-white text-xs font-semibold rounded-lg hover:bg-[#58152B]"
                        >
                          Mark Completed
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: EARNINGS & PAYOUTS */}
      {activeTab === 'earnings' && (
        <div className="space-y-6">
          {/* Earnings summary KPI cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs">
              <span className="text-[10px] font-semibold text-stone-400 uppercase tracking-wider block">Gross Bookings</span>
              <div className="text-2xl font-bold text-stone-900 mt-1">{formatBDT(grossEarnings)}</div>
              <span className="text-[11px] text-stone-500">From {completedBookings.length} completed experiences</span>
            </div>

            <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs">
              <span className="text-[10px] font-semibold text-stone-400 uppercase tracking-wider block">Platform Commission ({Math.round(platformConfig.commissionRate * 100)}%)</span>
              <div className="text-2xl font-bold text-rose-800 mt-1">-{formatBDT(platformCommissionDeducted)}</div>
              <span className="text-[11px] text-stone-500">Safety & operations deduction</span>
            </div>

            <div className="bg-white rounded-2xl border border-emerald-200 bg-emerald-50/20 p-5 shadow-xs">
              <span className="text-[10px] font-semibold text-emerald-800 uppercase tracking-wider block">Net Provider Earnings</span>
              <div className="text-2xl font-bold text-emerald-900 mt-1">{formatBDT(netEarnings)}</div>
              <button
                onClick={() => setIsPayoutModalOpen(true)}
                disabled={eligibleForPayoutBookings.length === 0}
                className="mt-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 px-3 py-1.5 rounded-lg inline-flex items-center gap-1 disabled:opacity-50"
              >
                <span>Request Mobile Wallet Payout</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Payout records ledger */}
          <div className="bg-white rounded-2xl border border-stone-200 p-6 space-y-4">
            <h3 className="font-serif font-bold text-base text-stone-900">Disbursement & Payout History</h3>

            {myPayouts.length === 0 ? (
              <p className="text-xs text-stone-500">No payout records yet.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-stone-200 text-stone-400 uppercase font-semibold text-[10px]">
                    <tr>
                      <th className="py-2.5">Booking Ref</th>
                      <th>Gross (৳)</th>
                      <th>Platform Cut</th>
                      <th>Net Payout (৳)</th>
                      <th>Method</th>
                      <th>Account</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 text-stone-700">
                    {myPayouts.map(p => (
                      <tr key={p.id}>
                        <td className="py-3 font-semibold text-stone-900">{p.bookingCode}</td>
                        <td>{formatBDT(p.grossAmount)}</td>
                        <td className="text-rose-700">-{formatBDT(p.platformCommission)}</td>
                        <td className="font-bold text-emerald-700">{formatBDT(p.netPayoutAmount)}</td>
                        <td className="uppercase font-semibold">{p.payoutMethod}</td>
                        <td>{p.accountNumber}</td>
                        <td>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            p.status === 'paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {p.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: IDENTITY VERIFICATION */}
      {activeTab === 'verification' && (
        <div className="bg-white rounded-2xl border border-stone-200 p-6 space-y-6 max-w-2xl">
          <div>
            <h3 className="font-serif font-bold text-lg text-stone-900">National ID & Trust Verification</h3>
            <p className="text-xs text-stone-500 mt-1">
              To protect both companions and clients, verified badges are granted after checking government-issued credentials.
            </p>
          </div>

          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-stone-500">Current Status:</span>
              <span className={`font-bold uppercase text-[11px] px-2 py-0.5 rounded ${
                currentUser.verificationStatus === 'verified' ? 'bg-emerald-100 text-emerald-800' :
                currentUser.verificationStatus === 'pending' ? 'bg-amber-100 text-amber-800' :
                'bg-stone-200 text-stone-700'
              }`}>
                {currentUser.verificationStatus}
              </span>
            </div>
            {currentUser.verificationSubmittedAt && (
              <div className="text-[11px] text-stone-400">
                Submitted on: {formatDate(currentUser.verificationSubmittedAt)}
              </div>
            )}
          </div>

          {currentUser.verificationStatus !== 'verified' && (
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-stone-700">Document Type</label>
                <select
                  value={docType}
                  onChange={(e) => setDocType(e.target.value as any)}
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                >
                  <option value="nid">Bangladesh National ID Card (Smart NID)</option>
                  <option value="passport">Bangladesh Passport</option>
                  <option value="driving_license">BRTA Driving License</option>
                </select>
              </div>

              <div className="border-2 border-dashed border-stone-200 rounded-2xl p-6 text-center space-y-2 bg-stone-50/50">
                <FileText className="w-8 h-8 text-stone-400 mx-auto" />
                <div className="text-xs font-semibold text-stone-700">Simulate Front & Back Upload</div>
                <p className="text-[11px] text-stone-400">PDF, JPG or PNG up to 10MB</p>
              </div>

              <button
                onClick={() => submitVerification(docType)}
                className="w-full py-2.5 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-semibold rounded-xl transition-colors"
              >
                Submit Documents for Admin Approval
              </button>
            </div>
          )}
        </div>
      )}

      {/* ADD/EDIT SERVICE MODAL */}
      {isServiceModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-stone-200">
              <h3 className="font-serif font-bold text-lg text-stone-900">
                {editingServiceId ? 'Edit Service Listing' : 'Publish New Companionship Service'}
              </h3>
              <button onClick={() => setIsServiceModalOpen(false)}>
                <X className="w-5 h-5 text-stone-400 hover:text-stone-700" />
              </button>
            </div>

            <form onSubmit={handleSaveService} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-semibold text-stone-700">Experience Category</label>
                <select
                  value={formCategoryId}
                  onChange={(e) => setFormCategoryId(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                >
                  {categories.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-stone-700">Service Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Afternoon Tea & Art Discussion at Bengal Shilpalay"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-semibold text-stone-700">Price in BDT (৳)</label>
                  <input
                    type="number"
                    min="500"
                    step="100"
                    required
                    value={formPrice}
                    onChange={(e) => setFormPrice(Number(e.target.value))}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-stone-700">Pricing Unit</label>
                  <select
                    value={formPricingUnit}
                    onChange={(e) => setFormPricingUnit(e.target.value as PricingUnit)}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                  >
                    <option value="hourly">Hourly Rate (per hour)</option>
                    <option value="session">Fixed Session</option>
                    <option value="package">Package Experience</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-semibold text-stone-700">Base Duration (Hours)</label>
                  <input
                    type="number"
                    min="1"
                    max="8"
                    value={formDurationHours}
                    onChange={(e) => setFormDurationHours(Number(e.target.value))}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-stone-700">Service Area / Venues</label>
                  <input
                    type="text"
                    value={formLocation}
                    onChange={(e) => setFormLocation(e.target.value)}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                    placeholder="e.g. Gulshan, Banani, Dhanmondi"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-stone-700">Detailed Description</label>
                <textarea
                  rows={3}
                  required
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Describe the atmosphere, conversation flow, and expectations..."
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-stone-700">Service Boundaries (One per line)</label>
                <textarea
                  rows={3}
                  value={formBoundaries}
                  onChange={(e) => setFormBoundaries(e.target.value)}
                  placeholder="e.g.&#10;Strictly public venues&#10;No physical contact&#10;Alcohol-free"
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsServiceModalOpen(false)}
                  className="px-4 py-2 border border-stone-200 rounded-xl text-stone-600 hover:bg-stone-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#721C38] hover:bg-[#58152B] text-white font-semibold rounded-xl"
                >
                  Save Service
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REQUEST PAYOUT MODAL */}
      {isPayoutModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-stone-200">
              <h3 className="font-serif font-bold text-lg text-stone-900">Request Earnings Payout</h3>
              <button onClick={() => setIsPayoutModalOpen(false)}>
                <X className="w-5 h-5 text-stone-400" />
              </button>
            </div>

            <form onSubmit={handleRequestPayoutSubmit} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-semibold text-stone-700">Payout Method (Bangladesh)</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'bkash', label: 'bKash' },
                    { id: 'nagad', label: 'Nagad' },
                    { id: 'bank_transfer', label: 'Bank' }
                  ].map(m => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setPayoutMethod(m.id as any)}
                      className={`py-2 text-xs font-semibold rounded-lg border transition-all ${
                        payoutMethod === m.id ? 'border-[#721C38] bg-rose-50 text-[#721C38]' : 'border-stone-200'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-stone-700">Wallet / Account Number</label>
                <input
                  type="text"
                  required
                  value={payoutAccount}
                  onChange={(e) => setPayoutAccount(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                  placeholder="01XXXXXXXXX"
                />
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-[11px]">
                Demo notice: Payouts are queued in the admin review ledger and marked processed within the simulation.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsPayoutModalOpen(false)}
                  className="px-4 py-2 border border-stone-200 rounded-xl text-stone-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-xl"
                >
                  Confirm Payout Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
