import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatTime } from '../../utils/formatters';
import { X, Send, ShieldAlert, MessageSquare, AlertCircle } from 'lucide-react';

interface MessagingDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  initialRecipientId?: string | null;
}

export const MessagingDrawer: React.FC<MessagingDrawerProps> = ({
  isOpen,
  onClose,
  initialRecipientId
}) => {
  const { 
    currentUser, 
    allUsers, 
    conversations, 
    messages, 
    sendMessage 
  } = useApp();

  const [activePartnerId, setActivePartnerId] = useState<string>(
    initialRecipientId || (conversations[0]?.participantIds.find(id => id !== currentUser.id) || 'usr-1')
  );

  const [inputText, setInputText] = useState('');

  if (!isOpen) return null;

  // Active chat partner
  const chatPartner = allUsers.find(u => u.id === activePartnerId);

  // Active messages between currentUser and chatPartner
  const conversationMessages = messages.filter(m => 
    (m.senderId === currentUser.id && m.receiverId === activePartnerId) ||
    (m.senderId === activePartnerId && m.receiverId === currentUser.id)
  );

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    sendMessage(activePartnerId, inputText.trim());
    setInputText('');
  };

  // Recent conversations list
  const userConversations = conversations.filter(c => c.participantIds.includes(currentUser.id));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-stone-900/40 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white h-full shadow-2xl flex flex-col border-l border-stone-200">
        
        {/* Top Drawer Bar */}
        <div className="p-4 bg-[#FAF7F5] border-b border-stone-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-[#721C38]" />
            <h3 className="font-serif font-bold text-base text-stone-900">In-App Messages</h3>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-stone-200 text-stone-500">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Conversation Switcher Pills if multiple */}
        <div className="p-3 border-b border-stone-100 flex items-center gap-2 overflow-x-auto bg-stone-50/50">
          {allUsers.filter(u => u.id !== currentUser.id && u.isProviderActive).map(user => (
            <button
              key={user.id}
              onClick={() => setActivePartnerId(user.id)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs whitespace-nowrap transition-all border ${
                activePartnerId === user.id 
                  ? 'bg-white border-[#721C38] text-[#721C38] font-bold shadow-2xs' 
                  : 'border-transparent text-stone-600 hover:bg-stone-100'
              }`}
            >
              <img src={user.avatar} alt={user.displayName} className="w-5 h-5 rounded-full object-cover" />
              <span>{user.displayName}</span>
            </button>
          ))}
        </div>

        {/* Safety Warning in Chat */}
        <div className="p-3 bg-rose-50/60 border-b border-rose-100 flex items-center gap-2 text-[11px] text-rose-900">
          <ShieldAlert className="w-4 h-4 text-[#721C38] shrink-0" />
          <span>
            For your security, keep conversations on-platform. Do not share financial or off-platform payment info.
          </span>
        </div>

        {/* Messages Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#FAF7F5]/40">
          {conversationMessages.length === 0 ? (
            <div className="text-center py-16 text-stone-400 text-xs">
              Say hello to {chatPartner?.displayName}! Introduce yourself and coordinate your public meeting.
            </div>
          ) : (
            conversationMessages.map(msg => {
              const isMe = msg.senderId === currentUser.id;
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-xs leading-relaxed shadow-2xs ${
                      isMe 
                        ? 'bg-[#721C38] text-white rounded-br-xs' 
                        : 'bg-white text-stone-800 border border-stone-200/80 rounded-bl-xs'
                    }`}
                  >
                    {msg.bookingReference && (
                      <span className="block text-[9px] uppercase font-bold tracking-wider opacity-80 mb-1">
                        Ref: {msg.bookingReference}
                      </span>
                    )}
                    <p>{msg.text}</p>
                  </div>
                  <span className="text-[10px] text-stone-400 mt-1 px-1">
                    {formatTime(msg.timestamp.split('T')[1]?.slice(0, 5) || '')}
                  </span>
                </div>
              );
            })
          )}
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSend} className="p-3 border-t border-stone-200 bg-white flex items-center gap-2">
          <input
            type="text"
            placeholder={`Message ${chatPartner?.displayName || 'companion'}...`}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="flex-1 text-xs px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
          />
          <button
            type="submit"
            className="p-2.5 bg-[#721C38] text-white rounded-xl hover:bg-[#58152B] transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};
