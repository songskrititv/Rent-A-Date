import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BookingStatus, Booking } from '../../types';
import { formatBDT, formatDate, formatTime } from '../../utils/formatters';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  MessageSquare, 
  ShieldCheck, 
  AlertCircle, 
  Heart, 
  Star, 
  CreditCard, 
  CheckCircle2, 
  XCircle,
  Share2,
  User,
  Plus,
  Gift,
  Coins,
  Wallet
} from 'lucide-react';
import { ReferralProgramModule } from '../referral/ReferralProgramModule';

export const CustomerDashboard: React.FC<{
  onOpenMessages: (recipientId?: string) => void;
  onExplore: () => void;
}> = ({ onOpenMessages, onExplore }) => {
  const { 
    currentUser, 
    bookings, 
    allUsers, 
    services, 
    updateBookingStatus, 
    submitReview, 
    reviews, 
    savedProviderIds,
    toggleSaveProvider,
    processPayment,
    startMeetup,
    addTip,
    setActiveLiveBookingId,
    activeLiveBookingId,
    referrals,
    walletCredits,
    language
  } = useApp();

  const [activeTab, setActiveTab] = useState<'bookings' | 'saved' | 'safety_checkin' | 'referrals' | 'profile'>('bookings');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Review modal state & Tip state
  const [reviewBookingId, setReviewBookingId] = useState<string | null>(null);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [selectedTip, setSelectedTip] = useState<number>(0);

  // Emergency contact state
  const [emergencyName, setEmergencyName] = useState('Rahim Karim');
  const [emergencyPhone, setEmergencyPhone] = useState('+880 1712 112233');
  const [checkinSent, setCheckinSent] = useState(false);

  // Filter bookings belonging to current user as customer
  const customerBookings = bookings.filter(b => b.customerId === currentUser.id);

  const filteredBookings = customerBookings.filter(b => {
    if (statusFilter === 'all') return true;
    if (statusFilter === 'upcoming') return b.status === 'confirmed' || b.status === 'in_progress';
    if (statusFilter === 'pending') return b.status === 'pending_acceptance' || b.status === 'payment_pending';
    if (statusFilter === 'completed') return b.status === 'completed';
    if (statusFilter === 'cancelled') return b.status === 'cancelled' || b.status === 'declined';
    return true;
  });

  const savedCompanions = allUsers.filter(u => savedProviderIds.includes(u.id));

  const handleCancelBooking = (booking: Booking) => {
    const reason = prompt('Please provide a reason for cancellation:');
    if (reason) {
      updateBookingStatus(booking.id, 'cancelled', reason);
    }
  };

  const handlePayNow = async (bookingId: string) => {
    await processPayment(bookingId, 'bkash');
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewBookingId) return;
    submitReview(reviewBookingId, reviewRating, reviewComment);
    if (selectedTip > 0) {
      addTip(reviewBookingId, selectedTip);
    }
    setReviewBookingId(null);
    setReviewComment('');
    setSelectedTip(0);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Account Overview Bar */}
      <div className="bg-white rounded-3xl border border-stone-200/90 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <img
            src={currentUser.avatar}
            alt={currentUser.displayName}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-stone-100 shadow-xs"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-serif text-2xl font-bold text-stone-900">{currentUser.fullName}</h1>
              <span className="text-[11px] font-semibold bg-stone-100 text-stone-700 px-2 py-0.5 rounded-md">
                Customer Workspace
              </span>
            </div>
            <div className="text-xs text-stone-500 mt-0.5">
              {currentUser.email} · {currentUser.area}, Dhaka · Member since {formatDate(currentUser.joinedDate)}
            </div>
          </div>
        </div>

        {/* Quick summary stats */}
        <div className="flex items-center gap-6 border-t md:border-t-0 md:border-l border-stone-100 pt-4 md:pt-0 md:pl-6 flex-wrap">
          <div>
            <span className="text-[10px] uppercase font-semibold text-stone-400 block">Total Bookings</span>
            <span className="text-xl font-bold text-stone-900">{customerBookings.length}</span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-semibold text-stone-400 block">Saved Companions</span>
            <span className="text-xl font-bold text-stone-900">{savedCompanions.length}</span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-semibold text-stone-400 block">Referral Credits</span>
            <button
              type="button"
              onClick={() => setActiveTab('referrals')}
              className="text-xl font-bold text-[#721C38] hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>{formatBDT(walletCredits)}</span>
              <Gift className="w-4 h-4 text-rose-500" />
            </button>
          </div>
          <div>
            <span className="text-[10px] uppercase font-semibold text-stone-400 block">Status</span>
            <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
              Active Client
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-stone-200 gap-6 text-sm font-semibold overflow-x-auto pb-0.5">
        <button
          onClick={() => setActiveTab('bookings')}
          className={`pb-3 transition-colors whitespace-nowrap ${
            activeTab === 'bookings'
              ? 'text-[#721C38] border-b-2 border-[#721C38]'
              : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          My Bookings ({customerBookings.length})
        </button>
        <button
          onClick={() => setActiveTab('saved')}
          className={`pb-3 transition-colors whitespace-nowrap ${
            activeTab === 'saved'
              ? 'text-[#721C38] border-b-2 border-[#721C38]'
              : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          Saved Companions ({savedCompanions.length})
        </button>
        <button
          onClick={() => setActiveTab('safety_checkin')}
          className={`pb-3 transition-colors whitespace-nowrap ${
            activeTab === 'safety_checkin'
              ? 'text-[#721C38] border-b-2 border-[#721C38]'
              : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          Safety & Trusted Contact
        </button>
        <button
          onClick={() => setActiveTab('referrals')}
          className={`pb-3 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'referrals'
              ? 'text-[#721C38] border-b-2 border-[#721C38]'
              : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <Gift className="w-4 h-4 text-rose-600" />
          <span>{language === 'bn' ? 'রেফারেল ও ক্রেডিট' : 'Refer & Earn Credits'}</span>
          <span className="text-[11px] font-mono font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
            {formatBDT(walletCredits)}
          </span>
        </button>
      </div>

      {/* TAB 1: BOOKINGS */}
      {activeTab === 'bookings' && (
        <div className="space-y-6">
          {/* Status Sub-filter */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            {['all', 'upcoming', 'pending', 'completed', 'cancelled'].map(tab => (
              <button
                key={tab}
                onClick={() => setStatusFilter(tab)}
                className={`px-3 py-1.5 rounded-lg capitalize font-medium transition-colors ${
                  statusFilter === tab 
                    ? 'bg-stone-900 text-white' 
                    : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-50'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {filteredBookings.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-3xl border border-stone-200 p-8 space-y-4">
              <Calendar className="w-12 h-12 text-stone-300 mx-auto" />
              <div>
                <h3 className="font-serif text-lg font-bold text-stone-800">No bookings found</h3>
                <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
                  Browse companions across Dhaka for dining, coffee meetups, or cultural events.
                </p>
              </div>
              <button
                onClick={onExplore}
                className="px-5 py-2.5 bg-[#721C38] text-white text-xs font-semibold rounded-xl hover:bg-[#58152B] transition-colors"
              >
                Discover Companions
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredBookings.map(booking => {
                const provider = allUsers.find(u => u.id === booking.providerId);
                const isReviewed = reviews.some(r => r.bookingId === booking.id);

                return (
                  <div
                    key={booking.id}
                    className="bg-white rounded-2xl border border-stone-200/90 p-5 sm:p-6 shadow-xs hover:border-stone-300 transition-colors space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-stone-100">
                      <div className="flex items-center gap-3">
                        <img
                          src={provider?.avatar}
                          alt={provider?.displayName}
                          className="w-12 h-12 rounded-xl object-cover border border-stone-100"
                        />
                        <div>
                          <span className="text-[10px] text-stone-400 font-bold uppercase tracking-wider">
                            Booking #{booking.bookingCode}
                          </span>
                          <h3 className="font-serif font-bold text-base text-stone-900">
                            {booking.priceSnapshot.serviceTitle} with {provider?.displayName}
                          </h3>
                        </div>
                      </div>

                      {/* Status Tag */}
                      <div className="self-start sm:self-center">
                        <span className={`text-xs font-semibold px-2.5 py-1 rounded-md capitalize ${
                          booking.status === 'confirmed' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' :
                          booking.status === 'pending_acceptance' ? 'bg-amber-50 text-amber-800 border border-amber-200' :
                          booking.status === 'completed' ? 'bg-stone-100 text-stone-800' :
                          booking.status === 'cancelled' ? 'bg-rose-50 text-rose-800 border border-rose-200' :
                          'bg-stone-100 text-stone-700'
                        }`}>
                          {booking.status.replace('_', ' ')}
                        </span>
                      </div>
                    </div>

                    {/* Details Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-stone-600 bg-[#FAF7F5] p-3.5 rounded-xl border border-stone-200/60">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-[#721C38]" />
                        <div>
                          <span className="text-[10px] text-stone-400 block font-medium">Scheduled Time</span>
                          <span className="font-semibold text-stone-800">
                            {formatDate(booking.scheduledDate)} at {formatTime(booking.scheduledTime)}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-[#721C38]" />
                        <div>
                          <span className="text-[10px] text-stone-400 block font-medium">Meetup Venue</span>
                          <span className="font-semibold text-stone-800 truncate block max-w-[200px]">
                            {booking.meetupLocation}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <CreditCard className="w-4 h-4 text-[#721C38]" />
                        <div>
                          <span className="text-[10px] text-stone-400 block font-medium">Agreed Total</span>
                          <span className="font-bold text-[#721C38]">
                            {formatBDT(booking.priceSnapshot.totalPayable)}
                          </span>
                          <span className="text-[10px] text-stone-500 ml-1">
                            ({booking.paymentStatus === 'paid' ? `Paid via ${booking.paymentMethod?.toUpperCase()}` : 'Unpaid'})
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Boundary & Snapshot Rules Preview */}
                    <div className="text-[11px] text-stone-500 flex flex-wrap items-center gap-3">
                      <span className="font-medium text-stone-700">Service Boundaries:</span>
                      {booking.priceSnapshot.serviceBoundaries.map((b, i) => (
                        <span key={i} className="text-stone-600">· {b}</span>
                      ))}
                    </div>

                    {/* Action Buttons */}
                    <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-stone-100 text-xs">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onOpenMessages(booking.providerId)}
                          className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg font-medium flex items-center gap-1.5 transition-colors"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>Message {provider?.displayName}</span>
                        </button>
                      </div>

                      <div className="flex items-center gap-2 flex-wrap">
                        {/* Escrow status tag for paid bookings */}
                        {booking.paymentStatus === 'paid' && booking.status !== 'completed' && booking.status !== 'cancelled' && (
                          <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-1 rounded-md">
                            Escrow Funded
                          </span>
                        )}

                        {/* Start Meetup & SOS Tracker button */}
                        {(booking.status === 'confirmed' || booking.status === 'in_progress') && (
                          <button
                            onClick={() => startMeetup(booking.id)}
                            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer animate-pulse"
                          >
                            <ShieldCheck className="w-3.5 h-3.5" />
                            <span>{booking.meetupState === 'active_live' ? 'Live Meetup HUD' : 'Start Meetup (SOS Active)'}</span>
                          </button>
                        )}

                        {/* If payment pending or accepted unpaid */}
                        {booking.paymentStatus === 'unpaid' && booking.status !== 'cancelled' && (
                          <button
                            onClick={() => handlePayNow(booking.id)}
                            className="px-3.5 py-1.5 bg-[#721C38] hover:bg-[#58152B] text-white font-semibold rounded-lg shadow-xs transition-colors"
                          >
                            Pay {formatBDT(booking.priceSnapshot.totalPayable)} (Demo)
                          </button>
                        )}

                        {/* If completed, allow review */}
                        {booking.status === 'completed' && !isReviewed && (
                          <button
                            onClick={() => setReviewBookingId(booking.id)}
                            className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-white font-semibold rounded-lg flex items-center gap-1 transition-colors"
                          >
                            <Star className="w-3.5 h-3.5 fill-white" />
                            <span>Leave Review & Tip</span>
                          </button>
                        )}

                        {booking.status === 'completed' && isReviewed && (
                          <span className="text-emerald-700 font-medium text-xs flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Review Submitted {booking.tipAmount ? `(Tip: ${formatBDT(booking.tipAmount)})` : ''}
                          </span>
                        )}

                        {/* Cancel button if pending or confirmed */}
                        {(booking.status === 'pending_acceptance' || booking.status === 'confirmed') && (
                          <button
                            onClick={() => handleCancelBooking(booking)}
                            className="text-stone-400 hover:text-rose-600 font-medium transition-colors"
                          >
                            Cancel Booking
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: SAVED COMPANIONS */}
      {activeTab === 'saved' && (
        <div className="space-y-4">
          {savedCompanions.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-2xl border border-stone-200">
              <Heart className="w-10 h-10 text-stone-300 mx-auto mb-2" />
              <p className="text-xs text-stone-500">You haven't saved any companion profiles yet.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {savedCompanions.map(c => (
                <div key={c.id} className="bg-white rounded-2xl border border-stone-200 p-4 flex items-center gap-3 shadow-xs">
                  <img src={c.avatar} alt={c.displayName} className="w-14 h-14 rounded-xl object-cover" />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-serif font-bold text-sm text-stone-900 truncate">{c.displayName}</h4>
                    <p className="text-xs text-stone-500">{c.area}, Dhaka</p>
                    <div className="flex items-center gap-1 text-xs text-amber-600 font-semibold mt-1">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                      <span>{c.rating}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleSaveProvider(c.id)}
                    className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg"
                    title="Remove"
                  >
                    <Heart className="w-4 h-4 fill-rose-500" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: SAFETY & TRUSTED CONTACT */}
      {activeTab === 'safety_checkin' && (
        <div className="bg-white rounded-2xl border border-stone-200 p-6 space-y-6 max-w-2xl">
          <div>
            <h3 className="font-serif font-bold text-lg text-stone-900">Safety Check-In & Trusted Contact</h3>
            <p className="text-xs text-stone-500 mt-1">
              Before attending any companion meetup, you can designate an emergency contact who will receive an automated simulation alert with your meetup time and venue.
            </p>
          </div>

          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-stone-700">Trusted Contact Full Name</label>
              <input
                type="text"
                value={emergencyName}
                onChange={(e) => setEmergencyName(e.target.value)}
                className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-stone-700">Emergency Phone Number (+880)</label>
              <input
                type="text"
                value={emergencyPhone}
                onChange={(e) => setEmergencyPhone(e.target.value)}
                className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
              />
            </div>

            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 text-xs text-emerald-900 space-y-1">
              <div className="font-semibold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                Live Status Tracker Simulation
              </div>
              <p className="text-emerald-800">
                When active, your trusted contact can view your verified meetup time, location, and companion identity.
              </p>
            </div>

            <button
              onClick={() => {
                setCheckinSent(true);
                setTimeout(() => setCheckinSent(false), 4000);
              }}
              className="px-5 py-2.5 bg-stone-900 hover:bg-[#721C38] text-white text-xs font-semibold rounded-xl transition-colors flex items-center gap-2"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>{checkinSent ? 'Alert Dispatched to Trusted Contact!' : 'Send Test Check-in Alert (SMS Simulation)'}</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 4: REFERRAL & CREDITS */}
      {activeTab === 'referrals' && (
        <div className="pt-2 animate-in fade-in">
          <ReferralProgramModule
            onExplore={onExplore}
            onBookWithCredits={onExplore}
          />
        </div>
      )}

      {/* Review Modal */}
      {reviewBookingId && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl">
            <h3 className="font-serif font-bold text-lg text-stone-900">Review Your Experience</h3>
            <form onSubmit={handleReviewSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-stone-700">Rating (1 to 5 Stars)</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map(star => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setReviewRating(star)}
                      className="p-1"
                    >
                      <Star className={`w-6 h-6 ${star <= reviewRating ? 'fill-amber-400 text-amber-500' : 'text-stone-300'}`} />
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-stone-700">Written Feedback</label>
                <textarea
                  required
                  rows={3}
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  placeholder="Share your experience regarding punctuality, conversation quality, and safety..."
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              {/* Optional Companion Tip */}
              <div className="space-y-1.5 bg-rose-50/50 p-3 rounded-xl border border-rose-100">
                <label className="text-xs font-semibold text-stone-800 flex items-center justify-between">
                  <span>Add Gratuity / Tip (Optional)</span>
                  <span className="text-[10px] text-[#721C38] font-bold">100% Goes to Companion</span>
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {[0, 100, 200, 500].map(amt => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setSelectedTip(amt)}
                      className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                        selectedTip === amt 
                          ? 'border-[#721C38] bg-[#721C38] text-white' 
                          : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                      }`}
                    >
                      {amt === 0 ? 'No Tip' : `+৳${amt}`}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setReviewBookingId(null)}
                  className="px-4 py-2 text-xs font-medium text-stone-600 hover:bg-stone-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold bg-[#721C38] text-white rounded-lg hover:bg-[#58152B] cursor-pointer"
                >
                  Submit Review {selectedTip > 0 ? `& ৳${selectedTip} Tip` : ''}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
