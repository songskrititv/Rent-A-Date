import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatBDT, formatDate } from '../../utils/formatters';
import { 
  Users, 
  Layers, 
  DollarSign, 
  ShieldAlert, 
  CheckCircle, 
  XCircle, 
  Percent, 
  Sliders, 
  Search, 
  ShieldCheck, 
  AlertTriangle,
  Lock,
  Eye,
  FileCheck2,
  CalendarCheck
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { 
    allUsers, 
    services, 
    bookings, 
    categories, 
    safetyReports, 
    platformConfig,
    adminApproveVerification,
    adminRejectVerification,
    updateCommissionRate,
    toggleCategoryStatus,
    adminSuspendUser
  } = useApp();

  const [activeTab, setActiveTab] = useState<'kpi' | 'verifications' | 'users' | 'categories' | 'commissions' | 'safety'>('kpi');
  const [userSearch, setUserSearch] = useState('');
  const [newCommissionRate, setNewCommissionRate] = useState(platformConfig.commissionRate * 100);

  // Computed metrics
  const totalUsers = allUsers.length;
  const providersCount = allUsers.filter(u => u.isProviderActive).length;
  const customersCount = totalUsers - providersCount;
  const pendingVerifications = allUsers.filter(u => u.verificationStatus === 'pending');
  
  const totalBookingsCount = bookings.length;
  const completedBookings = bookings.filter(b => b.status === 'completed');
  const grossBookingValue = completedBookings.reduce((sum, b) => sum + b.priceSnapshot.subtotal, 0);
  const platformRevenue = completedBookings.reduce((sum, b) => sum + b.priceSnapshot.platformFeeAmount, 0);

  const filteredUsers = allUsers.filter(u => 
    u.fullName.toLowerCase().includes(userSearch.toLowerCase()) ||
    u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
    u.area.toLowerCase().includes(userSearch.toLowerCase())
  );

  const handleUpdateCommission = (e: React.FormEvent) => {
    e.preventDefault();
    updateCommissionRate(newCommissionRate / 100);
    alert(`Platform commission rate updated to ${newCommissionRate}%`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Header bar */}
      <div className="bg-stone-900 text-white rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-md">
        <div>
          <div className="flex items-center gap-2 text-rose-300 text-xs font-semibold uppercase tracking-wider">
            <Lock className="w-3.5 h-3.5" />
            <span>Authorized Administration Console</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold mt-1 text-white">
            Marketplace Governance & Compliance
          </h1>
          <p className="text-xs text-stone-400 mt-1 max-w-xl">
            Enforce trust, moderate companion verifications, monitor safety reports, and manage financial commission parameters across Bangladesh.
          </p>
        </div>

        <div className="bg-stone-800/80 px-4 py-2.5 rounded-2xl border border-stone-700/80 text-xs flex items-center gap-3">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></div>
          <div>
            <span className="text-stone-400 block text-[10px]">CURRENT COMMISSION</span>
            <span className="font-bold text-white text-base">{Math.round(platformConfig.commissionRate * 100)}%</span>
          </div>
        </div>
      </div>

      {/* Navigation tabs */}
      <div className="flex border-b border-stone-200 gap-6 text-xs sm:text-sm font-semibold overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('kpi')}
          className={`pb-3 transition-colors whitespace-nowrap ${
            activeTab === 'kpi' ? 'text-[#721C38] border-b-2 border-[#721C38]' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          Executive Overview
        </button>
        <button
          onClick={() => setActiveTab('verifications')}
          className={`pb-3 transition-colors flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'verifications' ? 'text-[#721C38] border-b-2 border-[#721C38]' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <span>ID Verifications</span>
          {pendingVerifications.length > 0 && (
            <span className="w-4 h-4 rounded-full bg-amber-500 text-white text-[10px] flex items-center justify-center font-bold">
              {pendingVerifications.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`pb-3 transition-colors whitespace-nowrap ${
            activeTab === 'users' ? 'text-[#721C38] border-b-2 border-[#721C38]' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          Users Directory ({totalUsers})
        </button>
        <button
          onClick={() => setActiveTab('categories')}
          className={`pb-3 transition-colors whitespace-nowrap ${
            activeTab === 'categories' ? 'text-[#721C38] border-b-2 border-[#721C38]' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          Categories ({categories.length})
        </button>
        <button
          onClick={() => setActiveTab('commissions')}
          className={`pb-3 transition-colors whitespace-nowrap ${
            activeTab === 'commissions' ? 'text-[#721C38] border-b-2 border-[#721C38]' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          Commission Settings
        </button>
        <button
          onClick={() => setActiveTab('safety')}
          className={`pb-3 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'safety' ? 'text-[#721C38] border-b-2 border-[#721C38]' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
          <span>Safety Reports ({safetyReports.length})</span>
        </button>
      </div>

      {/* TAB 1: EXECUTIVE OVERVIEW (KPIs) */}
      {activeTab === 'kpi' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs">
              <span className="text-[10px] uppercase font-bold text-stone-400">Gross Booking Value</span>
              <div className="text-2xl font-bold text-stone-900 mt-1">{formatBDT(grossBookingValue)}</div>
              <span className="text-[11px] text-stone-500">From verified transactions</span>
            </div>

            <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs">
              <span className="text-[10px] uppercase font-bold text-stone-400">Platform Revenue ({Math.round(platformConfig.commissionRate * 100)}%)</span>
              <div className="text-2xl font-bold text-[#721C38] mt-1">{formatBDT(platformRevenue)}</div>
              <span className="text-[11px] text-stone-500">Net marketplace margin</span>
            </div>

            <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs">
              <span className="text-[10px] uppercase font-bold text-stone-400">Active Companions</span>
              <div className="text-2xl font-bold text-stone-900 mt-1">{providersCount}</div>
              <span className="text-[11px] text-stone-500">{customersCount} registered clients</span>
            </div>

            <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs">
              <span className="text-[10px] uppercase font-bold text-stone-400">Total Bookings</span>
              <div className="text-2xl font-bold text-stone-900 mt-1">{totalBookingsCount}</div>
              <span className="text-[11px] text-emerald-700 font-medium">{completedBookings.length} completed</span>
            </div>

          </div>

          {/* Recent marketplace activity */}
          <div className="bg-white rounded-2xl border border-stone-200 p-6 space-y-4">
            <h3 className="font-serif font-bold text-base text-stone-900">Recent Platform Bookings</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-stone-200 text-stone-400 uppercase font-semibold text-[10px]">
                  <tr>
                    <th className="py-2.5">Code</th>
                    <th>Experience</th>
                    <th>Customer</th>
                    <th>Provider</th>
                    <th>Date & Time</th>
                    <th>Total (৳)</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 text-stone-700">
                  {bookings.slice(0, 5).map(b => {
                    const cust = allUsers.find(u => u.id === b.customerId);
                    const prov = allUsers.find(u => u.id === b.providerId);
                    return (
                      <tr key={b.id}>
                        <td className="py-3 font-semibold text-stone-900">{b.bookingCode}</td>
                        <td className="font-medium">{b.priceSnapshot.serviceTitle}</td>
                        <td>{cust?.displayName}</td>
                        <td>{prov?.displayName}</td>
                        <td>{formatDate(b.scheduledDate)} {b.scheduledTime}</td>
                        <td className="font-bold text-stone-900">{formatBDT(b.priceSnapshot.totalPayable)}</td>
                        <td>
                          <span className="capitalize text-[10px] font-semibold bg-stone-100 px-2 py-0.5 rounded">
                            {b.status.replace('_', ' ')}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: VERIFICATION QUEUE */}
      {activeTab === 'verifications' && (
        <div className="bg-white rounded-2xl border border-stone-200 p-6 space-y-6">
          <div>
            <h3 className="font-serif font-bold text-lg text-stone-900">Government Identity Review Queue</h3>
            <p className="text-xs text-stone-500 mt-1">
              Validate National ID cards and Passports to grant the verified badge.
            </p>
          </div>

          {pendingVerifications.length === 0 ? (
            <div className="text-center py-12 bg-stone-50 rounded-2xl border border-dashed border-stone-200 text-xs text-stone-500">
              No pending verification requests in the queue.
            </div>
          ) : (
            <div className="space-y-4">
              {pendingVerifications.map(user => (
                <div key={user.id} className="p-4 rounded-xl border border-amber-200 bg-amber-50/30 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img src={user.avatar} alt={user.displayName} className="w-12 h-12 rounded-xl object-cover" />
                    <div>
                      <div className="font-serif font-bold text-sm text-stone-900">{user.fullName}</div>
                      <div className="text-xs text-stone-500">
                        {user.email} · Document: <span className="font-semibold uppercase">{user.verificationDocumentType || 'NID'}</span>
                      </div>
                      <div className="text-[11px] text-stone-400">Area: {user.area}, Dhaka</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => adminRejectVerification(user.id)}
                      className="px-3 py-1.5 border border-rose-300 text-rose-700 text-xs font-semibold rounded-lg hover:bg-rose-50"
                    >
                      Reject
                    </button>
                    <button
                      onClick={() => adminApproveVerification(user.id)}
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Approve & Grant Badge</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: USERS DIRECTORY */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-2xl border border-stone-200 p-6 space-y-4">
          <div className="flex items-center justify-between gap-4">
            <h3 className="font-serif font-bold text-base text-stone-900">User Accounts</h3>
            <div className="relative w-64">
              <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search user..."
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-xl"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-stone-200 text-stone-400 uppercase font-semibold text-[10px]">
                <tr>
                  <th className="py-2.5">User</th>
                  <th>Email & Phone</th>
                  <th>Area</th>
                  <th>Capabilities</th>
                  <th>ID Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 text-stone-700">
                {filteredUsers.map(u => (
                  <tr key={u.id}>
                    <td className="py-3 flex items-center gap-2.5">
                      <img src={u.avatar} alt={u.displayName} className="w-8 h-8 rounded-full object-cover" />
                      <div>
                        <div className="font-bold text-stone-900">{u.fullName}</div>
                        <div className="text-[10px] text-stone-400">{u.gender}</div>
                      </div>
                    </td>
                    <td>
                      <div>{u.email}</div>
                      <div className="text-[10px] text-stone-400">{u.phone}</div>
                    </td>
                    <td>{u.area}</td>
                    <td>
                      <div className="flex gap-1">
                        <span className="text-[10px] bg-stone-100 px-1.5 py-0.5 rounded">Client</span>
                        {u.isProviderActive && <span className="text-[10px] bg-rose-100 text-[#721C38] px-1.5 py-0.5 rounded font-bold">Companion</span>}
                        {u.isAdmin && <span className="text-[10px] bg-stone-900 text-white px-1.5 py-0.5 rounded font-bold">Admin</span>}
                      </div>
                    </td>
                    <td>
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        u.verificationStatus === 'verified' ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-100 text-stone-500'
                      }`}>
                        {u.verificationStatus}
                      </span>
                    </td>
                    <td>
                      {u.isProviderActive && (
                        <button
                          onClick={() => adminSuspendUser(u.id)}
                          className="text-[11px] text-rose-600 hover:underline"
                        >
                          Suspend Services
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: CATEGORIES MANAGEMENT */}
      {activeTab === 'categories' && (
        <div className="bg-white rounded-2xl border border-stone-200 p-6 space-y-4">
          <div>
            <h3 className="font-serif font-bold text-base text-stone-900">Experience Categories Moderation</h3>
            <p className="text-xs text-stone-500 mt-0.5">Toggle categories active or inactive across discovery filters.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {categories.map(c => (
              <div key={c.id} className="p-3.5 rounded-xl border border-stone-200 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-xs text-stone-900">{c.name} ({c.nameBn})</div>
                  <div className="text-[11px] text-stone-500">{c.description}</div>
                </div>
                <button
                  onClick={() => toggleCategoryStatus(c.id)}
                  className={`px-3 py-1 rounded text-xs font-semibold transition-colors ${
                    c.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-200 text-stone-600'
                  }`}
                >
                  {c.isActive ? 'Active' : 'Inactive'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: COMMISSION SETTINGS */}
      {activeTab === 'commissions' && (
        <div className="bg-white rounded-2xl border border-stone-200 p-6 space-y-6 max-w-xl">
          <div>
            <h3 className="font-serif font-bold text-base text-stone-900">Platform Commission Rules</h3>
            <p className="text-xs text-stone-500 mt-1">
              Adjust the platform fee deducted from companion earnings for trust, safety operations, and marketplace hosting.
            </p>
          </div>

          <form onSubmit={handleUpdateCommission} className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold text-stone-700">
                <span>Commission Percentage</span>
                <span className="text-[#721C38] text-base font-bold">{newCommissionRate}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="35"
                step="1"
                value={newCommissionRate}
                onChange={(e) => setNewCommissionRate(Number(e.target.value))}
                className="w-full accent-[#721C38]"
              />
              <div className="flex justify-between text-[10px] text-stone-400">
                <span>10% (Low)</span>
                <span>20% (Default)</span>
                <span>35% (High)</span>
              </div>
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 bg-[#721C38] text-white text-xs font-semibold rounded-xl hover:bg-[#58152B]"
            >
              Save New Commission Rule
            </button>
          </form>
        </div>
      )}

      {/* TAB 6: SAFETY REPORTS */}
      {activeTab === 'safety' && (
        <div className="bg-white rounded-2xl border border-stone-200 p-6 space-y-4">
          <h3 className="font-serif font-bold text-base text-stone-900">Safety Complaints & Reports</h3>
          {safetyReports.length === 0 ? (
            <div className="text-center py-10 bg-stone-50 rounded-xl border border-dashed border-stone-200 text-xs text-stone-500">
              No open safety incident reports. The platform remains safe and compliant.
            </div>
          ) : (
            <div className="space-y-3">
              {safetyReports.map(r => (
                <div key={r.id} className="p-4 bg-rose-50/50 border border-rose-200 rounded-xl space-y-2 text-xs">
                  <div className="flex justify-between font-bold text-rose-950">
                    <span>Reason: {r.reason}</span>
                    <span className="text-[10px] uppercase bg-rose-100 px-2 py-0.5 rounded">{r.status}</span>
                  </div>
                  <p className="text-rose-900">{r.details}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

    </div>
  );
};
