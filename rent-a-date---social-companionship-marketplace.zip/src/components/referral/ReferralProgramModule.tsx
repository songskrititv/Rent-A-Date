import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatBDT, formatDate } from '../../utils/formatters';
import { 
  Gift, 
  Share2, 
  Copy, 
  Check, 
  Users, 
  ShieldCheck, 
  Sparkles, 
  ArrowRight, 
  Clock, 
  AlertCircle, 
  Send, 
  CheckCircle2, 
  QrCode, 
  Smartphone, 
  Mail, 
  ExternalLink,
  Wallet,
  Coins,
  ScanFace,
  ChevronRight,
  Info,
  HelpCircle,
  BellRing,
  BadgePercent,
  TrendingUp
} from 'lucide-react';

export const ReferralProgramModule: React.FC<{
  onExplore?: () => void;
  onBookWithCredits?: () => void;
}> = ({ onExplore, onBookWithCredits }) => {
  const { 
    currentUser, 
    referrals, 
    creditTransactions, 
    userReferralCode, 
    walletCredits, 
    sendReferralInvite, 
    verifyFriendAndCreditReferrer, 
    sendVerificationReminder, 
    getReferralStats,
    language,
    setActiveView
  } = useApp();

  const isBn = language === 'bn';
  const stats = getReferralStats();

  // Invite form state
  const [friendName, setFriendName] = useState('');
  const [friendContact, setFriendContact] = useState('');
  const [customNote, setCustomNote] = useState('');
  const [inviteSuccessToast, setInviteSuccessToast] = useState<string | null>(null);

  // Copy states
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);

  // Tab filter for referrals list
  const [filterTab, setFilterTab] = useState<'all' | 'verified' | 'pending'>('all');

  // Simulation feedback state
  const [simulationCelebration, setSimulationCelebration] = useState<{
    friendName: string;
    amount: number;
  } | null>(null);

  const referralLink = `${window.location.origin}?ref=${userReferralCode}`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(userReferralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleSendInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!friendName.trim() || !friendContact.trim()) return;

    sendReferralInvite(friendName, friendContact);
    setInviteSuccessToast(
      isBn 
        ? `${friendName}-এর কাছে রেফারেল আমন্ত্রণ সফলভাবে পাঠানো হয়েছে!` 
        : `Referral invitation sent to ${friendName} successfully!`
    );

    setFriendName('');
    setFriendContact('');
    setCustomNote('');

    setTimeout(() => {
      setInviteSuccessToast(null);
    }, 4500);
  };

  const handleSimulateVerification = (referralId: string, name: string) => {
    verifyFriendAndCreditReferrer(referralId, 'face_and_nid');
    setSimulationCelebration({
      friendName: name,
      amount: 500
    });

    setTimeout(() => {
      setSimulationCelebration(null);
    }, 5500);
  };

  const handleSendReminderPing = (referralId: string, name: string) => {
    sendVerificationReminder(referralId);
    setInviteSuccessToast(
      isBn 
        ? `${name}-এর ফোনে ভেরিফিকেশন রিমাইন্ডার পাঠানো হয়েছে!` 
        : `Verification reminder notification sent to ${name}!`
    );
    setTimeout(() => setInviteSuccessToast(null), 3500);
  };

  const filteredReferrals = referrals.filter(r => {
    if (filterTab === 'verified') return r.status === 'verified';
    if (filterTab === 'pending') return r.status !== 'verified';
    return true;
  });

  const pendingCount = referrals.filter(r => r.status !== 'verified').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-200">
      
      {/* Simulation Celebration Notification Banner */}
      {simulationCelebration && (
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-2xl p-4 shadow-lg flex items-center justify-between gap-4 animate-in slide-in-from-top-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <Sparkles className="w-6 h-6 text-amber-200 animate-spin" />
            </div>
            <div>
              <div className="font-serif text-base font-bold flex items-center gap-2">
                <span>{isBn ? 'অভিনন্দন! রেফারেল বোনাস অর্জিত হয়েছে!' : 'Celebration! Referral Bonus Unlocked!'}</span>
                <span className="text-xs bg-amber-400 text-stone-900 px-2 py-0.5 rounded-full font-mono font-bold">+৳{simulationCelebration.amount}</span>
              </div>
              <p className="text-xs text-emerald-100">
                {isBn 
                  ? `${simulationCelebration.friendName} বায়োমেট্রিক ফেস ও প্রোফাইল ভেরিফিকেশন সম্পন্ন করেছেন। আপনার ওয়ালেটে ৳${simulationCelebration.amount} ক্রেডিট জমা হয়েছে!`
                  : `${simulationCelebration.friendName} completed face and profile verification. ৳${simulationCelebration.amount} has been added to your credits wallet!`}
              </p>
            </div>
          </div>
          <button
            onClick={() => setSimulationCelebration(null)}
            className="text-white/80 hover:text-white text-xs px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
          >
            ✕
          </button>
        </div>
      )}

      {/* Hero Header & Value Proposition */}
      <div className="relative overflow-hidden bg-gradient-to-br from-[#721C38] via-[#5A152C] to-[#3B0C1C] text-white rounded-3xl p-6 sm:p-10 shadow-xl border border-rose-900/50">
        {/* Subtle decorative background patterns */}
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-rose-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-1/3 -mb-10 w-60 h-60 bg-amber-500/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wide text-rose-200 bg-white/10 backdrop-blur-md px-3 py-1 rounded-xl border border-white/10">
            <Gift className="w-3.5 h-3.5 text-rose-300" />
            <span>{isBn ? 'রেন্ট আ ডেট রেফারেল প্রোগ্রাম ২০২৬' : 'Rent a Date Referral Program'}</span>
          </div>

          <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white leading-tight">
            {isBn ? (
              <>বন্ধুদের আমন্ত্রণ জানান, <span className="text-rose-200 underline decoration-rose-400/50">৳৫০০ ক্রেডিট</span> অর্জন করুন</>
            ) : (
              <>Invite Friends. Earn <span className="text-rose-200 underline decoration-rose-400/50">৳500 Credits</span>.</>
            )}
          </h1>

          <p className="text-sm sm:text-base text-rose-100/90 leading-relaxed max-w-2xl">
            {isBn ? (
              'আপনার পরিচিত বন্ধুদের রেন্ট আ ডেট-এ আমন্ত্রণ জানান। তারা সাইন আপ করে বায়োমেট্রিক ফেস বা এনআইডি ভেরিফিকেশন সম্পন্ন করলেই আপনি পাবেন ৳৫০০ বুকিং ক্রেডিট এবং আপনার বন্ধু পাবেন ৳৩০০ স্বাগতম বোনাস!'
            ) : (
              'Share meaningful companionship experiences with friends. When an invited friend signs up and completes their profile verification (Face or ID), you automatically earn ৳500 platform credits, and your friend gets ৳300 welcome credits!'
            )}
          </p>

          {/* 3 Step Visual Flow */}
          <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3.5 border border-white/10 flex items-start gap-3">
              <span className="w-6 h-6 rounded-lg bg-rose-200 text-[#721C38] font-bold flex items-center justify-center shrink-0 text-xs">
                1
              </span>
              <div>
                <div className="font-bold text-white">{isBn ? 'কোড শেয়ার করুন' : '1. Share Code'}</div>
                <div className="text-[11px] text-rose-200/80">{isBn ? 'আপনার লিঙ্ক বা কোড পাঠান' : 'Send unique invite link'}</div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3.5 border border-white/10 flex items-start gap-3">
              <span className="w-6 h-6 rounded-lg bg-rose-200 text-[#721C38] font-bold flex items-center justify-center shrink-0 text-xs">
                2
              </span>
              <div>
                <div className="font-bold text-white">{isBn ? 'বন্ধু ভেরিফাই করবেন' : '2. Friend Verifies'}</div>
                <div className="text-[11px] text-rose-200/80">{isBn ? 'লাইভ ফেস বা আইডি যাচাই' : 'Completes profile verification'}</div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3.5 border border-white/10 flex items-start gap-3">
              <span className="w-6 h-6 rounded-lg bg-emerald-400 text-stone-900 font-bold flex items-center justify-center shrink-0 text-xs">
                3
              </span>
              <div>
                <div className="font-bold text-white">{isBn ? 'তাৎক্ষণিক ক্রেডিট পান' : '3. Instant Credits'}</div>
                <div className="text-[11px] text-rose-200/80">{isBn ? '৳৫০০ আপনার ওয়ালেটে যুক্ত' : '৳500 added to your wallet'}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Metrics Row: Available Balance & Referral Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Available Wallet Credits */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200/90 shadow-xs flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              {isBn ? 'উপলব্ধ ব্যালেন্স' : 'Available Credits'}
            </span>
            <div className="w-9 h-9 rounded-xl bg-rose-50 text-[#721C38] flex items-center justify-center">
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-serif font-bold text-stone-900 tracking-tight">
              {formatBDT(walletCredits)}
            </div>
            <p className="text-[11px] text-stone-500 mt-0.5">
              {isBn ? 'যেকোনো বুকিংয়ে সরাসরি ব্যবহারযোগ্য' : 'Ready to apply on any booking'}
            </p>
          </div>
          {onBookWithCredits && (
            <button
              onClick={onBookWithCredits}
              className="text-xs font-bold text-[#721C38] hover:underline flex items-center gap-1 cursor-pointer pt-1"
            >
              <span>{isBn ? 'সার্ভিস বুক করুন' : 'Book a Companion'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Total Earned */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200/90 shadow-xs flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              {isBn ? 'সর্বমোট অর্জিত' : 'Total Earned'}
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-serif font-bold text-emerald-700 tracking-tight">
              {formatBDT(stats.totalEarned)}
            </div>
            <p className="text-[11px] text-stone-500 mt-0.5">
              {stats.verifiedCount} {isBn ? 'জন বন্ধু সফলভাবে ভেরিফাইড' : 'friends verified & rewarded'}
            </p>
          </div>
          <span className="text-[11px] text-emerald-800 font-medium">
            ✓ {isBn ? 'লাইফটাইম ক্রেডিট আয়' : 'Lifetime verified earnings'}
          </span>
        </div>

        {/* Pending Verification Credits */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200/90 shadow-xs flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              {isBn ? 'অপেক্ষমাণ ক্রেডিট' : 'Pending Credits'}
            </span>
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-serif font-bold text-amber-800 tracking-tight">
              {formatBDT(stats.pendingCredits)}
            </div>
            <p className="text-[11px] text-stone-500 mt-0.5">
              {stats.pendingCount} {isBn ? 'জন বন্ধুর ভেরিফিকেশন বাকি' : 'friends awaiting verification'}
            </p>
          </div>
          <span className="text-[11px] text-amber-800 font-medium">
            ⏳ {isBn ? 'ভেরিফাই করলেই অ্যাকাউন্টে জমা হবে' : 'Unlocks once friends verify'}
          </span>
        </div>

        {/* Total Invited Friends */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200/90 shadow-xs flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              {isBn ? 'মোট আমন্ত্রিত' : 'Total Invited'}
            </span>
            <div className="w-9 h-9 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-serif font-bold text-stone-900 tracking-tight">
              {stats.totalInvited}
            </div>
            <p className="text-[11px] text-stone-500 mt-0.5">
              {isBn ? 'রেফারেল নেটওয়ার্ক সদস্য' : 'Network members in Dhaka'}
            </p>
          </div>
          <span className="text-[11px] text-stone-600 font-medium">
            ∞ {isBn ? 'সীমাহীন আমন্ত্রণ সুবিধা' : 'No limit on referrals'}
          </span>
        </div>
      </div>

      {/* Main Two-Column Layout: Referral Code & Sharing vs. Direct Invite Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COLUMN: Your Referral Code & Social Channels (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-stone-200/90 shadow-xs space-y-6">
            <div>
              <h2 className="font-serif text-xl font-bold text-stone-900">
                {isBn ? 'আপনার ব্যক্তিগত রেফারেল কোড ও লিঙ্ক' : 'Your Personal Referral Code & Link'}
              </h2>
              <p className="text-xs text-stone-500 mt-1">
                {isBn ? 'বন্ধুদের এই কোড দিন অথবা সরাসরি লিঙ্ক শেয়ার করুন।' : 'Share this code or link with friends in Dhaka.'}
              </p>
            </div>

            {/* Code Box */}
            <div className="p-4 bg-gradient-to-r from-stone-50 to-rose-50/40 rounded-2xl border border-stone-200 space-y-3">
              <div className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
                {isBn ? 'রেফারেল কোড' : 'Referral Code'}
              </div>
              <div className="flex items-center justify-between gap-3 bg-white p-2.5 rounded-xl border border-stone-200/80 shadow-2xs">
                <span className="font-mono text-xl sm:text-2xl font-bold text-[#721C38] tracking-widest pl-2">
                  {userReferralCode}
                </span>
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="px-4 py-2 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-bold rounded-lg transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? (isBn ? 'কপি হয়েছে!' : 'Copied!') : (isBn ? 'কোড কপি' : 'Copy Code')}</span>
                </button>
              </div>

              {/* Link Box */}
              <div className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider pt-1">
                {isBn ? 'শেয়ার লিঙ্ক' : 'Shareable Link'}
              </div>
              <div className="flex items-center justify-between gap-3 bg-white p-2.5 rounded-xl border border-stone-200/80 shadow-2xs">
                <span className="text-xs text-stone-600 truncate font-mono pl-2">
                  {referralLink}
                </span>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedLink ? (isBn ? 'কপি হয়েছে!' : 'Copied!') : (isBn ? 'কপি' : 'Copy')}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowQrModal(!showQrModal)}
                    className="p-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg transition-colors cursor-pointer"
                    title={isBn ? 'কিউআর কোড দেখুন' : 'Show QR Code'}
                  >
                    <QrCode className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Social Sharing Quick Buttons */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-stone-700">
                {isBn ? 'সরাসরি শেয়ার করুন:' : 'Quick Share Via:'}
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {/* WhatsApp */}
                <a
                  href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
                    isBn 
                      ? `রেন্ট আ ডেট-এ যোগ দিয়ে ৳৩০০ স্বাগতম বোনাস পান! আমার রেফারেল কোড: ${userReferralCode} লিঙ্ক: ${referralLink}`
                      : `Join Rent a Date and get ৳300 welcome credits! Use my referral code: ${userReferralCode} link: ${referralLink}`
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2.5 bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200 rounded-xl text-emerald-900 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                >
                  <Smartphone className="w-3.5 h-3.5 text-emerald-700" />
                  <span>WhatsApp</span>
                </a>

                {/* Messenger / Facebook */}
                <a
                  href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralLink)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2.5 bg-blue-50 hover:bg-blue-100/80 border border-blue-200 rounded-xl text-blue-900 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                >
                  <Share2 className="w-3.5 h-3.5 text-blue-700" />
                  <span>Facebook</span>
                </a>

                {/* Email */}
                <a
                  href={`mailto:?subject=${encodeURIComponent(
                    isBn ? 'রেন্ট আ ডেট আমন্ত্রণ: ৳৩০০ স্বাগতম ক্রেডিট' : 'Invitation to Rent a Date Bangladesh: ৳300 Welcome Credits'
                  )}&body=${encodeURIComponent(
                    isBn
                      ? `হ্যালো! রেন্ট আ ডেট প্ল্যাটফর্মে যোগ দিন এবং আপনার প্রোফাইল ভেরিফাই করে ৳৩০০ ক্রেডিট পান। আমার রেফারেল কোড: ${userReferralCode} অথবা সাইন আপ করুন: ${referralLink}`
                      : `Hi! Join Rent a Date to connect with vetted social companions in Dhaka. Verify your profile to receive ৳300 welcome credits. Use my referral code: ${userReferralCode} or sign up at: ${referralLink}`
                  )}`}
                  className="p-2.5 bg-rose-50 hover:bg-rose-100/80 border border-rose-200 rounded-xl text-[#721C38] text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                >
                  <Mail className="w-3.5 h-3.5 text-[#721C38]" />
                  <span>Email</span>
                </a>

                {/* Direct Link */}
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className="p-2.5 bg-stone-100 hover:bg-stone-200 border border-stone-200 rounded-xl text-stone-800 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5 text-stone-600" />
                  <span>{copiedLink ? (isBn ? 'কপিকৃত' : 'Copied') : (isBn ? 'লিঙ্ক কপি' : 'Copy Link')}</span>
                </button>
              </div>
            </div>

            {/* QR Code In-line Drawer / Preview */}
            {showQrModal && (
              <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 text-center space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                    <QrCode className="w-4 h-4 text-[#721C38]" />
                    <span>{isBn ? 'স্ক্যান করে যোগ দিন (QR Code)' : 'Scan QR Code to Join'}</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowQrModal(false)}
                    className="text-stone-400 hover:text-stone-700 text-xs"
                  >
                    ✕
                  </button>
                </div>
                {/* Clean SVG QR code representation */}
                <div className="w-36 h-36 bg-white p-3 rounded-2xl border border-stone-200 mx-auto shadow-sm flex items-center justify-center">
                  <svg viewBox="0 0 100 100" className="w-full h-full text-stone-900">
                    <rect x="0" y="0" width="30" height="30" fill="currentColor" />
                    <rect x="5" y="5" width="20" height="20" fill="white" />
                    <rect x="10" y="10" width="10" height="10" fill="#721C38" />

                    <rect x="70" y="0" width="30" height="30" fill="currentColor" />
                    <rect x="75" y="5" width="20" height="20" fill="white" />
                    <rect x="80" y="10" width="10" height="10" fill="#721C38" />

                    <rect x="0" y="70" width="30" height="30" fill="currentColor" />
                    <rect x="5" y="75" width="20" height="20" fill="white" />
                    <rect x="10" y="80" width="10" height="10" fill="#721C38" />

                    {/* QR Matrix Dots */}
                    <rect x="40" y="10" width="8" height="8" fill="currentColor" />
                    <rect x="55" y="15" width="8" height="8" fill="currentColor" />
                    <rect x="35" y="35" width="10" height="10" fill="#721C38" />
                    <rect x="55" y="40" width="8" height="8" fill="currentColor" />
                    <rect x="70" y="50" width="10" height="10" fill="currentColor" />
                    <rect x="45" y="60" width="8" height="8" fill="currentColor" />
                    <rect x="65" y="75" width="12" height="12" fill="currentColor" />
                    <rect x="85" y="70" width="8" height="8" fill="#721C38" />
                    <rect x="40" y="85" width="8" height="8" fill="currentColor" />
                  </svg>
                </div>
                <div className="font-mono text-xs font-bold text-stone-700">{userReferralCode}</div>
                <p className="text-[10px] text-stone-500">
                  {isBn ? 'বন্ধু ক্যামেরা দিয়ে স্ক্যান করলেই সরাসরি আপনার রেফারেলে সাইন আপ করতে পারবেন।' : 'Point camera to scan and automatically apply this referral code.'}
                </p>
              </div>
            )}
          </div>

          {/* Interactive Simulation / Testing Sandbox Banner */}
          <div className="bg-gradient-to-br from-amber-50 to-orange-50/50 rounded-3xl p-6 border border-amber-200/90 shadow-xs space-y-3">
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-amber-500 text-stone-950 rounded-lg">
                <ScanFace className="w-4 h-4" />
              </span>
              <div>
                <h3 className="text-sm font-bold text-amber-950 flex items-center gap-2">
                  <span>{isBn ? 'ভেরিফিকেশন টেস্ট সিমুলেটর' : 'Live Verification Test Simulator'}</span>
                  <span className="text-[10px] bg-amber-200 text-amber-900 px-2 py-0.2 rounded font-mono font-bold">SANDBOX</span>
                </h3>
                <p className="text-xs text-amber-900/80">
                  {isBn 
                    ? 'আমন্ত্রিত কোনো বন্ধু প্রোফাইল ও ফেস ভেরিফিকেশন সম্পন্ন করলে কীভাবে ক্রেডিট জমা হয় তা পরীক্ষা করুন:'
                    : 'Simulate how credits are automatically rewarded when an invited friend completes profile verification:'}
                </p>
              </div>
            </div>

            {pendingCount > 0 ? (
              <div className="space-y-2 pt-1">
                <div className="text-xs font-semibold text-amber-950">
                  {isBn ? 'অপেক্ষমাণ বন্ধু নির্বাচন করে ভেরিফিকেশন পরীক্ষা করুন:' : 'Select a pending friend to test verification:'}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {referrals.filter(r => r.status !== 'verified').map(ref => (
                    <button
                      key={ref.id}
                      type="button"
                      onClick={() => handleSimulateVerification(ref.id, ref.friendName)}
                      className="p-3 bg-white hover:bg-amber-100/60 border border-amber-200 rounded-xl text-left transition-all shadow-2xs hover:shadow-xs cursor-pointer group flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-stone-900 group-hover:text-amber-950 truncate">
                          {ref.friendName}
                        </div>
                        <div className="text-[10px] text-stone-500 capitalize">
                          {ref.status === 'registered' ? (isBn ? 'অ্যাকাউন্ট তৈরি করেছে' : 'Registered user') : (isBn ? 'আমন্ত্রণ পাঠানো হয়েছে' : 'Invited')}
                        </div>
                      </div>
                      <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 flex items-center gap-1 shrink-0 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                        <ScanFace className="w-3 h-3" />
                        <span>{isBn ? 'ভেরিফাই করুন' : 'Verify'}</span>
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="p-3 bg-white/80 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-center justify-between gap-3">
                <span>{isBn ? 'সকল আমন্ত্রিত বন্ধু ইতিমধ্যেই ভেরিফাইড! নতুন বন্ধুকে আমন্ত্রণ জানান।' : 'All invited friends are already verified! Send a new invite to test.'}</span>
                <span className="text-emerald-700 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>100% {isBn ? 'সম্পন্ন' : 'Verified'}</span>
                </span>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: Direct Invite Form & Program Rules (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Direct Invite Form */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-stone-200/90 shadow-xs space-y-5">
            <div>
              <h2 className="font-serif text-xl font-bold text-stone-900">
                {isBn ? 'সরাসরি বন্ধুকে আমন্ত্রণ পাঠান' : 'Directly Invite a Friend'}
              </h2>
              <p className="text-xs text-stone-500 mt-1">
                {isBn ? 'বন্ধুর নাম ও ইমেইল/ফোন দিন। তাৎক্ষণিক আমন্ত্রণ চলে যাবে।' : 'Enter friend details to send an instant invitation.'}
              </p>
            </div>

            {inviteSuccessToast && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{inviteSuccessToast}</span>
              </div>
            )}

            <form onSubmit={handleSendInvite} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-stone-700">
                  {isBn ? 'বন্ধুর পুরো নাম *' : "Friend's Full Name *"}
                </label>
                <input
                  type="text"
                  required
                  placeholder={isBn ? 'যেমন: তানভীর আহমেদ' : 'e.g. Tanveer Ahmed'}
                  value={friendName}
                  onChange={(e) => setFriendName(e.target.value)}
                  className="w-full text-xs p-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-stone-700">
                  {isBn ? 'ইমেইল অথবা মোবাইল নম্বর (+৮৮০) *' : "Email or Phone Number (+880) *"}
                </label>
                <input
                  type="text"
                  required
                  placeholder={isBn ? 'tanveer@example.com অথবা ০১৭...' : 'tanveer@example.com or +88017...'}
                  value={friendContact}
                  onChange={(e) => setFriendContact(e.target.value)}
                  className="w-full text-xs p-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-stone-700 flex items-center justify-between">
                  <span>{isBn ? 'ব্যক্তিগত বার্তা (ঐচ্ছিক)' : 'Personal Note (Optional)'}</span>
                  <span className="text-[10px] text-stone-400">Optional</span>
                </label>
                <textarea
                  rows={2}
                  placeholder={isBn ? 'চলো রেন্ট আ ডেট-এ চমৎকার আড্ডা ও ইভেন্টের সঙ্গী খুঁজে নেই!' : 'Hey! Check out Rent a Date for thoughtful social companions in Dhaka!'}
                  value={customNote}
                  onChange={(e) => setCustomNote(e.target.value)}
                  className="w-full text-xs p-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-bold rounded-xl transition-all shadow-sm hover:shadow-md cursor-pointer flex items-center justify-center gap-2"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isBn ? 'আমন্ত্রণ পাঠান (+৳৫০০ ক্রেডিট আনলক)' : 'Send Invite (Unlock ৳500 Credits)'}</span>
              </button>
            </form>
          </div>

          {/* Reward Rules & Terms Card */}
          <div className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-xs space-y-4">
            <h3 className="font-serif text-base font-bold text-stone-900 flex items-center gap-2">
              <Info className="w-4 h-4 text-[#721C38]" />
              <span>{isBn ? 'রেফারেল নীতি ও ক্রেডিট ব্যবহার' : 'Referral Rules & Conditions'}</span>
            </h3>

            <div className="space-y-3 text-xs text-stone-600">
              <div className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  <strong>{isBn ? '১ ক্রেডিট = ১ টাকা:' : '1 Credit = ৳1 BDT:'}</strong>{' '}
                  {isBn ? 'অর্জিত ক্রেডিট বুকিংয়ের সময় সরাসরি ডিসকাউন্ট হিসেবে প্রযোজ্য।' : 'Credits are applied directly at checkout as monetary booking discounts.'}
                </span>
              </div>

              <div className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  <strong>{isBn ? 'ভেরিফিকেশন শর্ত:' : 'Profile Verification Required:'}</strong>{' '}
                  {isBn ? 'বন্ধু তার প্রোফাইলে লাইভ সেলফি বা এনআইডি/পাসপোর্ট যাচাই করলেই ক্রেডিট আনলক হয়।' : 'Reward unlocks automatically when the friend completes face or ID verification.'}
                </span>
              </div>

              <div className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  <strong>{isBn ? 'কোনো মেয়াদোত্তীর্ণের তারিখ নেই:' : 'Never Expire:'}</strong>{' '}
                  {isBn ? 'আপনার ওয়ালেটের ক্রেডিট আজীবন সচল থাকবে।' : 'Credits in your wallet remain valid indefinitely with no expiration.'}
                </span>
              </div>

              <div className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  <strong>{isBn ? 'সীমাহীন আমন্ত্রণ:' : 'Unlimited Referrals:'}</strong>{' '}
                  {isBn ? 'যত ইচ্ছা বন্ধুকে আমন্ত্রণ জানাতে পারেন, কোনো সর্বোচ্চ সীমা নেই।' : 'You can invite as many friends as you want across Dhaka.'}
                </span>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Referrals Tracking & Verification Status Table */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-stone-200/90 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-serif text-xl font-bold text-stone-900 flex items-center gap-2">
              <span>{isBn ? 'আমন্ত্রিত বন্ধুদের তালিকা ও স্ট্যাটাস' : 'Invited Friends & Verification Status'}</span>
              <span className="text-xs font-sans font-bold bg-stone-100 text-stone-700 px-2 py-0.5 rounded-full">
                {referrals.length}
              </span>
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              {isBn ? 'আমন্ত্রিত বন্ধুদের ভেরিফিকেশন অগ্রগতি পর্যবেক্ষণ করুন এবং রিমাইন্ডার পাঠান।' : 'Track profile verification progress and send reminders to friends.'}
            </p>
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-stone-100 rounded-xl shrink-0">
            <button
              type="button"
              onClick={() => setFilterTab('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                filterTab === 'all'
                  ? 'bg-white text-stone-900 shadow-2xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {isBn ? 'সকল' : 'All'} ({referrals.length})
            </button>

            <button
              type="button"
              onClick={() => setFilterTab('verified')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                filterTab === 'verified'
                  ? 'bg-white text-stone-900 shadow-2xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {isBn ? 'ভেরিফাইড' : 'Verified'} ({stats.verifiedCount})
            </button>

            <button
              type="button"
              onClick={() => setFilterTab('pending')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                filterTab === 'pending'
                  ? 'bg-white text-stone-900 shadow-2xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {isBn ? 'অপেক্ষমাণ' : 'Pending'} ({stats.pendingCount})
            </button>
          </div>
        </div>

        {/* List of Referrals */}
        {filteredReferrals.length === 0 ? (
          <div className="text-center py-12 text-stone-400 space-y-2">
            <Users className="w-10 h-10 mx-auto text-stone-300" />
            <p className="text-xs font-semibold text-stone-600">
              {isBn ? 'এই ক্যাটাগরিতে কোনো রেফারেল রেকর্ড নেই।' : 'No referral records match this filter.'}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-stone-100 border border-stone-200/80 rounded-2xl overflow-hidden">
            {filteredReferrals.map((item) => {
              const isVerified = item.status === 'verified';
              return (
                <div 
                  key={item.id} 
                  className={`p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-colors ${
                    isVerified ? 'bg-white hover:bg-emerald-50/20' : 'bg-stone-50/50 hover:bg-stone-50'
                  }`}
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-bold text-sm shrink-0 shadow-2xs ${
                      isVerified 
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                        : 'bg-amber-100 text-amber-900 border border-amber-300'
                    }`}>
                      {item.friendName.charAt(0)}
                    </div>
                    <div className="space-y-0.5 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-xs text-stone-900 truncate">
                          {item.friendName}
                        </span>
                        {isVerified ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full border border-emerald-300">
                            <ShieldCheck className="w-3 h-3 text-emerald-600" />
                            <span>{isBn ? 'প্রোফাইল ভেরিফাইড (+৳৫০০ অর্জিত)' : 'Profile Verified (+৳500 Rewarded)'}</span>
                          </span>
                        ) : item.status === 'registered' ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full border border-amber-200">
                            <Clock className="w-3 h-3 text-amber-600" />
                            <span>{isBn ? 'নিবন্ধিত · ভেরিফিকেশন বাকি' : 'Registered · Verification Pending'}</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-stone-600 bg-stone-200 px-2 py-0.5 rounded-full">
                            <Send className="w-3 h-3 text-stone-500" />
                            <span>{isBn ? 'আমন্ত্রণ পাঠানো হয়েছে' : 'Invited'}</span>
                          </span>
                        )}
                      </div>

                      <div className="text-[11px] text-stone-500 flex items-center gap-2 flex-wrap">
                        {item.friendEmail && <span>{item.friendEmail}</span>}
                        {item.friendPhone && (
                          <>
                            <span>·</span>
                            <span>{item.friendPhone}</span>
                          </>
                        )}
                        <span>·</span>
                        <span>{isBn ? 'আমন্ত্রণ:' : 'Invited:'} {formatDate(item.invitedAt)}</span>
                        {item.verifiedAt && (
                          <>
                            <span>·</span>
                            <span className="text-emerald-700 font-medium">
                              {isBn ? 'ভেরিফাইড:' : 'Verified:'} {formatDate(item.verifiedAt)}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions & Status on Right */}
                  <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                    {isVerified ? (
                      <div className="text-right">
                        <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-xl flex items-center gap-1">
                          <Check className="w-3.5 h-3.5" />
                          <span>+৳{item.rewardCredits} {isBn ? 'ক্রেডিট জমা' : 'Credited'}</span>
                        </span>
                      </div>
                    ) : (
                      <>
                        <button
                          type="button"
                          onClick={() => handleSendReminderPing(item.id, item.friendName)}
                          className="px-3 py-1.5 text-xs font-semibold text-stone-700 hover:text-stone-900 bg-white hover:bg-stone-100 border border-stone-200 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
                          title={isBn ? 'বন্ধুকে ভেরিফিকেশন রিমাইন্ডার পাঠান' : 'Send verification reminder ping'}
                        >
                          <BellRing className="w-3.5 h-3.5 text-amber-600" />
                          <span>{item.reminderSentAt ? (isBn ? 'স্মারক প্রেরিত' : 'Reminded') : (isBn ? 'রিমাইন্ডার পাঠান' : 'Remind Friend')}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleSimulateVerification(item.id, item.friendName)}
                          className="px-3 py-1.5 text-xs font-bold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
                          title={isBn ? 'টেস্টের জন্য ভেরিফিকেশন সম্পন্ন করুন' : 'Simulate friend verification for test'}
                        >
                          <ScanFace className="w-3.5 h-3.5 text-emerald-700" />
                          <span>{isBn ? 'ভেরিফাই টেস্ট' : 'Simulate Verify'}</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Credit Transactions Ledger */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-stone-200/90 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-serif text-lg font-bold text-stone-900">
              {isBn ? 'ওয়ালেট ক্রেডিট হিস্ট্রি ও লেনদেন' : 'Wallet Credits Ledger & Transactions'}
            </h3>
            <p className="text-xs text-stone-500">
              {isBn ? 'রেফারেল বোনাস ও বুকিংয়ে ক্রেডিট ব্যবহারের বিবরণী।' : 'Breakdown of earned bonuses and redeemed booking credits.'}
            </p>
          </div>
          <div className="text-right">
            <span className="text-xs text-stone-500">{isBn ? 'বর্তমান স্থিতি:' : 'Current Balance:'}</span>
            <div className="font-serif font-bold text-base text-[#721C38]">{formatBDT(walletCredits)}</div>
          </div>
        </div>

        {creditTransactions.length === 0 ? (
          <div className="text-center py-8 text-xs text-stone-400">
            {isBn ? 'কোনো পূর্ববর্তী লেনদেন নেই।' : 'No credit transactions yet.'}
          </div>
        ) : (
          <div className="divide-y divide-stone-100 border border-stone-200/80 rounded-2xl overflow-hidden">
            {creditTransactions.map((tx) => {
              const isPositive = tx.amount > 0;
              return (
                <div key={tx.id} className="p-3.5 sm:p-4 flex items-center justify-between gap-4 bg-white hover:bg-stone-50/50 transition-colors">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                      isPositive ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-[#721C38]'
                    }`}>
                      {isPositive ? <TrendingUp className="w-4 h-4" /> : <Coins className="w-4 h-4" />}
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-stone-900 truncate">
                        {isBn ? tx.descriptionBn || tx.description : tx.description}
                      </div>
                      <div className="text-[10px] text-stone-400">
                        {formatDate(tx.timestamp)} · {isBn ? 'ব্যালেন্স:' : 'Balance:'} {formatBDT(tx.balanceAfter)}
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className={`font-mono text-xs font-bold ${
                      isPositive ? 'text-emerald-700' : 'text-[#721C38]'
                    }`}>
                      {isPositive ? `+৳${tx.amount}` : `-৳${Math.abs(tx.amount)}`}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
};
