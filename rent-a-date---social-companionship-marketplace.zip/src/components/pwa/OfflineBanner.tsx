import React, { useState, useEffect } from 'react';
import { WifiOff, RefreshCw, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const OfflineBanner: React.FC = () => {
  const { language } = useApp();
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [showReconnected, setShowReconnected] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOffline(false);
      setShowReconnected(true);
      setTimeout(() => setShowReconnected(false), 3500);
    };

    const handleOffline = () => {
      setIsOffline(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (showReconnected) {
    return (
      <div className="fixed top-0 left-0 right-0 z-50 bg-emerald-600 text-white text-xs font-semibold py-1.5 px-3 text-center flex items-center justify-center gap-2 shadow-md animate-in slide-in-from-top">
        <CheckCircle2 className="w-4 h-4 text-emerald-200" />
        <span>{language === 'bn' ? 'ইন্টারনেট সংযোগ পুনরায় চালু হয়েছে!' : 'Back Online! Connection restored.'}</span>
      </div>
    );
  }

  if (!isOffline) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-amber-600 text-white text-xs font-semibold py-2 px-3 text-center flex items-center justify-center gap-2 shadow-md animate-in slide-in-from-top">
      <WifiOff className="w-4 h-4 text-amber-200 shrink-0" />
      <span>
        {language === 'bn' 
          ? 'আপনি বর্তমানে অফলাইনে আছেন — ক্যাশ করা ডেটা ও ভেরিফিকেশন টেস্ট করা যাচ্ছে।'
          : 'You are currently offline — using cached PWA shell and offline test data.'}
      </span>
      <button 
        onClick={() => window.location.reload()}
        className="ml-2 px-2 py-0.5 rounded bg-black/20 hover:bg-black/30 text-white font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
      >
        <RefreshCw className="w-3 h-3" />
        <span>{language === 'bn' ? 'রিফ্রেশ' : 'Retry'}</span>
      </button>
    </div>
  );
};
