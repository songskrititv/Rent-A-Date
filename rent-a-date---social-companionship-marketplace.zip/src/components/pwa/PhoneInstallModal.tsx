import React, { useState } from 'react';
import { 
  Smartphone, 
  X, 
  Copy, 
  Check, 
  Share2, 
  ExternalLink, 
  ShieldCheck, 
  Sparkles, 
  Download, 
  ArrowRight,
  CheckCircle2,
  Camera,
  WifiOff,
  Flame
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface PhoneInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  deferredPrompt?: any;
  onInstallDirectly?: () => void;
}

export const PhoneInstallModal: React.FC<PhoneInstallModalProps> = ({
  isOpen,
  onClose,
  deferredPrompt,
  onInstallDirectly
}) => {
  const { language } = useApp();
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'android' | 'ios' | 'features'>('android');

  if (!isOpen) return null;

  // The actual live shared URL or current origin
  const liveUrl = typeof window !== 'undefined' 
    ? (window.location.origin.includes('run.app') ? window.location.origin : 'https://ais-pre-dky5rqq332fzy7mth275l4-664741093126.asia-southeast1.run.app')
    : 'https://ais-pre-dky5rqq332fzy7mth275l4-664741093126.asia-southeast1.run.app';

  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=6&color=72-28-56&bgcolor=255-255-255&data=${encodeURIComponent(liveUrl)}`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(liveUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleWebShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Rent a Date - Social Companionship',
          text: 'Check out Rent a Date on mobile with Face Verification & Referral Credits!',
          url: liveUrl
        });
      } catch (err) {
        console.log('Share canceled or failed:', err);
      }
    } else {
      handleCopyLink();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-stone-900/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="phone-install-title"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-[#721C38] via-[#881337] to-[#58152B] p-5 sm:p-6 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-rose-200 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center shadow-inner">
              <Smartphone className="w-6 h-6 text-rose-100" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-200 border border-emerald-400/30">
                  {language === 'bn' ? 'অ্যান্ড্রয়েড ও আইওএস' : 'Android & iOS'}
                </span>
                <span className="text-[11px] font-medium text-rose-200">PWA Ready</span>
              </div>
              <h2 id="phone-install-title" className="text-xl sm:text-2xl font-serif font-bold text-white mt-1">
                {language === 'bn' ? 'ফোনে ইনস্টল ও টেস্ট করুন' : 'Install & Test on Phone'}
              </h2>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-stone-200 bg-stone-50/80 px-4 pt-2">
          <button
            onClick={() => setActiveTab('android')}
            className={`flex-1 py-2.5 px-3 text-xs sm:text-sm font-semibold rounded-t-xl transition-all border-b-2 flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'android'
                ? 'border-[#721C38] text-[#721C38] bg-white shadow-2xs'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>
            <span>Android (Chrome)</span>
          </button>
          <button
            onClick={() => setActiveTab('ios')}
            className={`flex-1 py-2.5 px-3 text-xs sm:text-sm font-semibold rounded-t-xl transition-all border-b-2 flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'ios'
                ? 'border-[#721C38] text-[#721C38] bg-white shadow-2xs'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-blue-500 inline-block"></span>
            <span>iPhone (Safari)</span>
          </button>
          <button
            onClick={() => setActiveTab('features')}
            className={`flex-1 py-2.5 px-3 text-xs sm:text-sm font-semibold rounded-t-xl transition-all border-b-2 flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'features'
                ? 'border-[#721C38] text-[#721C38] bg-white shadow-2xs'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>{language === 'bn' ? 'সুবিধাসমূহ' : 'Benefits'}</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">

          {/* Quick Direct Install Trigger (if browser supported beforeinstallprompt) */}
          {deferredPrompt && (
            <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between gap-3 shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-emerald-950">
                    {language === 'bn' ? 'এই ব্রাউজারে ইনস্টল সমর্থিত' : 'Direct Installation Ready'}
                  </h4>
                  <p className="text-xs text-emerald-800">
                    {language === 'bn' ? 'এক ক্লিকে আপনার হোমস্ক্রিনে অ্যাপটি যোগ করুন' : 'Add directly to your device home screen with 1 tap'}
                  </p>
                </div>
              </div>
              <button
                onClick={onInstallDirectly}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer"
              >
                <span>{language === 'bn' ? 'ইনস্টল করুন' : 'Install Now'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Main QR Code & Live Link Section */}
          <div className="bg-[#FAF7F5] rounded-2xl p-4 sm:p-5 border border-stone-200 flex flex-col sm:flex-row items-center gap-5">
            {/* QR Card */}
            <div className="bg-white p-3 rounded-2xl shadow-md border border-stone-200 flex flex-col items-center shrink-0">
              <div className="relative group">
                <img
                  src={qrImageUrl}
                  alt="Scan QR code to install on phone"
                  className="w-44 h-44 object-contain rounded-lg"
                  loading="eager"
                />
                <div className="absolute inset-0 bg-[#721C38]/5 rounded-lg pointer-events-none"></div>
              </div>
              <span className="text-[11px] font-semibold text-stone-500 mt-2 flex items-center gap-1">
                <Camera className="w-3.5 h-3.5 text-[#721C38]" />
                {language === 'bn' ? 'ক্যামেরা দিয়ে স্ক্যান করুন' : 'Scan with Phone Camera'}
              </span>
            </div>

            {/* Actions & Instructions */}
            <div className="flex-1 w-full space-y-3">
              <div>
                <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
                  {language === 'bn' ? 'অ্যাপ লিংক' : 'App Access URL'}
                </span>
                <div className="mt-1 flex items-center gap-2">
                  <div className="flex-1 px-3 py-2 bg-white rounded-xl border border-stone-200 text-xs font-mono text-stone-700 truncate shadow-2xs">
                    {liveUrl}
                  </div>
                  <button
                    onClick={handleCopyLink}
                    className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shrink-0 ${
                      copied 
                        ? 'bg-emerald-600 text-white' 
                        : 'bg-[#721C38] hover:bg-[#58152B] text-white shadow-xs'
                    }`}
                    title="Copy URL"
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? (language === 'bn' ? 'কপি হয়েছে' : 'Copied!') : (language === 'bn' ? 'কপি' : 'Copy')}</span>
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  onClick={handleWebShare}
                  className="px-3 py-1.5 rounded-xl border border-stone-300 hover:bg-white text-stone-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Share2 className="w-3.5 h-3.5 text-[#721C38]" />
                  <span>{language === 'bn' ? 'শেয়ার করুন' : 'Share to Phone'}</span>
                </button>
                <a
                  href={`https://wa.me/?text=${encodeURIComponent(`Check out Rent a Date on mobile: ${liveUrl}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-xl border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>WhatsApp</span>
                </a>
                <a
                  href={liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-xl border border-stone-200 hover:bg-white text-stone-600 text-xs font-semibold flex items-center gap-1.5 transition-colors ml-auto"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'ট্যাবে খুলুন' : 'Open Tab'}</span>
                </a>
              </div>

              <p className="text-[11px] text-stone-500 italic">
                {language === 'bn' 
                  ? 'টিপস: ফোনের গুগল ক্যামেরা বা ক্রোম ব্রাউজার দিয়ে কিউআর কোড স্ক্যান করলে সরাসরি অ্যাপ ওপেন হবে।'
                  : 'Tip: Point your phone camera or Google Chrome scanner at the QR code to open the app directly.'}
              </p>
            </div>
          </div>

          {/* Android Step-by-Step Guide */}
          {activeTab === 'android' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-600 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-emerald-600" />
                <span>
                  {language === 'bn' 
                    ? 'অ্যান্ড্রয়েড ফোনে ৩টি সহজ ধাপে ইনস্টল করুন:' 
                    : 'How to Install on Android (Chrome / Edge):'}
                </span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-2xl bg-white border border-stone-200 shadow-2xs space-y-2">
                  <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center">
                    1
                  </div>
                  <h5 className="text-xs font-bold text-stone-900">
                    {language === 'bn' ? 'ক্রোমে লিঙ্কটি খুলুন' : 'Open in Chrome'}
                  </h5>
                  <p className="text-[11px] text-stone-600 leading-relaxed">
                    {language === 'bn'
                      ? 'কিউআর কোড স্ক্যান করে অথবা লিংক কপি করে Google Chrome ব্রাউজারে পেস্ট করুন।'
                      : 'Scan QR code or paste URL into Google Chrome or Edge.'}
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-white border border-stone-200 shadow-2xs space-y-2">
                  <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center">
                    2
                  </div>
                  <h5 className="text-xs font-bold text-stone-900">
                    {language === 'bn' ? 'মেনু থেকে ইনস্টল চাপুন' : 'Tap "Install App"'}
                  </h5>
                  <p className="text-[11px] text-stone-600 leading-relaxed">
                    {language === 'bn'
                      ? 'পপ-আপে "Install" অথবা ক্রোমের উপরে ডানদিকের তিনটি বিন্দু (⋮) চেপে "Add to Home screen" চাপুন।'
                      : 'Tap the bottom "Install" banner or tap Chrome menu (⋮) -> "Add to Home screen".'}
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-white border border-stone-200 shadow-2xs space-y-2">
                  <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center">
                    3
                  </div>
                  <h5 className="text-xs font-bold text-stone-900">
                    {language === 'bn' ? 'হোমস্ক্রিন থেকে চালান' : 'Launch like Native App'}
                  </h5>
                  <p className="text-[11px] text-stone-600 leading-relaxed">
                    {language === 'bn'
                      ? 'অ্যাপের আইকন আপনার ফোনে তৈরি হবে। কোনো ব্রাউজার বার ছাড়া ফুল-স্ক্রিনে চলবে।'
                      : 'Rent a Date icon appears on home screen. Opens standalone without address bar.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* iOS Safari Step-by-Step Guide */}
          {activeTab === 'ios' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-600 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-blue-600" />
                <span>
                  {language === 'bn' 
                    ? 'আইফোনে (Safari) ইনস্টল করার নিয়ম:' 
                    : 'How to Install on iPhone (Safari):'}
                </span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-2xl bg-white border border-stone-200 shadow-2xs space-y-2">
                  <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-800 font-bold text-xs flex items-center justify-center">
                    1
                  </div>
                  <h5 className="text-xs font-bold text-stone-900">
                    {language === 'bn' ? 'সাফারিতে খুলুন' : 'Open in Safari'}
                  </h5>
                  <p className="text-[11px] text-stone-600 leading-relaxed">
                    {language === 'bn'
                      ? 'আইফোনে শুধুমাত্র Safari ব্রাউজারে লিংকটি খুলুন।'
                      : 'Open the URL specifically in Apple Safari browser on iOS.'}
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-white border border-stone-200 shadow-2xs space-y-2">
                  <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-800 font-bold text-xs flex items-center justify-center">
                    2
                  </div>
                  <h5 className="text-xs font-bold text-stone-900">
                    {language === 'bn' ? 'শেয়ার বাটন চাপুন' : 'Tap Share Button'}
                  </h5>
                  <p className="text-[11px] text-stone-600 leading-relaxed">
                    {language === 'bn'
                      ? 'নিচে থাকা শেয়ার (Share) আইকন (স্কয়ারের সাথে তীর) চাপুন।'
                      : 'Tap the Share icon at the bottom of the screen (square with arrow).'}
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-white border border-stone-200 shadow-2xs space-y-2">
                  <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-800 font-bold text-xs flex items-center justify-center">
                    3
                  </div>
                  <h5 className="text-xs font-bold text-stone-900">
                    {language === 'bn' ? 'Add to Home Screen' : 'Add to Home Screen'}
                  </h5>
                  <p className="text-[11px] text-stone-600 leading-relaxed">
                    {language === 'bn'
                      ? 'তালিকা থেকে স্ক্রল করে "Add to Home Screen" নির্বাচন করে "Add" চাপুন।'
                      : 'Scroll down and tap "Add to Home Screen", then tap "Add" in top right.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Key PWA & Testing Benefits */}
          {activeTab === 'features' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-600">
                {language === 'bn' ? 'মোবাইলে ইনস্টল করার বিশেষ সুবিধাসমূহ' : 'Native Mobile Features Tested:'}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-white rounded-xl border border-stone-200 flex items-start gap-2.5">
                  <Camera className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-stone-900 block font-semibold">
                      {language === 'bn' ? 'রিয়েল ক্যামেরা ফেস ভেরিফিকেশন' : 'Real Camera Face Verification'}
                    </strong>
                    <span className="text-stone-600 text-[11px]">
                      {language === 'bn'
                        ? 'ফোনের ফ্রন্ট সেলফি ক্যামেরা দিয়ে সরাসরি মুখমণ্ডল স্ক্যান ও সেলফি আপলোড করুন।'
                        : 'Use real front selfie camera hardware to complete biometric verification.'}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-white rounded-xl border border-stone-200 flex items-start gap-2.5">
                  <Flame className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-stone-900 block font-semibold">
                      {language === 'bn' ? 'ফুলস্ক্রিন অ্যাপ ফিল' : 'Standalone App Feel'}
                    </strong>
                    <span className="text-stone-600 text-[11px]">
                      {language === 'bn'
                        ? 'ব্রাউজারের অ্যাড্রেস বার ছাড়াই দেশীয় ব্র্যান্ডেড থিমে চলে।'
                        : 'No browser search bar or bottom navigation cluttering your view.'}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-white rounded-xl border border-stone-200 flex items-start gap-2.5">
                  <WifiOff className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-stone-900 block font-semibold">
                      {language === 'bn' ? 'অফলাইন ও ক্যাশ সাপোর্ট' : 'Offline Service Worker'}
                    </strong>
                    <span className="text-stone-600 text-[11px]">
                      {language === 'bn'
                        ? 'দুর্বল নেটওয়ার্কেও অ্যাপের ইউআই দ্রুত লোড হবে এবং কাজ করবে।'
                        : 'Cached assets load quickly even in unstable mobile network conditions.'}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-white rounded-xl border border-stone-200 flex items-start gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-[#721C38] shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-stone-900 block font-semibold">
                      {language === 'bn' ? 'রেফারেল ও ওটিপি টেস্ট' : 'OTP & Referral Program'}
                    </strong>
                    <span className="text-stone-600 text-[11px]">
                      {language === 'bn'
                        ? 'বন্ধু ইনভাইট করে ৳৫০০ ক্রেডিট অর্জন এবং বুকিংয়ে খরচ করার সম্পূর্ণ প্রবাহ।'
                        : 'Invite friends, earn ৳500 verification credits, and redeem directly.'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 bg-stone-50 border-t border-stone-200 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-stone-500">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{language === 'bn' ? 'নিরাপদ ও কোনো ডাউনলোডের ঝুঁকি নেই' : 'Verified PWA Standards'}</span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-stone-900 hover:bg-black text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
          >
            {language === 'bn' ? 'ঠিক আছে / বন্ধ করুন' : 'Done / Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
