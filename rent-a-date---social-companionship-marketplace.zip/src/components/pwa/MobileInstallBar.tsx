import React, { useState, useEffect } from 'react';
import { Download, X, Smartphone, Sparkles, Check } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface MobileInstallBarProps {
  onOpenPhoneModal: () => void;
  deferredPrompt: any;
  setDeferredPrompt: (prompt: any) => void;
}

export const MobileInstallBar: React.FC<MobileInstallBarProps> = ({
  onOpenPhoneModal,
  deferredPrompt,
  setDeferredPrompt
}) => {
  const { language } = useApp();
  const [isStandalone, setIsStandalone] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);
  const [installedSuccess, setInstalledSuccess] = useState(false);
  const [isMobileDevice, setIsMobileDevice] = useState(false);

  useEffect(() => {
    // Check if already in standalone PWA mode
    const checkStandalone = () => {
      const isStandaloneMode = 
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone === true;
      setIsStandalone(isStandaloneMode);
    };

    checkStandalone();

    // Check device type
    const checkMobile = () => {
      const ua = navigator.userAgent || '';
      const isMobileUA = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua);
      const isSmallScreen = window.innerWidth <= 768;
      setIsMobileDevice(isMobileUA || isSmallScreen);
    };

    checkMobile();

    // Check session dismissal
    if (sessionStorage.getItem('pwa_install_dismissed') === 'true') {
      setIsDismissed(true);
    }

    // App installed event
    const handleAppInstalled = () => {
      setInstalledSuccess(true);
      setDeferredPrompt(null);
      setTimeout(() => setIsDismissed(true), 4000);
    };

    window.addEventListener('appinstalled', handleAppInstalled);
    return () => {
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, [setDeferredPrompt]);

  const handleDismiss = () => {
    setIsDismissed(true);
    sessionStorage.setItem('pwa_install_dismissed', 'true');
  };

  const handleTriggerInstall = async () => {
    if (deferredPrompt) {
      try {
        setIsInstalling(true);
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') {
          setInstalledSuccess(true);
          setDeferredPrompt(null);
        }
      } catch (err) {
        console.warn('Install prompt error:', err);
        onOpenPhoneModal();
      } finally {
        setIsInstalling(false);
      }
    } else {
      // Open detailed step-by-step modal
      onOpenPhoneModal();
    }
  };

  // If already running inside installed standalone app, or dismissed, do not render
  if (isStandalone || isDismissed) {
    return null;
  }

  // Show if either deferred prompt is ready or we are on mobile or small screen
  if (!deferredPrompt && !isMobileDevice) {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 p-2 sm:p-3 bg-gradient-to-r from-stone-900/95 via-[#58152B]/95 to-stone-900/95 backdrop-blur-md text-white border-t border-rose-900/40 shadow-2xl animate-in slide-in-from-bottom duration-300">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-3 px-2">
        {/* App Info */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="relative shrink-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#721C38] to-rose-600 flex items-center justify-center shadow-md border border-rose-400/30 overflow-hidden">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h4 className="text-xs sm:text-sm font-bold text-white truncate">
                {language === 'bn' ? 'ফোনে ইনস্টল করুন' : 'Install Rent a Date'}
              </h4>
              <span className="text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.2 rounded-full hidden sm:inline-block">
                PWA
              </span>
            </div>
            <p className="text-[11px] text-rose-200/90 truncate">
              {installedSuccess
                ? (language === 'bn' ? 'সফলভাবে ইনস্টল সম্পন্ন হয়েছে!' : 'App installed successfully!')
                : (language === 'bn' ? 'ক্যামেরা ফেস ভেরিফিকেশন ও অফলাইন টেস্ট করুন' : 'Test native camera face verification & offline mode')}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 shrink-0">
          {installedSuccess ? (
            <div className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600/30 border border-emerald-400/40 text-emerald-200 text-xs font-semibold">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>{language === 'bn' ? 'ইনস্টল হয়েছে' : 'Installed'}</span>
            </div>
          ) : (
            <button
              onClick={handleTriggerInstall}
              disabled={isInstalling}
              className="px-3.5 sm:px-4 py-1.5 sm:py-2 bg-gradient-to-r from-rose-600 to-[#721C38] hover:from-rose-500 hover:to-[#881337] active:scale-95 text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-1.5 border border-rose-400/30 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>
                {deferredPrompt 
                  ? (language === 'bn' ? 'ইনস্টল করুন' : 'Install App')
                  : (language === 'bn' ? 'কীভাবে ইনস্টল করবেন' : 'How to Install')}
              </span>
            </button>
          )}

          <button
            onClick={handleDismiss}
            className="p-1.5 text-stone-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
            aria-label="Dismiss install banner"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
