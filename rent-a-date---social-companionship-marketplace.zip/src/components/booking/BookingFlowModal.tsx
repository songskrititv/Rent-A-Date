import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ProviderService, PaymentMethod } from '../../types';
import { formatBDT, MANDATORY_CONSENT_NOTICE } from '../../utils/formatters';
import { DHAKA_SAFE_VENUES, ACTIVE_PROMO_CODES, SafeVenue, PromoCode } from '../../data/venues';
import { 
  X, 
  Calendar, 
  Clock, 
  MapPin, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight, 
  CreditCard,
  AlertCircle,
  Lock,
  Sparkles,
  Smartphone,
  Tag,
  Check,
  Building,
  HeartHandshake,
  Gift,
  Wallet
} from 'lucide-react';

interface BookingFlowModalProps {
  serviceId: string;
  onClose: () => void;
  onSuccess: (bookingId: string) => void;
}

export const BookingFlowModal: React.FC<BookingFlowModalProps> = ({
  serviceId,
  onClose,
  onSuccess
}) => {
  const { 
    services, 
    allUsers, 
    createBooking, 
    processPayment, 
    platformConfig,
    isAuthenticated,
    setAuthModalOpen,
    setAuthModalMode,
    language,
    walletCredits,
    deductCreditsForBooking
  } = useApp();

  const isBn = language === 'bn';

  const service = services.find(s => s.id === serviceId);
  const provider = allUsers.find(u => u.id === service?.providerId);

  // Booking form state
  const [scheduledDate, setScheduledDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 2);
    return d.toISOString().split('T')[0];
  });
  const [scheduledTime, setScheduledTime] = useState('16:00');
  const [durationHours, setDurationHours] = useState(service?.durationHours || 2);
  
  // Safe venue selector
  const [selectedVenueId, setSelectedVenueId] = useState<string>('vn-1');
  const [customVenue, setCustomVenue] = useState<string>('');
  const [specialNotes, setSpecialNotes] = useState('');
  const [consentAcknowledged, setConsentAcknowledged] = useState(false);

  // Promo code state
  const [promoInput, setPromoInput] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(null);
  const [promoMessage, setPromoMessage] = useState<{ text: string; isError: boolean } | null>(null);

  // Referral Wallet credits state
  const [useWalletCredits, setUseWalletCredits] = useState(false);

  // Step state: 1 = Details & Schedule, 2 = Review & Consent, 3 = Simulated Payment Checkout, 4 = Confirmed
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [createdBookingId, setCreatedBookingId] = useState<string | null>(null);

  // Payment method simulation
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('bkash');
  const [accountNumber, setAccountNumber] = useState('01712000000');
  const [demoPin, setDemoPin] = useState('1234');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);

  if (!service || !provider) return null;

  const currentSafeVenue = DHAKA_SAFE_VENUES.find(v => v.id === selectedVenueId);
  const finalMeetupVenue = selectedVenueId === 'custom' 
    ? (customVenue || 'Custom Public Venue in Dhaka')
    : `${currentSafeVenue?.name} (${currentSafeVenue?.address})`;

  // Cost calculation with promo discount and referral credits
  const unitPrice = service.price;
  const rawSubtotal = service.pricingUnit === 'hourly' 
    ? unitPrice * durationHours 
    : unitPrice;

  let promoDiscountAmount = 0;
  if (appliedPromo) {
    if (appliedPromo.discountType === 'fixed') {
      promoDiscountAmount = appliedPromo.discountValue;
    } else {
      promoDiscountAmount = Math.round((rawSubtotal * appliedPromo.discountValue) / 100);
    }
  }

  const subtotalAfterPromo = Math.max(0, rawSubtotal - promoDiscountAmount);
  
  // Available referral credit discount (up to wallet balance and booking subtotal)
  const appliedCreditDiscount = useWalletCredits ? Math.min(walletCredits, subtotalAfterPromo) : 0;
  const discountAmount = promoDiscountAmount + appliedCreditDiscount;

  const subtotalAfterDiscount = Math.max(0, subtotalAfterPromo - appliedCreditDiscount);
  const platformFee = Math.round(subtotalAfterDiscount * platformConfig.commissionRate);
  const totalPayable = subtotalAfterDiscount;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    const found = ACTIVE_PROMO_CODES.find(p => p.code.toUpperCase() === promoInput.trim().toUpperCase());
    if (found) {
      if (rawSubtotal < found.minAmount) {
        setPromoMessage({ text: `Minimum booking value of ${formatBDT(found.minAmount)} required for ${found.code}`, isError: true });
      } else {
        setAppliedPromo(found);
        setPromoMessage({ text: `Coupon ${found.code} applied! Saved ${found.discountType === 'percentage' ? `${found.discountValue}%` : formatBDT(found.discountValue)}`, isError: false });
      }
    } else {
      setPromoMessage({ text: 'Invalid voucher code. Try DHAKA2026 or FIRSTDATE', isError: true });
    }
  };

  const handleProceedToReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scheduledDate || !scheduledTime) {
      alert('Please fill out all required meeting details.');
      return;
    }
    if (selectedVenueId === 'custom' && !customVenue.trim()) {
      alert('Please provide the public establishment name and address in Dhaka.');
      return;
    }
    setStep(2);
  };

  const handleConfirmBookingRequest = () => {
    if (!isAuthenticated) {
      setAuthModalMode('signin');
      setAuthModalOpen(true);
      return;
    }

    if (!consentAcknowledged) {
      alert(isBn ? 'এগিয়ে যেতে প্ল্যাটফর্মের নীতিমালা ও সীমানা শর্তাবলীতে সম্মতি দিন।' : 'You must acknowledge the platform safety and boundary agreement to proceed.');
      return;
    }

    const booking = createBooking({
      providerId: provider.id,
      serviceId: service.id,
      scheduledDate,
      scheduledTime,
      durationHours,
      meetupLocation: finalMeetupVenue,
      venueId: selectedVenueId,
      promoCode: appliedPromo?.code,
      discountAmount,
      specialNotes
    });

    if (useWalletCredits && appliedCreditDiscount > 0) {
      deductCreditsForBooking(booking.id, appliedCreditDiscount);
    }

    setCreatedBookingId(booking.id);
    setStep(3); // proceed to demo payment checkout
  };

  const handleSimulatePayment = async () => {
    if (!createdBookingId) return;
    setIsProcessingPayment(true);

    // Simulate gateway delay
    setTimeout(async () => {
      await processPayment(createdBookingId, paymentMethod);
      setIsProcessingPayment(false);
      setStep(4);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="bg-[#FAF7F5] border-b border-stone-200 p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={provider.avatar} alt={provider.displayName} className="w-10 h-10 rounded-full object-cover border border-stone-200" />
            <div>
              <span className="text-[10px] text-stone-500 uppercase font-semibold">Reserve Experience</span>
              <h3 className="font-serif font-bold text-base text-stone-900">{service.title} with {provider.displayName}</h3>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-stone-400 hover:text-stone-700 rounded-full cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator */}
        <div className="bg-stone-50 border-b border-stone-200 px-6 py-2.5 flex items-center justify-between text-xs">
          <div className={`flex items-center gap-1.5 font-medium ${step >= 1 ? 'text-[#721C38] font-semibold' : 'text-stone-400'}`}>
            <span className="w-5 h-5 rounded-full bg-stone-200 flex items-center justify-center text-[10px] font-bold">1</span>
            <span>Date & Safe Venue</span>
          </div>
          <span className="text-stone-300">→</span>
          <div className={`flex items-center gap-1.5 font-medium ${step >= 2 ? 'text-[#721C38] font-semibold' : 'text-stone-400'}`}>
            <span className="w-5 h-5 rounded-full bg-stone-200 flex items-center justify-center text-[10px] font-bold">2</span>
            <span>Safety Consent</span>
          </div>
          <span className="text-stone-300">→</span>
          <div className={`flex items-center gap-1.5 font-medium ${step >= 3 ? 'text-[#721C38] font-semibold' : 'text-stone-400'}`}>
            <span className="w-5 h-5 rounded-full bg-stone-200 flex items-center justify-center text-[10px] font-bold">3</span>
            <span>Escrow Checkout</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {/* STEP 1: SCHEDULE & CURATED VENUE */}
          {step === 1 && (
            <form onSubmit={handleProceedToReview} className="p-5 sm:p-6 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Scheduled Date */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-stone-700 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-[#721C38]" />
                    Select Date
                  </label>
                  <input
                    type="date"
                    required
                    min={new Date().toISOString().split('T')[0]}
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                  />
                </div>

                {/* Scheduled Time */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-stone-700 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#721C38]" />
                    Select Start Time
                  </label>
                  <input
                    type="time"
                    required
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                  />
                </div>

              </div>

              {/* Companion Available Time Slots quick buttons */}
              {provider.availableTimeSlots && provider.availableTimeSlots.length > 0 && (
                <div className="space-y-1.5 bg-rose-50/40 p-3 rounded-xl border border-rose-100">
                  <label className="text-[11px] font-semibold text-stone-700 flex items-center justify-between">
                    <span>{provider.displayName}'s Available Slots for this day:</span>
                    <span className="text-[10px] text-rose-700 font-bold">Fast Auto-fill</span>
                  </label>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {provider.availableTimeSlots.map((slot, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          // convert 12-hr to 24-hr format for time input
                          const [timePart, modifier] = slot.split(' ');
                          let [hours, minutes] = timePart.split(':');
                          let h = parseInt(hours, 10);
                          if (modifier === 'PM' && h < 12) h += 12;
                          if (modifier === 'AM' && h === 12) h = 0;
                          const formatted24 = `${h.toString().padStart(2, '0')}:${minutes || '00'}`;
                          setScheduledTime(formatted24);
                        }}
                        className="px-2.5 py-1 bg-white hover:bg-rose-100/70 border border-rose-200 rounded-lg text-xs font-medium text-stone-800 transition-colors cursor-pointer"
                      >
                        {slot}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Duration Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-stone-700 flex items-center justify-between">
                  <span>Duration Option</span>
                  <span className="text-[11px] text-stone-500 font-normal">
                    Unit: {service.pricingUnit === 'hourly' ? 'Hourly rate applies' : 'Fixed session rate'}
                  </span>
                </label>
                <div className="flex gap-2">
                  {service.availableDurations.map(dur => (
                    <button
                      key={dur}
                      type="button"
                      onClick={() => setDurationHours(dur)}
                      className={`flex-1 py-2 text-xs font-medium rounded-xl border transition-all ${
                        durationHours === dur 
                          ? 'border-[#721C38] bg-rose-50 text-[#721C38] font-bold shadow-2xs' 
                          : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                      }`}
                    >
                      {dur} {dur === 1 ? 'Hour' : 'Hours'}
                    </button>
                  ))}
                </div>
              </div>

              {/* CURATED SAFE PUBLIC VENUES SELECTOR */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-stone-700 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Building className="w-3.5 h-3.5 text-[#721C38]" />
                    Verified Safe Public Venue in Dhaka
                  </span>
                  <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">
                    100% Public Standard
                  </span>
                </label>

                <select
                  value={selectedVenueId}
                  onChange={(e) => setSelectedVenueId(e.target.value)}
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                >
                  <optgroup label="Curated Verified Public Venues (Dhaka)">
                    {DHAKA_SAFE_VENUES.map(v => (
                      <option key={v.id} value={v.id}>
                        {v.name} — {v.area} ({v.category})
                      </option>
                    ))}
                  </optgroup>
                  <option value="custom">Other Public Cafe / Restaurant / Gallery (Custom Input)</option>
                </select>

                {selectedVenueId !== 'custom' && currentSafeVenue && (
                  <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs text-stone-600 space-y-1">
                    <div className="font-semibold text-stone-900 flex items-center justify-between">
                      <span>{currentSafeVenue.name} ({currentSafeVenue.area})</span>
                      <span className="text-[11px] text-amber-600 font-bold">★ {currentSafeVenue.safetyRating} Safety Rating</span>
                    </div>
                    <p className="text-[11px] text-stone-500">{currentSafeVenue.address}</p>
                    <p className="text-[10px] text-stone-400 italic">Popular for: {currentSafeVenue.popularFor}</p>
                  </div>
                )}

                {selectedVenueId === 'custom' && (
                  <div className="space-y-1 pt-1">
                    <input
                      type="text"
                      required
                      placeholder="Enter verified public venue name and address (e.g. Crimson Cup Banani, Crimson Cafe Gulshan)..."
                      value={customVenue}
                      onChange={(e) => setCustomVenue(e.target.value)}
                      className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                    />
                    <p className="text-[10px] text-rose-600">
                      Strict Policy: Never enter private houses, hotels, apartments, or unverified locations.
                    </p>
                  </div>
                )}
              </div>

              {/* Special Request Notes */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-stone-700">Special Notes or Conversation Topics (Optional)</label>
                <textarea
                  rows={2}
                  placeholder="Share any topics of interest, dietary preferences, or plans for the meetup..."
                  value={specialNotes}
                  onChange={(e) => setSpecialNotes(e.target.value)}
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38]"
                />
              </div>

              {/* Cost Summary Box */}
              <div className="bg-[#FAF7F5] rounded-2xl p-4 border border-stone-200/80 space-y-2.5">
                <div className="flex justify-between text-xs text-stone-600">
                  <span>Experience Subtotal ({service.pricingUnit === 'hourly' ? `${formatBDT(unitPrice)} × ${durationHours}h` : 'Fixed Session'})</span>
                  <span className="font-semibold text-stone-900">{formatBDT(rawSubtotal)}</span>
                </div>

                {promoDiscountAmount > 0 && (
                  <div className="flex justify-between text-xs text-emerald-700 font-semibold">
                    <span>Discount Coupon ({appliedPromo?.code})</span>
                    <span>-{formatBDT(promoDiscountAmount)}</span>
                  </div>
                )}

                {/* Referral Wallet Credits Option */}
                {walletCredits > 0 && (
                  <label className="flex items-center justify-between p-2.5 bg-rose-50/70 border border-rose-200/80 rounded-xl cursor-pointer hover:bg-rose-50 transition-colors">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={useWalletCredits}
                        onChange={(e) => setUseWalletCredits(e.target.checked)}
                        className="rounded border-stone-300 text-[#721C38] focus:ring-[#721C38] w-4 h-4 accent-[#721C38]"
                      />
                      <div className="text-xs">
                        <span className="font-semibold text-stone-900 flex items-center gap-1">
                          <Gift className="w-3.5 h-3.5 text-[#721C38]" />
                          <span>{isBn ? 'রেফারেল ক্রেডিট ব্যবহার করুন' : 'Apply Referral Credits'}</span>
                        </span>
                        <span className="text-[10px] text-stone-500">
                          {isBn ? `ওয়ালেট ব্যালেন্স: ৳${walletCredits}` : `Wallet Balance: ৳${walletCredits}`}
                        </span>
                      </div>
                    </div>
                    {useWalletCredits && appliedCreditDiscount > 0 && (
                      <span className="font-mono text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        -{formatBDT(appliedCreditDiscount)}
                      </span>
                    )}
                  </label>
                )}

                <div className="flex justify-between text-xs text-stone-500">
                  <span>Platform Operations & Escrow Protection (Included)</span>
                  <span>{formatBDT(platformFee)} ({Math.round(platformConfig.commissionRate * 100)}%)</span>
                </div>

                <div className="border-t border-stone-200 pt-2 flex justify-between text-sm font-bold text-stone-900">
                  <span>Total Amount Payable</span>
                  <span className="text-[#721C38] text-base">{formatBDT(totalPayable)}</span>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                >
                  <span>Continue to Safety Agreement</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: SAFETY & MUTUAL CONSENT ACKNOWLEDGMENT */}
          {step === 2 && (
            <div className="p-5 sm:p-6 space-y-5">
              <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 space-y-3">
                <div className="flex items-center gap-2 text-rose-950 font-serif font-bold text-base">
                  <ShieldCheck className="w-5 h-5 text-[#721C38]" />
                  Mandatory Code of Conduct & Service Boundaries
                </div>
                <p className="text-xs text-rose-900 leading-relaxed font-normal bg-white p-3 rounded-xl border border-rose-100">
                  "{MANDATORY_CONSENT_NOTICE}"
                </p>
                
                <ul className="text-xs text-rose-800 space-y-1.5 pl-1">
                  <li className="flex items-center gap-2">
                    <span className="text-rose-600 font-bold">•</span>
                    <span>Designated Public Venue: <strong>{finalMeetupVenue}</strong></span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-rose-600 font-bold">•</span>
                    <span>Either party may pause or conclude the meetup if uncomfortable.</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-rose-600 font-bold">•</span>
                    <span>Strict zero-tolerance policy against harassment, coercion, or solicitations.</span>
                  </li>
                </ul>
              </div>

              {/* Checkbox acknowledgement */}
              <label className="flex items-start gap-3 p-3 bg-stone-50 rounded-xl border border-stone-200 cursor-pointer">
                <input
                  type="checkbox"
                  required
                  checked={consentAcknowledged}
                  onChange={(e) => setConsentAcknowledged(e.target.checked)}
                  className="mt-0.5 rounded border-stone-300 text-[#721C38] focus:ring-[#721C38] w-4 h-4 accent-[#721C38]"
                />
                <span className="text-xs text-stone-700 leading-normal">
                  I explicitly confirm that I am at least 18 years of age. I understand that payment secures social companionship only, and does not purchase romantic affection, physical intimacy, or consent to any extracurricular behavior.
                </span>
              </label>

              {/* Navigation buttons */}
              <div className="flex items-center justify-between pt-3">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-2 border border-stone-200 text-stone-700 text-xs font-semibold rounded-xl hover:bg-stone-50 cursor-pointer"
                >
                  Back to Schedule
                </button>
                <button
                  type="button"
                  disabled={!consentAcknowledged}
                  onClick={handleConfirmBookingRequest}
                  className={`px-6 py-2.5 text-white text-xs font-semibold rounded-xl flex items-center gap-2 transition-all cursor-pointer ${
                    consentAcknowledged ? 'bg-[#721C38] hover:bg-[#58152B]' : 'bg-stone-300 cursor-not-allowed'
                  }`}
                >
                  <span>Submit & Proceed to Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: BANGLADESH PAYMENT & ESCROW CHECKOUT */}
          {step === 3 && (
            <div className="p-5 sm:p-6 space-y-5">
              
              {/* Escrow Protection Guarantee Card */}
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-emerald-950">
                <HeartHandshake className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-emerald-900 block">100% Escrow Protection Guarantee</span>
                  <p className="mt-0.5 text-emerald-800 leading-relaxed">
                    Your money is safely held in platform escrow. Payment is only disbursed to {provider.displayName} after the meetup takes place and both parties safely mark it completed.
                  </p>
                </div>
              </div>

              {/* Promo code entry */}
              <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 space-y-2">
                <label className="text-xs font-semibold text-stone-700 flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-[#721C38]" />
                  Have a Promo Code or Voucher?
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Try DHAKA2026 or FIRSTDATE"
                    value={promoInput}
                    onChange={(e) => setPromoInput(e.target.value)}
                    className="flex-1 text-xs p-2 bg-white border border-stone-200 rounded-lg uppercase font-semibold"
                  />
                  <button
                    type="button"
                    onClick={handleApplyPromo}
                    className="px-4 py-2 bg-stone-900 hover:bg-[#721C38] text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                  >
                    Apply
                  </button>
                </div>
                {promoMessage && (
                  <p className={`text-[11px] font-medium ${promoMessage.isError ? 'text-rose-600' : 'text-emerald-700'}`}>
                    {promoMessage.text}
                  </p>
                )}
              </div>

              {/* Payment Gateway Selector */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-stone-700">Choose Payment Method</label>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('bkash')}
                    className={`p-3 rounded-xl border text-center transition-all flex flex-col items-center gap-1.5 cursor-pointer ${
                      paymentMethod === 'bkash' 
                        ? 'border-[#E2136E] bg-pink-50/50 shadow-2xs font-bold text-[#E2136E]' 
                        : 'border-stone-200 bg-white text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <Smartphone className="w-5 h-5 text-[#E2136E]" />
                    <span className="text-xs">bKash</span>
                    <span className="text-[10px] text-stone-400 font-normal">Fast Wallet</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('nagad')}
                    className={`p-3 rounded-xl border text-center transition-all flex flex-col items-center gap-1.5 cursor-pointer ${
                      paymentMethod === 'nagad' 
                        ? 'border-[#F7931E] bg-amber-50/50 shadow-2xs font-bold text-[#F7931E]' 
                        : 'border-stone-200 bg-white text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <Smartphone className="w-5 h-5 text-[#F7931E]" />
                    <span className="text-xs">Nagad</span>
                    <span className="text-[10px] text-stone-400 font-normal">Post Office</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('sslcommerz')}
                    className={`p-3 rounded-xl border text-center transition-all flex flex-col items-center gap-1.5 cursor-pointer ${
                      paymentMethod === 'sslcommerz' 
                        ? 'border-indigo-600 bg-indigo-50/50 shadow-2xs font-bold text-indigo-700' 
                        : 'border-stone-200 bg-white text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <CreditCard className="w-5 h-5 text-indigo-600" />
                    <span className="text-xs">SSLCOMMERZ</span>
                    <span className="text-[10px] text-stone-400 font-normal">Card / NetBanking</span>
                  </button>
                </div>
              </div>

              {/* Simulated Gateway Fields */}
              <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 space-y-3">
                <div className="flex items-center justify-between text-xs pb-2 border-b border-stone-200">
                  <span className="text-stone-500 font-medium">Merchant: Rent a Date Ltd.</span>
                  <span className="font-bold text-stone-900 text-sm">{formatBDT(totalPayable)}</span>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-stone-600">Mobile Wallet Number</label>
                  <input
                    type="text"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    className="w-full text-xs p-2 bg-white border border-stone-200 rounded-lg"
                    placeholder="017XXXXXXXX"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-stone-600">Demo Verification PIN (Simulated)</label>
                  <input
                    type="password"
                    value={demoPin}
                    onChange={(e) => setDemoPin(e.target.value)}
                    className="w-full text-xs p-2 bg-white border border-stone-200 rounded-lg"
                    placeholder="****"
                  />
                </div>
              </div>

              {/* Pay Button */}
              <div className="pt-2">
                <button
                  type="button"
                  disabled={isProcessingPayment}
                  onClick={handleSimulatePayment}
                  className="w-full py-3 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-all shadow-sm cursor-pointer disabled:opacity-50"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>
                    {isProcessingPayment 
                      ? `Authorizing ${paymentMethod.toUpperCase()} Escrow...` 
                      : `Confirm & Pay ${formatBDT(totalPayable)} to Escrow`}
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: SUCCESS CONFIRMATION RECEIPT */}
          {step === 4 && (
            <div className="p-6 text-center space-y-5">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div className="space-y-1">
                <h3 className="font-serif font-bold text-2xl text-stone-900">Booking Confirmed & Escrow Funded!</h3>
                <p className="text-xs text-stone-600 max-w-md mx-auto">
                  Your reservation with {provider.displayName} is confirmed. Funds are safely held in escrow until the session is completed.
                </p>
              </div>

              <div className="bg-[#FAF7F5] rounded-2xl p-4 text-xs text-left space-y-2 border border-stone-200 max-w-md mx-auto">
                <div className="flex justify-between">
                  <span className="text-stone-500">Service:</span>
                  <span className="font-semibold text-stone-900">{service.title}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Date & Time:</span>
                  <span className="font-semibold text-stone-900">{scheduledDate} at {scheduledTime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Meetup Venue:</span>
                  <span className="font-semibold text-stone-900">{finalMeetupVenue}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Paid to Escrow:</span>
                  <span className="font-bold text-[#721C38]">{formatBDT(totalPayable)} ({paymentMethod.toUpperCase()})</span>
                </div>
              </div>

              <button
                onClick={() => {
                  if (createdBookingId) onSuccess(createdBookingId);
                  onClose();
                }}
                className="px-8 py-2.5 bg-stone-900 hover:bg-[#721C38] text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                View in My Bookings Dashboard
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
