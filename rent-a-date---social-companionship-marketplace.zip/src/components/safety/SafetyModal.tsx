import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { MANDATORY_CONSENT_NOTICE } from '../../utils/formatters';
import { 
  X, 
  ShieldCheck, 
  AlertTriangle, 
  PhoneCall, 
  MapPin, 
  CheckCircle2, 
  Eye, 
  Lock,
  Flag
} from 'lucide-react';

interface SafetyModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetReportUserId?: string | null;
}

export const SafetyModal: React.FC<SafetyModalProps> = ({
  isOpen,
  onClose,
  targetReportUserId
}) => {
  const { allUsers, submitReport } = useApp();
  const [activeTab, setActiveTab] = useState<'guidelines' | 'report'>(targetReportUserId ? 'report' : 'guidelines');

  // Report Form state
  const [reportTargetId, setReportTargetId] = useState(targetReportUserId || allUsers[0]?.id || '');
  const [reportReason, setReportReason] = useState('Off-platform contact request');
  const [reportDetails, setReportDetails] = useState('');
  const [isReportSubmitted, setIsReportSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitReport({
      reportedUserId: reportTargetId,
      reason: reportReason,
      details: reportDetails
    });
    setIsReportSubmitted(true);
    setTimeout(() => {
      setIsReportSubmitted(false);
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div 
        className="bg-white max-w-2xl w-full rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="bg-[#FAF7F5] border-b border-stone-200 p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-rose-100 text-[#721C38] rounded-xl">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-lg text-stone-900">Safety, Trust & Service Boundaries</h3>
              <p className="text-xs text-stone-500">Rent a Date Community Standards & Operations</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-stone-200 text-stone-400">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub-tab navigation */}
        <div className="flex border-b border-stone-200 bg-white px-6">
          <button
            onClick={() => setActiveTab('guidelines')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'guidelines'
                ? 'border-[#721C38] text-[#721C38]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Safety Guidelines & Consent Policy
          </button>
          <button
            onClick={() => setActiveTab('report')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'report'
                ? 'border-[#721C38] text-[#721C38]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Flag className="w-3.5 h-3.5" />
            <span>File an Incident Report</span>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {activeTab === 'guidelines' && (
            <div className="space-y-6 text-xs text-stone-700">
              
              {/* Mandatory Policy Box */}
              <div className="bg-gradient-to-br from-rose-50 to-[#FAF7F5] border-2 border-rose-200/80 rounded-2xl p-5 space-y-3">
                <div className="flex items-center gap-2 font-serif font-bold text-base text-[#721C38]">
                  <AlertTriangle className="w-5 h-5" />
                  Mandatory Platform Service Boundary Notice
                </div>
                <blockquote className="bg-white p-4 rounded-xl border border-rose-200 text-stone-800 leading-relaxed font-normal italic">
                  "{MANDATORY_CONSENT_NOTICE}"
                </blockquote>
                <p className="text-[11px] text-stone-600 leading-normal">
                  Our service connects vetted adults for social companionship in public venues. Any pressure, coercion, or solicitation of sexual acts will result in permanent account deactivation and referral to civil authorities.
                </p>
              </div>

              {/* 4 Pillars of Meetup Safety */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-1.5">
                  <div className="font-semibold text-stone-900 flex items-center gap-1.5 text-xs">
                    <MapPin className="w-4 h-4 text-[#721C38]" />
                    1. 100% Public Venues Only
                  </div>
                  <p className="text-stone-600 text-[11px] leading-relaxed">
                    Meet strictly in well-lit, public coffee shops, restaurants, art galleries, or cultural venues in Dhaka. Never agree to private homes or secluded places.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-1.5">
                  <div className="font-semibold text-stone-900 flex items-center gap-1.5 text-xs">
                    <Eye className="w-4 h-4 text-[#721C38]" />
                    2. Maintain Clear Boundaries
                  </div>
                  <p className="text-stone-600 text-[11px] leading-relaxed">
                    Either party can respectfully conclude or pause the experience at any moment. Respect personal autonomy at all times.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-1.5">
                  <div className="font-semibold text-stone-900 flex items-center gap-1.5 text-xs">
                    <Lock className="w-4 h-4 text-[#721C38]" />
                    3. Protected In-App Messages
                  </div>
                  <p className="text-stone-600 text-[11px] leading-relaxed">
                    Communicate through our in-app messaging system. Never send money outside the verified checkout gateway.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-1.5">
                  <div className="font-semibold text-stone-900 flex items-center gap-1.5 text-xs">
                    <PhoneCall className="w-4 h-4 text-emerald-600" />
                    4. Emergency Helpline (999)
                  </div>
                  <p className="text-stone-600 text-[11px] leading-relaxed">
                    In any case of immediate discomfort or emergency, call <strong>999</strong> (Bangladesh National Emergency Service) or report via the app immediately.
                  </p>
                </div>

              </div>

            </div>
          )}

          {activeTab === 'report' && (
            <div className="space-y-4">
              {isReportSubmitted ? (
                <div className="text-center py-10 space-y-3">
                  <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
                  <h4 className="font-serif font-bold text-lg text-stone-900">Report Submitted to Trust & Safety Team</h4>
                  <p className="text-xs text-stone-500 max-w-sm mx-auto">
                    Our compliance operations team will review this incident within 2 hours. Your report is kept confidential.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleReportSubmit} className="space-y-4 text-xs">
                  <div>
                    <h4 className="font-serif font-bold text-sm text-stone-900">Confidential Incident Report</h4>
                    <p className="text-[11px] text-stone-500">
                      Report any behavior that breaches the code of conduct or service boundaries.
                    </p>
                  </div>

                  <div className="space-y-1">
                    <label className="font-semibold text-stone-700">Select User to Report</label>
                    <select
                      value={reportTargetId}
                      onChange={(e) => setReportTargetId(e.target.value)}
                      className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                    >
                      {allUsers.map(u => (
                        <option key={u.id} value={u.id}>{u.displayName} ({u.area})</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-semibold text-stone-700">Reason for Report</label>
                    <select
                      value={reportReason}
                      onChange={(e) => setReportReason(e.target.value)}
                      className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                    >
                      <option value="boundary_violation">Boundary Violation (Requested non-social activity)</option>
                      <option value="off_platform_contact">Attempted off-platform payment or contact</option>
                      <option value="unauthorized_venue">Requested private or non-public venue</option>
                      <option value="harassment">Verbal Harassment or Disrespectful Behavior</option>
                      <option value="identity_mismatch">Identity did not match profile photo</option>
                      <option value="other">Other policy concern</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-semibold text-stone-700">Incident Details</label>
                    <textarea
                      rows={4}
                      required
                      value={reportDetails}
                      onChange={(e) => setReportDetails(e.target.value)}
                      placeholder="Please specify date, time, location, and exact statements or events..."
                      className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                    />
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      className="px-6 py-2.5 bg-rose-700 hover:bg-rose-800 text-white font-semibold rounded-xl flex items-center gap-2 transition-colors cursor-pointer"
                    >
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>Submit Incident to Moderation</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
