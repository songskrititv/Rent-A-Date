import React, { useState } from 'react';
import { User, ProviderService } from '../../types';
import { useApp } from '../../context/AppContext';
import { formatBDT } from '../../utils/formatters';
import { Star, ShieldCheck, Heart, MapPin, ArrowRight, Volume2, Sparkles, Check, Play, Pause } from 'lucide-react';

interface CompanionCardProps {
  companion: User;
  onSelect: (companionId: string) => void;
}

export const CompanionCard: React.FC<CompanionCardProps> = ({ companion, onSelect }) => {
  const { services, savedProviderIds, toggleSaveProvider, currentUser } = useApp();
  const [isPlayingVoice, setIsPlayingVoice] = useState(false);

  const companionServices = services.filter(s => s.providerId === companion.id && s.isActive);
  const isSaved = savedProviderIds.includes(companion.id);

  // Calculate compatibility match % based on shared interests
  const sharedInterests = companion.interests.filter(i => 
    currentUser.interests.some(ci => ci.toLowerCase() === i.toLowerCase())
  );
  const matchPercentage = Math.min(98, Math.max(78, 75 + sharedInterests.length * 8));

  // Calculate lowest price among active services
  const minPrice = companionServices.length > 0
    ? Math.min(...companionServices.map(s => s.price))
    : 1000;

  const minService = companionServices.find(s => s.price === minPrice) || companionServices[0];

  const handleToggleVoice = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsPlayingVoice(!isPlayingVoice);
    if (!isPlayingVoice) {
      setTimeout(() => setIsPlayingVoice(false), 4500);
    }
  };

  return (
    <div className="group bg-white rounded-2xl border border-stone-200/90 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col h-full">
      {/* Photo with status indicator and bookmark button */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-stone-100">
        <img
          src={companion.avatar}
          alt={companion.displayName}
          className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
          loading="lazy"
        />

        {/* Gradient overlay for text contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-stone-900/60 via-transparent to-transparent opacity-80"></div>

        {/* Top-left Compatibility Match Badge */}
        <div className="absolute top-3 left-3 bg-stone-900/70 backdrop-blur-md text-rose-200 border border-rose-500/30 px-2 py-0.5 rounded-lg text-[10px] font-bold flex items-center gap-1 shadow-sm">
          <Sparkles className="w-3 h-3 text-rose-400" />
          <span>{matchPercentage}% Match</span>
        </div>

        {/* Top-right Favorite/Save button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleSaveProvider(companion.id);
          }}
          className="absolute top-3 right-3 w-9 h-9 rounded-full bg-stone-900/40 backdrop-blur-md flex items-center justify-center text-white hover:bg-stone-900/70 transition-colors"
          title={isSaved ? "Remove from saved" : "Save companion"}
        >
          <Heart className={`w-4 h-4 ${isSaved ? "fill-rose-500 text-rose-500" : "text-white"}`} />
        </button>

        {/* Bottom image overlay metadata */}
        <div className="absolute bottom-3 left-3 right-3 text-white flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 font-medium">
            <MapPin className="w-3.5 h-3.5 text-rose-300" />
            <span>{companion.area}, Dhaka</span>
          </div>

          {/* Voice sample quick preview button */}
          {companion.voiceIntro && (
            <button
              onClick={handleToggleVoice}
              className={`flex items-center gap-1 text-[11px] font-medium backdrop-blur-md px-2 py-0.5 rounded-lg transition-colors cursor-pointer ${
                isPlayingVoice 
                  ? 'bg-rose-600 text-white shadow-xs animate-pulse' 
                  : 'bg-stone-900/70 text-stone-200 hover:bg-stone-900'
              }`}
              title="Listen to 10s voice greeting"
            >
              {isPlayingVoice ? <Pause className="w-3 h-3" /> : <Volume2 className="w-3 h-3 text-rose-300" />}
              <span>{isPlayingVoice ? 'Speaking...' : 'Voice'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Voice sample playback bubble */}
      {isPlayingVoice && companion.voiceIntro && (
        <div className="bg-rose-950 text-rose-100 text-[11px] px-3.5 py-2 border-b border-rose-900 flex items-center justify-between animate-in fade-in">
          <div className="truncate italic">
            "{companion.voiceIntro.quote}"
          </div>
          <span className="text-[10px] text-rose-300 ml-2 font-mono shrink-0">
            {companion.voiceIntro.accent}
          </span>
        </div>
      )}

      {/* Card Content */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        
        {/* Name and Rating */}
        <div>
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 min-w-0">
              <h3 className="font-serif text-lg font-bold text-stone-900 group-hover:text-[#721C38] transition-colors truncate">
                {companion.displayName}
              </h3>
              {companion.verificationStatus === 'verified' && (
                <span
                  className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200/90 px-1.5 py-0.5 rounded-md shrink-0 shadow-2xs"
                  title="Government ID Verified Provider"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span className="text-[10px] font-bold tracking-tight">Verified</span>
                </span>
              )}
            </div>
            <div className="flex items-center gap-1 text-xs text-stone-700 font-semibold shrink-0">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
              <span>{companion.rating.toFixed(1)}</span>
              <span className="text-stone-400 font-normal">({companion.reviewCount})</span>
            </div>
          </div>

          {/* Professional Background Badge */}
          {companion.professionalBadge && (
            <div className="text-[11px] font-semibold text-stone-700 mt-0.5 truncate">
              {companion.professionalBadge}
            </div>
          )}

          {/* Clean unboxed metadata (anti-slop rule) */}
          <div className="flex items-center gap-2 text-xs text-stone-500 mt-1 flex-wrap">
            <span className="capitalize">{companion.gender}</span>
            <span aria-hidden="true">·</span>
            <span>{companion.languages.join(', ')}</span>
            <span aria-hidden="true">·</span>
            <span>{companionServices.length} {companionServices.length === 1 ? 'service' : 'services'}</span>
          </div>

          <p className="text-xs text-stone-600 line-clamp-2 mt-2 leading-relaxed font-normal">
            {companion.bio}
          </p>
        </div>

        {/* Published services highlight */}
        <div className="pt-2 border-t border-stone-100 space-y-1">
          <div className="text-[11px] text-stone-400 uppercase tracking-wider font-semibold">
            Featured Experiences
          </div>
          <div className="text-xs text-stone-700 font-medium truncate">
            {companionServices.map(s => s.title).slice(0, 2).join(' · ')}
          </div>
        </div>

        {/* Pricing & CTA */}
        <div className="pt-2 flex items-center justify-between gap-3 border-t border-stone-100">
          <div>
            <span className="text-[10px] text-stone-400 block uppercase font-medium">Starts from</span>
            <div className="text-sm font-bold text-stone-900">
              <span className="text-[#721C38]">{formatBDT(minPrice)}</span>
              <span className="text-xs text-stone-500 font-normal ml-1">
                /{minService?.pricingUnit === 'hourly' ? 'hr' : 'session'}
              </span>
            </div>
          </div>

          <button
            onClick={() => onSelect(companion.id)}
            className="px-3.5 py-2 bg-stone-900 hover:bg-[#721C38] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <span>View Services</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
};
