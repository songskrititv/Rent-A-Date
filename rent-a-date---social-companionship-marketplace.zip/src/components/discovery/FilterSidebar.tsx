import React from 'react';
import { useApp } from '../../context/AppContext';
import { formatBDT } from '../../utils/formatters';
import { Filter, RotateCcw, Search, ShieldCheck } from 'lucide-react';

interface FilterState {
  searchQuery: string;
  selectedCategory: string;
  selectedArea: string;
  gender: string;
  maxPrice: number;
  verifiedOnly: boolean;
  sortBy: 'recommended' | 'price_low' | 'price_high' | 'rating';
}

interface FilterSidebarProps {
  filters: FilterState;
  onChange: (updates: Partial<FilterState>) => void;
  onReset: () => void;
  resultCount: number;
}

export const FilterSidebar: React.FC<FilterSidebarProps> = ({
  filters,
  onChange,
  onReset,
  resultCount
}) => {
  const { categories, language } = useApp();

  return (
    <div className="bg-white rounded-2xl border border-stone-200/90 p-5 shadow-xs space-y-6">
      
      {/* Header and Reset */}
      <div className="flex items-center justify-between pb-4 border-b border-stone-100">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-[#721C38]" />
          <h3 className="font-serif font-bold text-base text-stone-900">Filters</h3>
          <span className="text-xs text-stone-400 font-medium">({resultCount})</span>
        </div>
        <button
          onClick={onReset}
          className="text-xs text-stone-500 hover:text-[#721C38] flex items-center gap-1 font-medium transition-colors"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="space-y-1.5">
        <label className="text-xs font-semibold text-stone-700">Keywords / Interests</label>
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search art, jazz, cafes, name..."
            value={filters.searchQuery}
            onChange={(e) => onChange({ searchQuery: e.target.value })}
            className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#721C38] focus:bg-white transition-all text-stone-900"
          />
        </div>
      </div>

      {/* Experience Category */}
      <div className="space-y-2">
        <label className="text-xs font-semibold text-stone-700">Experience Category</label>
        <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
          <button
            onClick={() => onChange({ selectedCategory: '' })}
            className={`w-full text-left text-xs px-2.5 py-1.5 rounded-lg transition-colors flex items-center justify-between ${
              filters.selectedCategory === '' ? 'bg-[#721C38] text-white font-medium' : 'text-stone-600 hover:bg-stone-50'
            }`}
          >
            <span>All Experiences</span>
          </button>
          {categories.filter(c => c.isActive).map(cat => (
            <button
              key={cat.id}
              onClick={() => onChange({ selectedCategory: cat.id })}
              className={`w-full text-left text-xs px-2.5 py-1.5 rounded-lg transition-colors flex items-center justify-between ${
                filters.selectedCategory === cat.id ? 'bg-[#721C38] text-white font-medium' : 'text-stone-600 hover:bg-stone-50'
              }`}
            >
              <span className="truncate">{language === 'bn' ? cat.nameBn : cat.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Location in Dhaka */}
      <div className="space-y-2">
        <label className="text-xs font-semibold text-stone-700">Dhaka Area</label>
        <select
          value={filters.selectedArea}
          onChange={(e) => onChange({ selectedArea: e.target.value })}
          className="w-full text-xs bg-stone-50 border border-stone-200 rounded-xl p-2 text-stone-800 focus:outline-none focus:ring-1 focus:ring-[#721C38]"
        >
          <option value="">All Neighborhoods</option>
          <option value="Gulshan">Gulshan 1 & 2</option>
          <option value="Banani">Banani</option>
          <option value="Dhanmondi">Dhanmondi</option>
          <option value="Uttara">Uttara</option>
          <option value="Bashundhara">Bashundhara R/A</option>
          <option value="Mohakhali">Mohakhali DOHS</option>
          <option value="Old Dhaka">Old Dhaka</option>
        </select>
      </div>

      {/* Companion Gender (Optional & Inclusive) */}
      <div className="space-y-2">
        <label className="text-xs font-semibold text-stone-700">Companion Gender</label>
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-stone-100 rounded-xl">
          {[
            { id: 'all', label: 'All' },
            { id: 'female', label: 'Women' },
            { id: 'male', label: 'Men' }
          ].map(g => (
            <button
              key={g.id}
              onClick={() => onChange({ gender: g.id })}
              className={`py-1.5 text-xs font-medium rounded-lg transition-all ${
                filters.gender === g.id ? 'bg-white text-stone-900 shadow-xs font-semibold' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {g.label}
            </button>
          ))}
        </div>
      </div>

      {/* Max Budget (BDT ৳) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-semibold text-stone-700">
          <span>Max Budget</span>
          <span className="text-[#721C38] font-bold">{formatBDT(filters.maxPrice)}</span>
        </div>
        <input
          type="range"
          min="800"
          max="5000"
          step="200"
          value={filters.maxPrice}
          onChange={(e) => onChange({ maxPrice: Number(e.target.value) })}
          className="w-full accent-[#721C38] cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-stone-400">
          <span>৳800</span>
          <span>৳5,000+</span>
        </div>
      </div>

      {/* Verified Status Toggle */}
      <div className="pt-2 border-t border-stone-100">
        <label className="flex items-center justify-between cursor-pointer">
          <span className="text-xs font-medium text-stone-700 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            Verified Companions Only
          </span>
          <input
            type="checkbox"
            checked={filters.verifiedOnly}
            onChange={(e) => onChange({ verifiedOnly: e.target.checked })}
            className="rounded border-stone-300 text-[#721C38] focus:ring-[#721C38] w-4 h-4 accent-[#721C38]"
          />
        </label>
      </div>

    </div>
  );
};
