import React, { useState } from 'react';
import { User, ProviderService } from '../../types';
import { useApp } from '../../context/AppContext';
import { formatBDT, formatDate } from '../../utils/formatters';
import { 
  X, 
  Star, 
  ShieldCheck, 
  MapPin, 
  Clock, 
  Calendar, 
  AlertCircle, 
  ShieldAlert, 
  CheckCircle2, 
  MessageSquare,
  Sparkles,
  Heart,
  ChevronRight,
  Info,
  Volume2,
  Pause,
  PhoneCall,
  Phone
} from 'lucide-react';

interface CompanionDetailModalProps {
  companionId: string;
  onClose: () => void;
  onStartBooking: (serviceId: string) => void;
  onOpenMessage: (recipientId: string) => void;
  onReport: (reportedUserId: string) => void;
}

export const CompanionDetailModal: React.FC<CompanionDetailModalProps> = ({
  companionId,
  onClose,
  onStartBooking,
  onOpenMessage,
  onReport
}) => {
  const { 
    allUsers, 
    services, 
    categories, 
    reviews, 
    savedProviderIds, 
    toggleSaveProvider, 
    currentUser, 
    setActiveVoiceCallPartner,
    isAuthenticated,
    setAuthModalOpen,
    setAuthModalMode,
    language
  } = useApp();

  const isBn = language === 'bn';

  const companion = allUsers.find(u => u.id === companionId);
  const companionServices = services.filter(s => s.providerId === companionId && s.isActive);
  const companionReviews = reviews.filter(r => r.providerId === companionId);
  const isSaved = savedProviderIds.includes(companionId);

  const [activeTab, setActiveTab] = useState<'services' | 'about' | 'reviews'>('services');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  if (!companion) return null;

  // Calculate compatibility match % based on shared interests
  const sharedInterests = companion.interests.filter(i => 
    currentUser.interests.some(ci => ci.toLowerCase() === i.toLowerCase())
  );
  const matchPercentage = Math.min(98, Math.max(78, 75 + sharedInterests.length * 8));

  const handleToggleVoice = () => {
    setIsPlayingAudio(!isPlayingAudio);
    if (!isPlayingAudio) {
      setTimeout(() => setIsPlayingAudio(false), 5000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Modal Top Bar */}
        <div className="relative bg-[#FAF7F5] border-b border-stone-200 p-4 sm:p-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img
              src={companion.avatar}
              alt={companion.displayName}
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-white shadow-sm"
            />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-serif text-2xl font-bold text-stone-900">
                  {companion.displayName}
                </h2>
                {companion.verificationStatus === 'verified' && (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-md">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    ID Verified ({companion.verificationDocumentType?.toUpperCase() || 'NID'})
                  </span>
                )}
                {companion.isFaceVerified && (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-md">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    {language === 'bn' ? 'ফেস ভেরিফাইড' : 'Face Verified'}
                  </span>
                )}
                {companion.isPhoneVerified && (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-stone-700 bg-stone-100 border border-stone-200 px-2 py-0.5 rounded-md">
                    <Phone className="w-3 h-3 text-[#721C38]" />
                    {language === 'bn' ? 'ফোন ভেরিফাইড' : 'Phone Verified'}
                  </span>
                )}
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-rose-800 bg-rose-50 border border-rose-200 px-2.5 py-0.5 rounded-md">
                  <Sparkles className="w-3.5 h-3.5 text-rose-600" />
                  {matchPercentage}% Match with You
                </span>
              </div>

              {companion.professionalBadge && (
                <div className="text-xs font-semibold text-stone-700 mt-1">
                  {companion.professionalBadge}
                </div>
              )}
              
              <div className="flex items-center gap-2 text-xs text-stone-500 mt-1 flex-wrap">
                <span className="flex items-center gap-1 font-medium text-stone-700">
                  <MapPin className="w-3.5 h-3.5 text-[#721C38]" />
                  {companion.area}, Dhaka
                </span>
                <span>·</span>
                <span className="capitalize">{companion.gender}</span>
                <span>·</span>
                <span className="flex items-center gap-1 font-semibold text-stone-900">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                  {companion.rating.toFixed(2)} ({companion.reviewCount} reviews)
                </span>
                {companion.voiceIntro && (
                  <>
                    <span>·</span>
                    <button
                      onClick={handleToggleVoice}
                      className={`inline-flex items-center gap-1 font-semibold text-xs px-2 py-0.5 rounded-md transition-colors ${
                        isPlayingAudio 
                          ? 'bg-rose-600 text-white animate-pulse' 
                          : 'bg-stone-200 hover:bg-stone-300 text-stone-800'
                      }`}
                    >
                      {isPlayingAudio ? <Pause className="w-3 h-3" /> : <Volume2 className="w-3 h-3 text-[#721C38]" />}
                      <span>{isPlayingAudio ? 'Playing Voice...' : 'Voice Intro (14s)'}</span>
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Top Actions: Bookmark, Close */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => toggleSaveProvider(companion.id)}
              className="w-10 h-10 rounded-full border border-stone-200 bg-white flex items-center justify-center hover:bg-stone-50 transition-colors"
              title={isSaved ? "Saved" : "Save"}
            >
              <Heart className={`w-4 h-4 ${isSaved ? "fill-rose-500 text-rose-500" : "text-stone-600"}`} />
            </button>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full border border-stone-200 bg-white flex items-center justify-center text-stone-500 hover:text-stone-900 hover:bg-stone-50 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-stone-200 bg-white px-6">
          <button
            onClick={() => setActiveTab('services')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'services'
                ? 'border-[#721C38] text-[#721C38]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Services & Pricing ({companionServices.length})
          </button>
          <button
            onClick={() => setActiveTab('about')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'about'
                ? 'border-[#721C38] text-[#721C38]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Biography & Guidelines
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'reviews'
                ? 'border-[#721C38] text-[#721C38]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Client Reviews ({companionReviews.length})
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">

          {/* TAB 1: SERVICES & PRICING */}
          {activeTab === 'services' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-serif font-bold text-lg text-stone-900">
                    Published Companionship Services
                  </h3>
                  <p className="text-xs text-stone-500">
                    Each service has transparent pricing in BDT (৳) and predefined boundaries.
                  </p>
                </div>
              </div>

              {companionServices.length === 0 ? (
                <div className="text-center py-12 bg-stone-50 rounded-2xl border border-dashed border-stone-200">
                  <p className="text-sm text-stone-500 font-medium">No published services currently available.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {companionServices.map(service => {
                    const category = categories.find(c => c.id === service.categoryId);
                    return (
                      <div
                        key={service.id}
                        className="bg-[#FAF7F5] rounded-2xl border border-stone-200/80 p-5 flex flex-col justify-between hover:border-[#721C38]/40 transition-colors shadow-2xs"
                      >
                        <div className="space-y-3">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <span className="text-[10px] font-semibold text-[#721C38] uppercase tracking-wider block">
                                {category?.name || 'Experience'}
                              </span>
                              <h4 className="font-serif font-bold text-base text-stone-900">
                                {service.title}
                              </h4>
                            </div>
                            <div className="text-right shrink-0">
                              <span className="text-base font-bold text-stone-900 block">
                                {formatBDT(service.price)}
                              </span>
                              <span className="text-[10px] text-stone-500">
                                /{service.pricingUnit === 'hourly' ? 'hour' : 'session'}
                              </span>
                            </div>
                          </div>

                          <p className="text-xs text-stone-600 leading-relaxed font-normal">
                            {service.description}
                          </p>

                          {/* Metadata row */}
                          <div className="flex flex-wrap items-center gap-3 text-[11px] text-stone-500 pt-1">
                            <span className="flex items-center gap-1 font-medium">
                              <Clock className="w-3 h-3 text-stone-400" />
                              {service.durationHours} {service.durationHours === 1 ? 'hour' : 'hours'} base
                            </span>
                            <span>·</span>
                            <span className="flex items-center gap-1 font-medium">
                              <MapPin className="w-3 h-3 text-stone-400" />
                              {service.generalLocation}
                            </span>
                          </div>

                          {/* Service Boundaries */}
                          <div className="bg-white rounded-xl p-3 border border-stone-200/60 space-y-1.5">
                            <div className="text-[10px] font-semibold text-stone-500 uppercase tracking-wider flex items-center gap-1">
                              <ShieldCheck className="w-3 h-3 text-emerald-600" />
                              Service Boundaries & Terms
                            </div>
                            <ul className="text-[11px] text-stone-600 space-y-1">
                              {service.serviceBoundaries.map((b, idx) => (
                                <li key={idx} className="flex items-start gap-1.5">
                                  <span className="text-rose-700 font-bold">✓</span>
                                  <span>{b}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>

                        {/* Direct Booking CTA */}
                        <div className="mt-4 pt-3 border-t border-stone-200/60 flex items-center justify-between gap-3">
                          <span className="text-[11px] text-stone-400">
                            Notice: {service.advanceNoticeHours}h advance booking
                          </span>
                          <button
                            onClick={() => onStartBooking(service.id)}
                            className="px-4 py-2 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                          >
                            <span>Book This Service</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: BIOGRAPHY & GUIDELINES */}
          {activeTab === 'about' && (
            <div className="space-y-6">
              <div>
                <h4 className="font-serif font-bold text-base text-stone-900 mb-2">About {companion.displayName}</h4>
                <p className="text-sm text-stone-700 leading-relaxed">{companion.bio}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-stone-50 p-4 rounded-xl border border-stone-200/80">
                  <h5 className="text-xs font-semibold text-stone-800 uppercase tracking-wider mb-2">Languages Spoken</h5>
                  <div className="flex flex-wrap gap-2 text-xs text-stone-700">
                    {companion.languages.map((l, i) => (
                      <span key={i} className="bg-white px-2.5 py-1 rounded-md border border-stone-200 font-medium">
                        {l}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-stone-50 p-4 rounded-xl border border-stone-200/80">
                  <h5 className="text-xs font-semibold text-stone-800 uppercase tracking-wider mb-2">Passions & Interests</h5>
                  <div className="flex flex-wrap gap-2 text-xs text-stone-700">
                    {companion.interests.map((int, i) => (
                      <span key={i} className="bg-white px-2.5 py-1 rounded-md border border-stone-200 font-medium">
                        {int}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Verified Identity Card */}
              <div className="bg-emerald-50/60 border border-emerald-200 rounded-2xl p-4 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div className="text-xs text-emerald-950 space-y-1">
                  <div className="font-semibold text-emerald-900">Identity Authenticated by Platform Ops</div>
                  <p className="text-emerald-800 leading-normal">
                    {companion.displayName} has completed government-issued {companion.verificationDocumentType?.toUpperCase() || 'NID'} verification. Physical identity matches verified records on file.
                  </p>
                </div>
              </div>

              {/* Safety Rules for this Companion */}
              <div className="p-4 bg-stone-100 rounded-2xl border border-stone-200 text-xs text-stone-600 space-y-2">
                <div className="font-semibold text-stone-900 flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-stone-500" />
                  Code of Respect & Safety
                </div>
                <p>
                  All bookings with {companion.displayName} are governed by the Rent a Date Code of Conduct. Meetups occur strictly in public establishments in Dhaka. Contact info is maintained safely within the platform.
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: CLIENT REVIEWS */}
          {activeTab === 'reviews' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                <div>
                  <h4 className="font-serif font-bold text-base text-stone-900">Verified Client Feedback</h4>
                  <p className="text-xs text-stone-500">Only verified clients who completed a booking can leave ratings.</p>
                </div>
                <div className="flex items-center gap-1 text-sm font-bold text-stone-900">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                  <span>{companion.rating.toFixed(2)}</span>
                  <span className="text-xs text-stone-400 font-normal">({companion.reviewCount} total)</span>
                </div>
              </div>

              {companionReviews.length === 0 ? (
                <div className="text-center py-10 bg-stone-50 rounded-2xl border border-dashed border-stone-200 text-stone-500 text-xs">
                  No verified client reviews submitted yet.
                </div>
              ) : (
                <div className="space-y-3">
                  {companionReviews.map(review => (
                    <div key={review.id} className="p-4 rounded-xl bg-stone-50 border border-stone-200/80 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <img src={review.customerAvatar} alt={review.customerName} className="w-7 h-7 rounded-full object-cover" />
                          <span className="text-xs font-semibold text-stone-800">{review.customerName}</span>
                        </div>
                        <div className="flex items-center gap-1 text-xs font-semibold text-amber-600">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                          <span>{review.rating} / 5</span>
                        </div>
                      </div>
                      <p className="text-xs text-stone-600 leading-relaxed font-normal">{review.comment}</p>
                      {review.providerReply && (
                        <div className="mt-2 pl-3 border-l-2 border-[#721C38] text-[11px] text-stone-500">
                          <span className="font-semibold text-stone-700">{companion.displayName}'s Response: </span>
                          {review.providerReply}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Modal Bottom Actions: In-App Message & Report */}
        <div className="border-t border-stone-200 bg-[#FAF7F5] px-6 py-3 flex items-center justify-between text-xs">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (!isAuthenticated) {
                  setAuthModalMode('signin');
                  setAuthModalOpen(true);
                  return;
                }
                onOpenMessage(companion.id);
              }}
              className="px-3.5 py-2 bg-white hover:bg-stone-100 text-stone-800 border border-stone-200 rounded-xl font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5 text-[#721C38]" />
              <span>{isBn ? 'মেসেজ পাঠান' : 'Ask a Question'}</span>
            </button>
            <button
              onClick={() => {
                if (!isAuthenticated) {
                  setAuthModalMode('signin');
                  setAuthModalOpen(true);
                  return;
                }
                onClose();
                setActiveVoiceCallPartner(companion);
              }}
              className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-xl font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Encrypted in-app audio call without revealing phone numbers"
            >
              <PhoneCall className="w-3.5 h-3.5 text-emerald-700" />
              <span>{isBn ? 'ইন-অ্যাপ অডিও কল' : 'Encrypted Voice Call'}</span>
            </button>
            <button
              onClick={() => onReport(companion.id)}
              className="text-stone-400 hover:text-rose-600 transition-colors flex items-center gap-1"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Report</span>
            </button>
          </div>

          <div className="text-[11px] text-stone-400 hidden sm:block">
            Member since {formatDate(companion.joinedDate)}
          </div>
        </div>

      </div>
    </div>
  );
};
