import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../utils/formatters';
import { Search, MapPin, Sparkles, Calendar, Heart, Shield, CheckCircle } from 'lucide-react';

interface HeroSectionProps {
  onSearch: (filters: {
    area: string;
    categoryId: string;
    date: string;
    genderPref: string;
  }) => void;
  onBecomeCompanion: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onSearch, onBecomeCompanion }) => {
  const { language, categories, currentUser, isAuthenticated, setAuthModalOpen, setAuthModalMode } = useApp();
  const t = TRANSLATIONS[language];

  const [selectedArea, setSelectedArea] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [genderPref, setGenderPref] = useState('all');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch({
      area: selectedArea,
      categoryId: selectedCategory,
      date: selectedDate,
      genderPref
    });
  };

  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:pt-14 lg:pb-24 border-b border-stone-200/70 bg-gradient-to-b from-[#FAF7F5] via-[#F6EDE9]/40 to-[#FAF7F5]">
      {/* Subtle background ornamentation */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-rose-200/20 blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 rounded-full bg-amber-100/30 blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-10">
          
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#721C38] tracking-widest uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-[#721C38]"></span>
            {t.tagline}
          </div>

          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-stone-900 leading-[1.15]">
            {t.heroHeadline}
          </h1>

          <p className="text-base sm:text-lg text-stone-600 max-w-2xl mx-auto font-normal leading-relaxed">
            {t.heroSub}
          </p>

          <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => {
                const el = document.getElementById('explore-listings');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-6 py-3 bg-[#721C38] hover:bg-[#58152B] text-white font-medium text-sm rounded-xl shadow-sm transition-all hover:shadow-md cursor-pointer"
            >
              {t.explore}
            </button>
            {!isAuthenticated ? (
              <button
                onClick={() => {
                  setAuthModalMode('signup');
                  setAuthModalOpen(true);
                }}
                className="px-6 py-3 bg-white hover:bg-stone-50 text-stone-800 border border-stone-200 font-medium text-sm rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-2"
              >
                <span>{language === 'bn' ? 'সাইন আপ করুন' : 'Sign Up Free'}</span>
              </button>
            ) : !currentUser.isProviderActive ? (
              <button
                onClick={onBecomeCompanion}
                className="px-6 py-3 bg-white hover:bg-stone-50 text-stone-800 border border-stone-200 font-medium text-sm rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                {t.becomeCompanion}
              </button>
            ) : null}
          </div>
        </div>

        {/* Discovery Filter Bar */}
        <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-md border border-stone-200/90 p-3 sm:p-4">
          <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            
            {/* Area in Dhaka */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-stone-600 uppercase tracking-wider flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#721C38]" />
                Location
              </label>
              <select
                value={selectedArea}
                onChange={(e) => setSelectedArea(e.target.value)}
                className="w-full text-xs font-medium text-stone-900 bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-2 focus:ring-1 focus:ring-[#721C38] focus:outline-none"
              >
                <option value="">All Dhaka Areas</option>
                <option value="Gulshan">Gulshan 1 & 2</option>
                <option value="Banani">Banani</option>
                <option value="Dhanmondi">Dhanmondi</option>
                <option value="Uttara">Uttara</option>
                <option value="Bashundhara">Bashundhara R/A</option>
                <option value="Mohakhali">Mohakhali DOHS</option>
                <option value="Old Dhaka">Old Dhaka</option>
              </select>
            </div>

            {/* Experience Category */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-stone-600 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-700" />
                Experience
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full text-xs font-medium text-stone-900 bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-2 focus:ring-1 focus:ring-[#721C38] focus:outline-none"
              >
                <option value="">All 10 Categories</option>
                {categories.filter(c => c.isActive).map(c => (
                  <option key={c.id} value={c.id}>
                    {language === 'bn' ? c.nameBn : c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Companion Gender */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-stone-600 uppercase tracking-wider flex items-center gap-1.5">
                <Heart className="w-3.5 h-3.5 text-rose-600" />
                Companion Gender
              </label>
              <select
                value={genderPref}
                onChange={(e) => setGenderPref(e.target.value)}
                className="w-full text-xs font-medium text-stone-900 bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-2 focus:ring-1 focus:ring-[#721C38] focus:outline-none"
              >
                <option value="all">All Genders</option>
                <option value="female">Women</option>
                <option value="male">Men</option>
              </select>
            </div>

            {/* Submit Button */}
            <div className="flex items-end">
              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-[#721C38] hover:bg-[#58152B] text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs"
              >
                <Search className="w-4 h-4" />
                <span>Search Companions</span>
              </button>
            </div>

          </form>
        </div>

        {/* Trust Badges Bar */}
        <div className="mt-10 pt-6 border-t border-stone-200/60 max-w-4xl mx-auto flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-xs text-stone-600 font-medium">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-700" />
            <span>Government ID Verified (NID/Passport)</span>
          </div>
          <span className="text-stone-300 hidden sm:inline">·</span>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-rose-700" />
            <span>100% Public Venues Only</span>
          </div>
          <span className="text-stone-300 hidden sm:inline">·</span>
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-700" />
            <span>Clear BDT (৳) Rates Per Hour/Session</span>
          </div>
        </div>

      </div>
    </section>
  );
};
