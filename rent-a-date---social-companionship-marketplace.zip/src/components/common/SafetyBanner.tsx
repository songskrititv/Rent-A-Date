import React from 'react';
import { ShieldCheck, Info } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { MANDATORY_CONSENT_NOTICE, MANDATORY_CONSENT_NOTICE_BN } from '../../utils/formatters';

export const SafetyBanner: React.FC<{ onOpenSafetyModal: () => void }> = ({ onOpenSafetyModal }) => {
  const { language } = useApp();
  const notice = language === 'bn' ? MANDATORY_CONSENT_NOTICE_BN : MANDATORY_CONSENT_NOTICE;

  return (
    <div className="bg-gradient-to-r from-stone-900 via-[#3B0C1B] to-stone-900 text-stone-200 border-b border-rose-950/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5">
        <div className="flex flex-col md:flex-row items-center justify-between gap-3 text-xs leading-relaxed">
          <div className="flex items-start sm:items-center gap-2.5">
            <span className="p-1 rounded-md bg-rose-500/20 text-rose-300 shrink-0 mt-0.5 sm:mt-0">
              <ShieldCheck className="w-4 h-4" />
            </span>
            <p className="text-stone-300 font-normal">
              <strong className="text-rose-200 font-semibold mr-1">Platform Boundary Policy:</strong>
              {notice}
            </p>
          </div>
          <button
            onClick={onOpenSafetyModal}
            className="shrink-0 flex items-center gap-1.5 px-3 py-1 text-[11px] font-semibold text-rose-200 bg-rose-900/40 hover:bg-rose-900/70 border border-rose-700/50 rounded-lg transition-colors whitespace-nowrap self-end md:self-auto"
          >
            <Info className="w-3.5 h-3.5" />
            <span>Safety Guidelines</span>
          </button>
        </div>
      </div>
    </div>
  );
};
