import React from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../utils/formatters';
import { 
  Search, 
  ShieldCheck, 
  CalendarCheck, 
  CreditCard, 
  Heart, 
  HelpCircle, 
  ArrowRight,
  Sparkles,
  MapPin,
  Lock
} from 'lucide-react';

export const HowItWorksView: React.FC<{ onExplore: () => void; onBecomeCompanion: () => void }> = ({
  onExplore,
  onBecomeCompanion
}) => {
  const { language, currentUser } = useApp();
  const t = TRANSLATIONS[language];

  const faqs = [
    {
      q: "What exactly is Rent a Date?",
      a: "Rent a Date is a paid social companionship marketplace operating in Bangladesh. Adults can discover and hire polite, engaging companions to accompany them to coffee meetups, restaurants, cultural exhibitions, concerts, or city walks. It is strictly for platonic or social companionship."
    },
    {
      q: "Is Rent a Date an escort or adult dating platform?",
      a: "No, absolutely not. Rent a Date has an uncompromising zero-tolerance policy against escorting, prostitution, physical intimacy, or sexual activities. All bookings occur exclusively in verified public venues in Dhaka."
    },
    {
      q: "Can one account both book companions and offer companion services?",
      a: "Yes! Our unified architecture allows any eligible adult (aged 18+) to switch between 'Book Services' and 'Manage My Services' from the exact same account without creating multiple logins."
    },
    {
      q: "How does the pricing and payment system work?",
      a: "Companions set their own rates in Bangladeshi Taka (৳ BDT) for each distinct service (e.g. ৳800/hr for Coffee, ৳1,800/session for Dinner). A standard 20% platform operational fee is included in checkout. Payments are processed through simulated Bangladesh payment gateways (bKash, Nagad, SSLCOMMERZ)."
    },
    {
      q: "How are identities verified?",
      a: "Companions submit their Bangladesh National ID (Smart NID) or Passport to our operations compliance team before receiving a verified trust badge on their public profile."
    },
    {
      q: "What happens if I need to cancel my booking?",
      a: "Cancellations made within the companion's stated advance window (e.g., 24 or 48 hours prior) are fully eligible for refunds according to published cancellation policies."
    }
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      
      {/* Hero Header */}
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <span className="text-xs font-semibold uppercase tracking-widest text-[#721C38]">
          Transparent Marketplace Mechanics
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900">
          How Rent a Date Works
        </h1>
        <p className="text-sm sm:text-base text-stone-600 leading-relaxed">
          Connecting thoughtful people for unforgettable social experiences in Dhaka. Clear rates, verified identities, and ironclad safety standards.
        </p>
      </div>

      {/* Customer Journey: 4 Steps */}
      <div className="space-y-6">
        <div className="border-b border-stone-200 pb-3">
          <h2 className="font-serif text-2xl font-bold text-stone-900">For Clients (Booking an Experience)</h2>
          <p className="text-xs text-stone-500">From discovery to memorable companionship in 4 simple steps.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-3 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-[#721C38] flex items-center justify-center font-bold text-sm">
              1
            </div>
            <h3 className="font-serif font-bold text-base text-stone-900">Explore & Filter</h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Browse vetted companions across Dhaka. Filter by neighborhood (Gulshan, Dhanmondi, Banani), interests, budget, and experience type.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-3 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-[#721C38] flex items-center justify-center font-bold text-sm">
              2
            </div>
            <h3 className="font-serif font-bold text-base text-stone-900">Select Specific Service</h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Each companion offers multiple published experiences with upfront pricing per hour or session and explicit service boundaries.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-3 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-[#721C38] flex items-center justify-center font-bold text-sm">
              3
            </div>
            <h3 className="font-serif font-bold text-base text-stone-900">Sign Safety Agreement</h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Agree to the mutual consent policy and select a verified public venue in Dhaka. Complete secure payment via bKash, Nagad or SSLCOMMERZ.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-3 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-[#721C38] flex items-center justify-center font-bold text-sm">
              4
            </div>
            <h3 className="font-serif font-bold text-base text-stone-900">Enjoy & Review</h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Meet at the scheduled public venue. After the session concludes, leave verified ratings to strengthen community trust.
            </p>
          </div>
        </div>
      </div>

      {/* Provider Journey: 4 Steps */}
      <div className="space-y-6">
        <div className="border-b border-stone-200 pb-3">
          <h2 className="font-serif text-2xl font-bold text-stone-900">For Companions (Offering Experiences)</h2>
          <p className="text-xs text-stone-500">Monetize your social intelligence, cultural knowledge, and great conversation.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-3 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center font-bold text-sm">
              1
            </div>
            <h3 className="font-serif font-bold text-base text-stone-900">Activate Provider Workspace</h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Toggle to provider mode from your existing account. Complete your public profile with Dhaka neighborhood, bio, and cultural interests.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-3 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center font-bold text-sm">
              2
            </div>
            <h3 className="font-serif font-bold text-base text-stone-900">Publish Multi-Tier Services</h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Create individual listings (e.g., ৳800/hr Coffee, ৳1,800 Dinner, ৳2,500 City Tour) with your custom rules and boundaries.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-3 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center font-bold text-sm">
              3
            </div>
            <h3 className="font-serif font-bold text-base text-stone-900">Verify Government Identity</h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Upload your National ID or Passport to receive the verified shield, unlocking maximum booking volume and client trust.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-3 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center font-bold text-sm">
              4
            </div>
            <h3 className="font-serif font-bold text-base text-stone-900">Receive Direct Payouts</h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Accept or decline booking requests. Review your gross earnings minus 20% platform fee and withdraw instantly to bKash or Nagad.
            </p>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="space-y-6 pt-6">
        <div className="text-center space-y-2">
          <div className="inline-flex p-2 bg-stone-100 rounded-full text-stone-700">
            <HelpCircle className="w-5 h-5" />
          </div>
          <h2 className="font-serif text-2xl font-bold text-stone-900">Frequently Asked Questions</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {faqs.map((faq, idx) => (
            <div key={idx} className="bg-white p-5 rounded-2xl border border-stone-200 space-y-2 shadow-2xs">
              <h3 className="font-serif font-bold text-sm text-stone-900">{faq.q}</h3>
              <p className="text-xs text-stone-600 leading-relaxed">{faq.a}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom CTA Banner */}
      <div className="bg-gradient-to-r from-[#721C38] via-[#5B142B] to-[#3B0C1B] rounded-3xl p-8 sm:p-12 text-white text-center space-y-4 shadow-lg">
        <h2 className="font-serif text-2xl sm:text-3xl font-bold">Ready to Experience Great Company?</h2>
        <p className="text-xs sm:text-sm text-rose-100 max-w-xl mx-auto">
          Explore vetted companions for coffee, fine dining, cultural galas, or city explorations across Dhaka today.
        </p>
        <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={onExplore}
            className="px-6 py-3 bg-white text-stone-900 hover:bg-stone-100 font-semibold text-xs rounded-xl transition-all shadow-sm cursor-pointer"
          >
            Explore Companions in Dhaka
          </button>
          {!currentUser.isProviderActive && (
            <button
              onClick={onBecomeCompanion}
              className="px-6 py-3 bg-rose-900/60 hover:bg-rose-900/80 border border-rose-300/40 text-white font-semibold text-xs rounded-xl transition-all cursor-pointer"
            >
              Become a Companion
            </button>
          )}
        </div>
      </div>

    </div>
  );
};
