import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../utils/formatters';
import { 
  Heart, 
  ShieldCheck, 
  MessageSquare, 
  UserCheck, 
  Globe, 
  Menu, 
  X, 
  Sparkles,
  ArrowRightLeft,
  ChevronDown,
  Lock,
  Layers,
  CalendarCheck,
  LogIn,
  UserPlus,
  LogOut,
  Gift,
  Wallet,
  Smartphone
} from 'lucide-react';

export const Header: React.FC<{ 
  onOpenSafetyModal: () => void; 
  onOpenMessages: () => void;
  onOpenPhoneInstallModal?: () => void;
}> = ({
  onOpenSafetyModal,
  onOpenMessages,
  onOpenPhoneInstallModal
}) => {
  const { 
    currentUser, 
    allUsers, 
    switchUser, 
    activeRole, 
    setActiveRole, 
    activeView, 
    setActiveView, 
    language, 
    setLanguage,
    notificationCount,
    activateProviderStatus,
    setAuthModalOpen,
    setAuthModalMode,
    logout,
    isAuthenticated,
    walletCredits
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const t = TRANSLATIONS[language];

  return (
    <header className="sticky top-0 z-40 bg-[#FAF7F5]/90 backdrop-blur-md border-b border-stone-200/80 transition-all">
      {/* Top Demo Simulation Notice Bar */}
      <div className="bg-stone-900 text-stone-300 text-xs py-1.5 px-4 text-center flex items-center justify-center gap-2">
        <span className="inline-block w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
        <span className="font-medium text-rose-200">BANGLADESH PILOT · DHAKA MARKET</span>
        <span className="text-stone-500 hidden sm:inline">|</span>
        <span className="hidden sm:inline text-stone-400">Strictly Non-Sexual Social Companionship Platform · 18+ Only</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          
          {/* Logo & Tagline */}
          <div className="flex items-center gap-8">
            <button 
              onClick={() => { setActiveView('explore'); }}
              className="flex items-center gap-2.5 text-left group focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#721C38] to-[#4A0E22] flex items-center justify-center text-rose-100 shadow-sm group-hover:scale-105 transition-transform">
                <Heart className="w-5 h-5 fill-rose-300/30 text-rose-200" />
              </div>
              <div>
                <span className="font-serif text-2xl font-bold tracking-tight text-stone-900 group-hover:text-[#721C38] transition-colors">
                  Rent a Date
                </span>
                <span className="block text-[10px] uppercase tracking-widest text-stone-500 font-medium -mt-1">
                  Social Companions
                </span>
              </div>
            </button>

            {/* Desktop Navigation Links */}
            <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
              <button
                onClick={() => setActiveView('explore')}
                className={`transition-colors py-1 ${activeView === 'explore' ? 'text-[#721C38] font-semibold border-b-2 border-[#721C38]' : 'text-stone-600 hover:text-stone-900'}`}
              >
                {t.explore}
              </button>
              <button
                onClick={() => setActiveView('how_it_works')}
                className={`transition-colors py-1 ${activeView === 'how_it_works' ? 'text-[#721C38] font-semibold border-b-2 border-[#721C38]' : 'text-stone-600 hover:text-stone-900'}`}
              >
                {t.howItWorks}
              </button>
              <button
                onClick={onOpenSafetyModal}
                className="text-stone-600 hover:text-stone-900 transition-colors flex items-center gap-1.5 py-1"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                {t.safety}
              </button>
              <button
                onClick={() => setActiveView('referral_program')}
                className={`transition-colors py-1 flex items-center gap-1.5 ${activeView === 'referral_program' ? 'text-[#721C38] font-semibold border-b-2 border-[#721C38]' : 'text-stone-600 hover:text-stone-900'}`}
              >
                <Gift className="w-3.5 h-3.5 text-rose-600" />
                <span>{t.referralProgram}</span>
                {walletCredits > 0 && (
                  <span className="text-[10px] font-mono font-bold bg-rose-100 text-[#721C38] px-1.5 py-0.2 rounded">
                    ৳{walletCredits}
                  </span>
                )}
              </button>
            </nav>
          </div>

          {/* Right Controls: Role Switch, Demo User Switcher, Language & Profile */}
          <div className="hidden lg:flex items-center gap-2.5">
            {/* Install on Phone / Test Button */}
            <button
              onClick={onOpenPhoneInstallModal}
              className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl border border-emerald-300 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 transition-colors shadow-2xs cursor-pointer group"
              title="Install & Test on Mobile Phone"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-600 group-hover:scale-110 transition-transform" />
              <span>{language === 'bn' ? 'ফোনে ইনস্টল' : 'Install on Phone'}</span>
            </button>
            
            {/* Language Switch */}
            <button
              onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
              className="flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-stone-200 text-stone-700 hover:bg-stone-100 transition-colors"
              title="Toggle English / Bangla"
            >
              <Globe className="w-3.5 h-3.5 text-stone-500" />
              <span>{language === 'en' ? 'বাং' : 'EN'}</span>
            </button>

            {/* In-app Messages Trigger */}
            <button
              onClick={onOpenMessages}
              className="relative p-2 rounded-lg text-stone-600 hover:text-stone-900 hover:bg-stone-100 transition-colors"
              title="Messages"
            >
              <MessageSquare className="w-5 h-5" />
              {notificationCount > 0 && (
                <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-rose-600"></span>
              )}
            </button>

            {/* Unified Role Switcher (Book Services ↔ Manage My Services ↔ Admin) */}
            <div className="flex items-center bg-stone-100/90 p-1 rounded-xl border border-stone-200">
              <button
                onClick={() => {
                  setActiveRole('customer');
                  setActiveView('customer_dashboard');
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-1.5 ${
                  activeRole === 'customer'
                    ? 'bg-white text-stone-900 shadow-xs font-semibold'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <CalendarCheck className="w-3.5 h-3.5 text-[#721C38]" />
                {t.bookServices}
              </button>

              {currentUser.isProviderActive ? (
                <button
                  onClick={() => {
                    setActiveRole('provider');
                    setActiveView('provider_dashboard');
                  }}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-1.5 ${
                    activeRole === 'provider'
                      ? 'bg-white text-stone-900 shadow-xs font-semibold'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5 text-amber-700" />
                  {t.manageServices}
                </button>
              ) : (
                <button
                  onClick={activateProviderStatus}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg transition-all text-stone-600 hover:text-stone-900 hover:bg-white/60 flex items-center gap-1"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  {t.becomeCompanion}
                </button>
              )}

              {currentUser.isAdmin && (
                <button
                  onClick={() => {
                    setActiveRole('admin');
                    setActiveView('admin_dashboard');
                  }}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-1.5 ${
                    activeRole === 'admin'
                      ? 'bg-stone-900 text-white shadow-xs font-semibold'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <Lock className="w-3.5 h-3.5 text-rose-400" />
                  Admin
                </button>
              )}
            </div>

            {/* Direct Sign In & Sign Up or Profile Menu */}
            {!isAuthenticated ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setAuthModalMode('signin');
                    setAuthModalOpen(true);
                  }}
                  className="px-3.5 py-1.5 text-xs font-bold text-stone-700 hover:text-stone-900 border border-stone-200 hover:border-stone-300 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 bg-white shadow-2xs"
                >
                  <LogIn className="w-3.5 h-3.5 text-[#721C38]" />
                  <span>{t.signIn}</span>
                </button>
                <button
                  onClick={() => {
                    setAuthModalMode('signup');
                    setAuthModalOpen(true);
                  }}
                  className="px-4 py-1.5 text-xs font-bold text-white bg-[#721C38] hover:bg-[#58152B] rounded-xl transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>{t.signUp}</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setAuthModalMode('signup');
                    setAuthModalOpen(true);
                  }}
                  className="px-3 py-1.5 text-xs font-medium text-stone-700 hover:text-stone-900 border border-stone-200 hover:bg-stone-50 rounded-xl transition-colors cursor-pointer hidden xl:flex items-center gap-1.5"
                  title={language === 'bn' ? 'নতুন অ্যাকাউন্ট তৈরি করুন' : 'Create new account'}
                >
                  <UserPlus className="w-3.5 h-3.5 text-[#721C38]" />
                  <span>{language === 'bn' ? 'নতুন অ্যাকাউন্ট' : '+ Register'}</span>
                </button>

                {/* Demo Switcher Quick Menu */}
                <div className="relative">
                  <button
                    onClick={() => setUserMenuOpen(!userMenuOpen)}
                    className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-full border border-stone-200 bg-white hover:border-stone-300 transition-colors shadow-xs"
                  >
                    <img
                      src={currentUser.avatar}
                      alt={currentUser.displayName}
                      className="w-7 h-7 rounded-full object-cover border border-stone-200"
                    />
                    <div className="text-left leading-tight hidden xl:block">
                      <div className="text-xs font-semibold text-stone-900 truncate max-w-[100px]">
                        {currentUser.displayName}
                      </div>
                      <div className="text-[10px] text-stone-500 capitalize">
                        {activeRole}
                      </div>
                    </div>
                    <ChevronDown className="w-3.5 h-3.5 text-stone-400" />
                  </button>

                  {userMenuOpen && (
                    <div 
                      className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-lg border border-stone-200 py-2 z-50"
                      onMouseLeave={() => setUserMenuOpen(false)}
                    >
                      <div className="px-3 py-2 border-b border-stone-100">
                        <p className="text-xs font-semibold text-stone-800">
                          {language === 'bn' ? 'ব্যবহারকারী অ্যাকাউন্ট সুইচ করুন' : 'Quick Persona Switcher (Demo)'}
                        </p>
                        <p className="text-[11px] text-stone-500">
                          {language === 'bn' ? 'ভিন্ন ভিন্ন প্রোফাইল থেকে টেস্ট করুন' : 'Test Rent a Date under different accounts'}
                        </p>
                      </div>
                  
                  <div className="max-h-60 overflow-y-auto py-1">
                    {allUsers.map(user => (
                      <button
                        key={user.id}
                        onClick={() => {
                          switchUser(user.id);
                          setUserMenuOpen(false);
                        }}
                        className={`w-full px-3 py-2 text-left flex items-center gap-2.5 hover:bg-stone-50 transition-colors ${
                          user.id === currentUser.id ? 'bg-rose-50/50' : ''
                        }`}
                      >
                        <img 
                          src={user.avatar} 
                          alt={user.displayName} 
                          className="w-8 h-8 rounded-full object-cover border border-stone-200" 
                        />
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-medium text-stone-900 truncate flex items-center gap-1.5">
                            {user.displayName}
                            {user.verificationStatus === 'verified' && (
                              <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1 py-0.2 rounded font-semibold flex items-center gap-0.5 shrink-0">
                                <ShieldCheck className="w-2.5 h-2.5 text-emerald-600" />
                                {language === 'bn' ? 'ভেরিফাইড' : 'VERIFIED'}
                              </span>
                            )}
                            {user.isAdmin && <span className="text-[9px] bg-stone-800 text-white px-1.5 py-0.2 rounded">ADMIN</span>}
                            {user.isProviderActive && <span className="text-[9px] bg-rose-100 text-[#721C38] px-1.5 py-0.2 rounded font-semibold">PROVIDER</span>}
                          </div>
                          <div className="text-[11px] text-stone-500 truncate">{user.area} · {user.gender}</div>
                        </div>
                        {user.id === currentUser.id && (
                          <span className="w-2 h-2 rounded-full bg-[#721C38]"></span>
                        )}
                      </button>
                    ))}
                  </div>

                  <div className="border-t border-stone-100 mt-1 pt-2 px-3 pb-1 space-y-1.5">
                    <button
                      onClick={() => {
                        setActiveView('customer_dashboard');
                        setUserMenuOpen(false);
                      }}
                      className="text-xs text-stone-700 hover:text-[#721C38] font-medium block py-1 w-full text-left"
                    >
                      {language === 'bn' ? 'অ্যাকাউন্ট ও প্রোফাইল সেটিংস' : 'View Account & Profile Settings'}
                    </button>
                    <button
                      onClick={() => {
                        setActiveView('referral_program');
                        setUserMenuOpen(false);
                      }}
                      className="text-xs text-stone-700 hover:text-[#721C38] font-medium py-1 w-full text-left flex items-center justify-between"
                    >
                      <span className="flex items-center gap-1.5">
                        <Gift className="w-3.5 h-3.5 text-rose-600" />
                        <span>{t.referralProgram}</span>
                      </span>
                      <span className="font-mono text-[10px] font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                        ৳{walletCredits}
                      </span>
                    </button>
                    <div className="border-t border-stone-100 pt-1.5 flex items-center justify-between gap-2">
                      <button
                        onClick={() => {
                          setAuthModalMode('signin');
                          setAuthModalOpen(true);
                          setUserMenuOpen(false);
                        }}
                        className="text-xs font-semibold text-[#721C38] hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <LogIn className="w-3.5 h-3.5" />
                        <span>Sign In</span>
                      </button>
                      <button
                        onClick={() => {
                          setAuthModalMode('signup');
                          setAuthModalOpen(true);
                          setUserMenuOpen(false);
                        }}
                        className="text-xs font-semibold text-stone-700 hover:text-stone-900 flex items-center gap-1 cursor-pointer"
                      >
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Sign Up</span>
                      </button>
                      <button
                        onClick={() => {
                          logout();
                          setUserMenuOpen(false);
                        }}
                        className="text-xs text-rose-600 hover:underline flex items-center gap-1 cursor-pointer"
                        title="Log out from current session"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Exit</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

      </div>

          {/* Mobile menu trigger */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
              className="text-xs font-semibold px-2 py-1 rounded border border-stone-200 text-stone-700"
            >
              {language === 'en' ? 'বাং' : 'EN'}
            </button>
            <button
              onClick={onOpenMessages}
              className="p-2 text-stone-700 hover:text-stone-900"
            >
              <MessageSquare className="w-5 h-5" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-stone-700 hover:bg-stone-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-stone-200 bg-[#FAF7F5] px-4 pt-3 pb-6 space-y-4">
          
          {/* Mobile Auth Quick Buttons */}
          <div className="grid grid-cols-2 gap-2 pb-1 border-b border-stone-200/80">
            <button
              onClick={() => {
                setAuthModalMode('signin');
                setAuthModalOpen(true);
                setMobileMenuOpen(false);
              }}
              className="py-2.5 px-3 text-xs font-bold rounded-xl border border-stone-200 bg-white text-stone-800 hover:bg-stone-50 flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
            >
              <LogIn className="w-4 h-4 text-[#721C38]" />
              <span>{t.signIn}</span>
            </button>
            <button
              onClick={() => {
                setAuthModalMode('signup');
                setAuthModalOpen(true);
                setMobileMenuOpen(false);
              }}
              className="py-2.5 px-3 text-xs font-bold rounded-xl bg-[#721C38] text-white hover:bg-[#58152B] flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>{t.signUp}</span>
            </button>
          </div>

          {/* Mobile Install on Phone Banner Trigger */}
          <button
            onClick={() => {
              if (onOpenPhoneInstallModal) onOpenPhoneInstallModal();
              setMobileMenuOpen(false);
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm cursor-pointer"
          >
            <Smartphone className="w-4 h-4" />
            <span>{language === 'bn' ? 'ফোনে ইনস্টল করুন (PWA)' : 'Install App on Phone (PWA)'}</span>
          </button>

          <div className="flex flex-col gap-2 pt-1">
            <button
              onClick={() => { setActiveView('explore'); setMobileMenuOpen(false); }}
              className="text-left py-2 font-medium text-stone-800"
            >
              {t.explore}
            </button>
            <button
              onClick={() => { setActiveView('how_it_works'); setMobileMenuOpen(false); }}
              className="text-left py-2 font-medium text-stone-800"
            >
              {t.howItWorks}
            </button>
            <button
              onClick={() => { onOpenSafetyModal(); setMobileMenuOpen(false); }}
              className="text-left py-2 font-medium text-stone-800 flex items-center gap-2"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              {t.safety}
            </button>
            <button
              onClick={() => { setActiveView('referral_program'); setMobileMenuOpen(false); }}
              className="text-left py-2 font-medium text-stone-800 flex items-center justify-between"
            >
              <span className="flex items-center gap-2">
                <Gift className="w-4 h-4 text-rose-600" />
                <span>{t.referralProgram}</span>
              </span>
              {walletCredits > 0 && (
                <span className="text-[10px] font-mono font-bold bg-rose-100 text-[#721C38] px-2 py-0.5 rounded">
                  ৳{walletCredits}
                </span>
              )}
            </button>
          </div>

          <div className="border-t border-stone-200 pt-3">
            <div className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2">Switch Workspace</div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => { setActiveRole('customer'); setActiveView('customer_dashboard'); setMobileMenuOpen(false); }}
                className={`py-2 text-xs font-medium rounded-lg text-center ${activeRole === 'customer' ? 'bg-[#721C38] text-white font-bold' : 'bg-stone-100 text-stone-800'}`}
              >
                Customer Mode
              </button>
              {currentUser.isProviderActive ? (
                <button
                  onClick={() => { setActiveRole('provider'); setActiveView('provider_dashboard'); setMobileMenuOpen(false); }}
                  className={`py-2 text-xs font-medium rounded-lg text-center ${activeRole === 'provider' ? 'bg-[#721C38] text-white font-bold' : 'bg-stone-100 text-stone-800'}`}
                >
                  Provider Workspace
                </button>
              ) : (
                <button
                  onClick={() => { activateProviderStatus(); setMobileMenuOpen(false); }}
                  className="py-2 text-xs font-medium rounded-lg text-center bg-stone-200 text-stone-800"
                >
                  Become Provider
                </button>
              )}
            </div>
            {currentUser.isAdmin && (
              <button
                onClick={() => { setActiveRole('admin'); setActiveView('admin_dashboard'); setMobileMenuOpen(false); }}
                className="w-full mt-2 py-2 text-xs font-medium rounded-lg text-center bg-stone-900 text-white"
              >
                Admin Panel
              </button>
            )}
          </div>

          {isAuthenticated && (
            <div className="border-t border-stone-200 pt-3">
              <div className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2">
                {language === 'bn' ? 'বর্তমান ব্যবহারকারী' : 'Logged in as'}
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img src={currentUser.avatar} alt={currentUser.displayName} className="w-10 h-10 rounded-full object-cover border border-stone-200" />
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-stone-900 truncate">{currentUser.fullName}</div>
                    <div className="text-xs text-stone-500 truncate">{currentUser.email}</div>
                  </div>
                </div>
                <button
                  onClick={() => {
                    logout();
                    setMobileMenuOpen(false);
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-lg flex items-center gap-1 cursor-pointer"
                  title="Logout"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{t.logout}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
