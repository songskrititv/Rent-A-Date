import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { PhoneOff, Mic, MicOff, Volume2, ShieldCheck, Lock } from 'lucide-react';

export const VoiceCallModal: React.FC = () => {
  const { activeVoiceCallPartner, setActiveVoiceCallPartner } = useApp();
  const [callDurationSec, setCallDurationSec] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeaker, setIsSpeaker] = useState(true);
  const [callStatus, setCallStatus] = useState<'connecting' | 'connected'>('connecting');

  useEffect(() => {
    if (!activeVoiceCallPartner) {
      setCallDurationSec(0);
      setCallStatus('connecting');
      return;
    }

    const connectTimeout = setTimeout(() => {
      setCallStatus('connected');
    }, 1500);

    const interval = setInterval(() => {
      setCallDurationSec(prev => prev + 1);
    }, 1000);

    return () => {
      clearTimeout(connectTimeout);
      clearInterval(interval);
    };
  }, [activeVoiceCallPartner]);

  if (!activeVoiceCallPartner) return null;

  const formatTimer = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-stone-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div 
        className="bg-stone-900 border border-stone-800 text-white max-w-sm w-full rounded-3xl shadow-2xl p-6 text-center space-y-6 flex flex-col items-center"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Security Tag */}
        <div className="inline-flex items-center gap-1.5 text-[10px] font-semibold text-emerald-400 bg-emerald-950/80 border border-emerald-800/80 px-2.5 py-1 rounded-full">
          <Lock className="w-3 h-3" />
          <span>Encrypted Voice Call · Masked Number</span>
        </div>

        {/* Partner Photo & Wave animation */}
        <div className="relative my-2">
          <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-emerald-500 shadow-xl mx-auto">
            <img 
              src={activeVoiceCallPartner.avatar} 
              alt={activeVoiceCallPartner.displayName} 
              className="w-full h-full object-cover"
            />
          </div>
          {callStatus === 'connected' && (
            <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-500"></span>
            </span>
          )}
        </div>

        {/* Name and State */}
        <div className="space-y-1">
          <h3 className="font-serif font-bold text-xl text-white">
            {activeVoiceCallPartner.displayName}
          </h3>
          <p className="text-xs text-stone-400">
            {callStatus === 'connecting' ? 'Establishing secure voice relay...' : `Call Connected · ${formatTimer(callDurationSec)}`}
          </p>
          <span className="text-[11px] text-stone-500 block">
            {activeVoiceCallPartner.area}, Dhaka
          </span>
        </div>

        {/* Sound Wave Visualizer Simulation */}
        <div className="flex items-center justify-center gap-1 h-8">
          {[12, 24, 16, 32, 20, 28, 14, 26, 18].map((h, i) => (
            <div 
              key={i} 
              className={`w-1 bg-emerald-400 rounded-full transition-all duration-300 ${callStatus === 'connected' ? 'animate-pulse' : 'opacity-30'}`}
              style={{ height: `${callStatus === 'connected' ? h : 8}px` }}
            ></div>
          ))}
        </div>

        {/* Interactive Controls */}
        <div className="flex items-center justify-center gap-4 pt-2">
          {/* Mute Button */}
          <button
            onClick={() => setIsMuted(!isMuted)}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
              isMuted ? 'bg-stone-700 text-rose-400' : 'bg-stone-800 text-stone-200 hover:bg-stone-700'
            }`}
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* End Call Button */}
          <button
            onClick={() => setActiveVoiceCallPartner(null)}
            className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-700 text-white flex items-center justify-center transition-transform hover:scale-105 shadow-lg shadow-rose-900/50 cursor-pointer"
            title="End Call"
          >
            <PhoneOff className="w-6 h-6" />
          </button>

          {/* Speaker Button */}
          <button
            onClick={() => setIsSpeaker(!isSpeaker)}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
              isSpeaker ? 'bg-emerald-900/60 text-emerald-400 border border-emerald-700' : 'bg-stone-800 text-stone-200 hover:bg-stone-700'
            }`}
            title={isSpeaker ? 'Speaker On' : 'Speaker Off'}
          >
            <Volume2 className="w-5 h-5" />
          </button>
        </div>

        <p className="text-[10px] text-stone-500">
          Calls are routed through our secure voice proxy to protect your private Bangladesh phone number.
        </p>
      </div>
    </div>
  );
};
