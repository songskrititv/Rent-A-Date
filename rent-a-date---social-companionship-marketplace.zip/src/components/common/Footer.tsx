import React from 'react';
import { Heart, Shield, PhoneCall, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const Footer: React.FC<{ onOpenSafetyModal: () => void }> = ({ onOpenSafetyModal }) => {
  const { setActiveView } = useApp();

  return (
    <footer className="bg-stone-900 text-stone-300 border-t border-stone-800 text-sm mt-24">
      {/* Safety highlight bar */}
      <div className="border-b border-stone-800 py-8 bg-stone-950/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-white font-medium text-sm">Verified Identities (NID / Passport)</h4>
              <p className="text-stone-400 text-xs mt-1">
                Companions submit government IDs before listing services. Profiles indicate genuine verification status.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-white font-medium text-sm">Public Venue Standard</h4>
              <p className="text-stone-400 text-xs mt-1">
                All meetups occur in public cafes, restaurants, galleries, or cultural venues across Dhaka. No private home visits.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <PhoneCall className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-white font-medium text-sm">Emergency Assistance: 999</h4>
              <p className="text-stone-400 text-xs mt-1">
                Emergency services 999 are integrated into our safety guidelines alongside 24/7 in-app incident reporting.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-10">
          
          {/* Col 1 & 2: Brand & Mission */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#721C38] to-[#4A0E22] flex items-center justify-center text-rose-100 shadow-sm">
                <Heart className="w-4 h-4 fill-rose-300/30 text-rose-200" />
              </div>
              <span className="font-serif text-2xl font-bold text-white tracking-tight">
                Rent a Date
              </span>
            </div>
            
            <p className="text-stone-400 text-xs leading-relaxed max-w-sm">
              Rent a Date is Bangladesh's dedicated paid social companionship marketplace. We connect vetted adult companions with individuals seeking engaging company for dining, gallery tours, cultural events, and conversational meetups.
            </p>

            <div className="p-3 bg-stone-800/80 rounded-xl border border-stone-700/60 text-xs space-y-1">
              <div className="flex items-center gap-1.5 text-rose-300 font-semibold text-[11px] uppercase tracking-wide">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                Zero-Tolerance Legal Notice
              </div>
              <p className="text-stone-400 text-[11px] leading-normal">
                This platform is strictly for consensual social companionship. It is NOT an escort agency or sexual services platform. Any solicitation, exploitation, or non-consensual behavior will result in immediate termination, blacklisting, and reporting to legal authorities.
              </p>
            </div>
          </div>

          {/* Col 3: Experiences */}
          <div className="space-y-3">
            <h4 className="text-white font-semibold text-xs tracking-wider uppercase">Experiences</h4>
            <ul className="space-y-2 text-xs text-stone-400">
              <li><button onClick={() => setActiveView('explore')} className="hover:text-white transition-colors">Romantic Date</button></li>
              <li><button onClick={() => setActiveView('explore')} className="hover:text-white transition-colors">Coffee Meetup</button></li>
              <li><button onClick={() => setActiveView('explore')} className="hover:text-white transition-colors">Fine Dining Companion</button></li>
              <li><button onClick={() => setActiveView('explore')} className="hover:text-white transition-colors">Theatre & Cultural Events</button></li>
              <li><button onClick={() => setActiveView('explore')} className="hover:text-white transition-colors">Concert & Live Music</button></li>
              <li><button onClick={() => setActiveView('explore')} className="hover:text-white transition-colors">Old Dhaka Heritage Walk</button></li>
            </ul>
          </div>

          {/* Col 4: Operational Areas in Dhaka */}
          <div className="space-y-3">
            <h4 className="text-white font-semibold text-xs tracking-wider uppercase">Service Hubs (Dhaka)</h4>
            <ul className="space-y-1.5 text-xs text-stone-400">
              <li>Gulshan 1 & Gulshan 2</li>
              <li>Banani (Road 11 & Kemal Ataturk)</li>
              <li>Dhanmondi (Lakeside & 27)</li>
              <li>Uttara (Sectors 1 - 14)</li>
              <li>Bashundhara R/A & 300 Feet</li>
              <li>Mohakhali DOHS & Baridhara</li>
              <li>Old Dhaka (Heritage precinct)</li>
            </ul>
          </div>

          {/* Col 5: Trust, Safety & Legal */}
          <div className="space-y-3">
            <h4 className="text-white font-semibold text-xs tracking-wider uppercase">Trust & Policies</h4>
            <ul className="space-y-2 text-xs text-stone-400">
              <li>
                <button onClick={onOpenSafetyModal} className="hover:text-white transition-colors flex items-center gap-1 text-emerald-400">
                  <Shield className="w-3.5 h-3.5" />
                  Code of Conduct
                </button>
              </li>
              <li><button onClick={onOpenSafetyModal} className="hover:text-white transition-colors">Public Meetup Checklist</button></li>
              <li><button onClick={onOpenSafetyModal} className="hover:text-white transition-colors">Cancellation & Refunds</button></li>
              <li><button onClick={onOpenSafetyModal} className="hover:text-white transition-colors">Terms of Service</button></li>
              <li><button onClick={onOpenSafetyModal} className="hover:text-white transition-colors">Privacy & Data Handling</button></li>
              <li><button onClick={() => setActiveView('how_it_works')} className="hover:text-white transition-colors">How Bookings Work</button></li>
            </ul>
          </div>

        </div>

        {/* Bottom copyright and currency */}
        <div className="border-t border-stone-800 mt-12 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-400">
          <div>
            © {new Date().getFullYear()} Rent a Date (Bangladesh). All rights reserved. Registered for consensual social services.
          </div>
          <div className="flex items-center gap-4 text-stone-400">
            <span>Currency: <strong>Bangladeshi Taka (BDT, ৳)</strong></span>
            <span>·</span>
            <span>Age Requirement: <strong>18+ Adults Only</strong></span>
          </div>
        </div>
      </div>
    </footer>
  );
};
