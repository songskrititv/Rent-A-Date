import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { formatBDT, formatTime } from '../../utils/formatters';
import { 
  ShieldAlert, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  PhoneCall, 
  X, 
  AlertTriangle,
  HeartHandshake,
  Share2
} from 'lucide-react';

export const LiveMeetupModal: React.FC = () => {
  const { 
    bookings, 
    allUsers, 
    activeLiveBookingId, 
    endMeetup, 
    setActiveLiveBookingId, 
    submitReport 
  } = useApp();

  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [sosSent, setSosSent] = useState(false);
  const [trustedAlertSent, setTrustedAlertSent] = useState(false);

  const activeBooking = bookings.find(b => b.id === activeLiveBookingId);
  const partner = allUsers.find(u => u.id === activeBooking?.providerId);

  useEffect(() => {
    if (!activeLiveBookingId) return;
    const interval = setInterval(() => {
      setElapsedSeconds(prev => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [activeLiveBookingId]);

  if (!activeBooking || !partner) return null;

  const formatTimer = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleTriggerSOS = () => {
    setSosSent(true);
    submitReport({
      reportedUserId: partner.id,
      bookingCode: activeBooking.bookingCode,
      reason: 'Emergency SOS Triggered During Live Meetup',
      details: `Emergency alert flagged at venue ${activeBooking.meetupLocation}. Police emergency 999 hotline dispatched.`
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div 
        className="bg-white max-w-lg w-full rounded-3xl shadow-2xl border-2 border-emerald-500/80 overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Active Bar */}
        <div className="bg-emerald-950 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
            <div>
              <span className="text-[10px] text-emerald-300 font-bold uppercase tracking-wider block">
                ACTIVE VERIFIED MEETUP
              </span>
              <h3 className="font-serif font-bold text-base text-white">
                Live Session #{activeBooking.bookingCode}
              </h3>
            </div>
          </div>
          <button 
            onClick={() => setActiveLiveBookingId(null)}
            className="p-1.5 rounded-full hover:bg-emerald-900 text-stone-300"
            title="Minimize Tracker"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Timer & Companion Identity */}
        <div className="p-6 text-center space-y-4 bg-stone-50 border-b border-stone-200">
          <div className="relative inline-block">
            <img 
              src={partner.avatar} 
              alt={partner.displayName} 
              className="w-20 h-20 rounded-2xl object-cover mx-auto border-3 border-emerald-500 shadow-md"
            />
            <span className="absolute -bottom-2 -right-2 bg-emerald-600 text-white p-1 rounded-full text-xs shadow-xs">
              <CheckCircle2 className="w-4 h-4" />
            </span>
          </div>

          <div>
            <h4 className="font-serif font-bold text-lg text-stone-900">{partner.displayName}</h4>
            <p className="text-xs text-stone-500">{activeBooking.priceSnapshot.serviceTitle}</p>
          </div>

          {/* Elapsed Timer Box */}
          <div className="bg-white border border-stone-200/90 rounded-2xl py-3 px-6 inline-block shadow-2xs">
            <span className="text-[10px] uppercase font-bold text-stone-400 block tracking-wider">
              Elapsed Session Time
            </span>
            <span className="font-mono text-3xl font-bold text-stone-900 tracking-wider">
              {formatTimer(elapsedSeconds)}
            </span>
          </div>
        </div>

        {/* Location & Safety Checklist */}
        <div className="p-6 space-y-4 text-xs">
          <div className="bg-white border border-stone-200 p-3.5 rounded-2xl flex items-start gap-3">
            <MapPin className="w-5 h-5 text-[#721C38] shrink-0 mt-0.5" />
            <div>
              <span className="text-[10px] text-stone-400 uppercase font-semibold">Verified Public Venue</span>
              <div className="font-semibold text-stone-800 text-xs">{activeBooking.meetupLocation}</div>
              <span className="text-[11px] text-emerald-700 font-medium mt-0.5 block">
                ✓ Public establishment guidelines in effect
              </span>
            </div>
          </div>

          {/* SOS & Incident alert response */}
          {sosSent ? (
            <div className="bg-rose-50 border-2 border-rose-500 p-4 rounded-2xl text-rose-950 space-y-2 animate-bounce">
              <div className="font-bold flex items-center gap-1.5 text-sm text-rose-700">
                <AlertTriangle className="w-5 h-5" />
                Emergency SOS Broadcasted!
              </div>
              <p className="text-xs text-rose-900 leading-normal">
                Dhaka Operations Trust Team has been alerted with your live location. If you are in immediate danger, please dial <strong>999</strong> immediately.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={handleTriggerSOS}
                className="py-3 px-4 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs"
              >
                <ShieldAlert className="w-4 h-4" />
                <span>1-Click SOS (999)</span>
              </button>

              <button
                onClick={() => {
                  setTrustedAlertSent(true);
                  setTimeout(() => setTrustedAlertSent(false), 3000);
                }}
                className="py-3 px-4 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-2xl font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Share2 className="w-4 h-4 text-stone-600" />
                <span>{trustedAlertSent ? 'Check-in Sent!' : 'Share Status'}</span>
              </button>
            </div>
          )}

          {/* Complete Session Safely */}
          <div className="pt-2">
            <button
              onClick={() => endMeetup(activeBooking.id)}
              className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer"
            >
              <HeartHandshake className="w-4 h-4" />
              <span>Conclude Meetup Safely</span>
            </button>
            <p className="text-[11px] text-center text-stone-400 mt-2">
              Marking concluded will archive the session, release provider escrow, and open review options.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
};
