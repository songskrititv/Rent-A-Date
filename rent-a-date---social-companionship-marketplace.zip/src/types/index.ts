export type Gender = 'female' | 'male' | 'other' | 'prefer_not_to_say';
export type GenderPreference = 'all' | 'female' | 'male';
export type VerificationStatus = 'unverified' | 'pending' | 'verified' | 'rejected';
export type UserRole = 'customer' | 'provider' | 'admin';

export interface User {
  id: string;
  email: string;
  fullName: string;
  displayName: string;
  phone: string;
  avatar: string;
  bio: string;
  dateOfBirth: string; // YYYY-MM-DD
  gender: Gender;
  city: string; // e.g., Dhaka
  area: string; // e.g., Gulshan 2, Dhanmondi, Banani
  languages: string[];
  interests: string[];
  isProviderActive: boolean;
  isAdmin: boolean;
  verificationStatus: VerificationStatus;
  verificationDocumentType?: 'nid' | 'passport' | 'driving_license';
  verificationSubmittedAt?: string;
  isPhoneVerified?: boolean;
  isFaceVerified?: boolean;
  faceVerificationPhoto?: string;
  faceVerifiedAt?: string;
  professionalBadge?: string;
  voiceIntro?: {
    quote: string;
    durationSec: number;
    accent: string;
  };
  availableTimeSlots?: string[];
  password?: string;
  rating: number;
  reviewCount: number;
  joinedDate: string;
  referralCode?: string;
  referredByCode?: string;
  walletCredits?: number;
}

export interface ServiceCategory {
  id: string;
  name: string;
  nameBn: string;
  slug: string;
  description: string;
  icon: string;
  suggestedDuration: string;
  minPriceEstimate: number;
  isActive: boolean;
  order: number;
}

export type PricingUnit = 'hourly' | 'session' | 'package';
export type CancellationPolicy = 'flexible_24h' | 'moderate_48h' | 'strict_72h';

export interface ProviderService {
  id: string;
  providerId: string;
  categoryId: string;
  title: string;
  description: string;
  price: number; // in BDT ৳
  currency: 'BDT';
  pricingUnit: PricingUnit;
  durationHours: number;
  availableDurations: number[]; // e.g. [1, 2, 3] hours
  generalLocation: string; // e.g. "Gulshan, Banani, Uttara"
  advanceNoticeHours: number;
  cancellationPolicy: CancellationPolicy;
  serviceBoundaries: string[]; // explicit rules e.g., "Public spaces only", "No home visits"
  maxParticipants: number;
  isActive: boolean;
}

export interface AvailabilitySchedule {
  dayOfWeek: number; // 0 = Sunday, 1 = Monday, ... 6 = Saturday
  dayName: string;
  isAvailable: boolean;
  startHour: string; // "10:00"
  endHour: string;   // "21:00"
}

export type BookingStatus =
  | 'draft'
  | 'pending_acceptance'
  | 'accepted'
  | 'payment_pending'
  | 'confirmed'
  | 'in_progress'
  | 'completed'
  | 'declined'
  | 'cancelled'
  | 'refund_pending'
  | 'refunded';

export interface BookingPriceSnapshot {
  serviceTitle: string;
  categoryName: string;
  unitPrice: number;
  pricingUnit: PricingUnit;
  durationHours: number;
  subtotal: number;
  discountAmount?: number;
  promoCode?: string;
  platformFeeRate: number; // e.g. 0.20
  platformFeeAmount: number;
  totalPayable: number;
  providerEarnings: number;
  serviceBoundaries: string[];
  cancellationPolicy: CancellationPolicy;
}

export type PaymentMethod = 'bkash' | 'nagad' | 'sslcommerz' | 'card';
export type PaymentStatus = 'unpaid' | 'paid' | 'refunded' | 'failed';

export type MeetupState = 'scheduled' | 'active_live' | 'completed_safe';

export interface Booking {
  id: string;
  bookingCode: string; // e.g., "RAD-4921"
  customerId: string;
  providerId: string;
  serviceId: string;
  priceSnapshot: BookingPriceSnapshot;
  scheduledDate: string; // YYYY-MM-DD
  scheduledTime: string; // HH:mm
  durationHours: number;
  meetupLocation: string;
  venueId?: string;
  specialNotes?: string;
  status: BookingStatus;
  paymentMethod?: PaymentMethod;
  paymentStatus: PaymentStatus;
  transactionReference?: string;
  paidAt?: string;
  tipAmount?: number;
  meetupState?: MeetupState;
  meetupStartedAt?: string;
  meetupEndedAt?: string;
  cancellationReason?: string;
  declineReason?: string;
  consentAcknowledged: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentTransaction {
  id: string;
  bookingId: string;
  bookingCode: string;
  method: PaymentMethod;
  amount: number;
  platformFee: number;
  netProviderAmount: number;
  status: 'success' | 'refunded' | 'failed';
  gatewayTransactionId: string;
  isDemo: boolean;
  timestamp: string;
}

export type PayoutStatus = 'estimated' | 'pending' | 'eligible' | 'processing' | 'paid';

export interface PayoutRecord {
  id: string;
  providerId: string;
  bookingId: string;
  bookingCode: string;
  grossAmount: number;
  platformCommission: number;
  netPayoutAmount: number;
  payoutMethod: 'bkash' | 'nagad' | 'bank_transfer';
  accountNumber: string;
  status: PayoutStatus;
  requestedAt: string;
  processedAt?: string;
}

export interface Review {
  id: string;
  bookingId: string;
  customerId: string;
  customerName: string;
  customerAvatar: string;
  providerId: string;
  rating: number; // 1 to 5
  comment: string;
  providerReply?: string;
  createdAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  receiverId: string;
  text: string;
  timestamp: string;
  bookingReference?: string;
}

export interface Conversation {
  id: string;
  participantIds: [string, string];
  lastMessage: string;
  lastTimestamp: string;
  unreadCount: number;
  bookingId?: string;
}

export interface SafetyReport {
  id: string;
  reportedByUserId: string;
  reportedUserId: string;
  bookingCode?: string;
  reason: string;
  details: string;
  status: 'open' | 'investigating' | 'resolved' | 'dismissed';
  actionTaken?: string;
  createdAt: string;
}

export interface PlatformConfig {
  commissionRate: number; // default 0.20
  currencyCode: 'BDT';
  currencySymbol: '৳';
  initialCity: string;
  minAge: number;
  isDemoMode: boolean;
}

export type ReferralStatus = 'invited' | 'registered' | 'verified';

export interface ReferralRecord {
  id: string;
  referrerId: string;
  referredUserId?: string;
  friendName: string;
  friendEmail?: string;
  friendPhone?: string;
  referralCode: string;
  status: ReferralStatus;
  rewardCredits: number; // e.g. 500 BDT
  invitedAt: string;
  registeredAt?: string;
  verifiedAt?: string;
  verificationMethod?: 'face_and_nid' | 'face' | 'phone_otp' | 'nid';
  reminderSentAt?: string;
}

export type CreditTransactionType = 
  | 'referral_bonus' 
  | 'welcome_bonus' 
  | 'booking_discount' 
  | 'admin_adjustment';

export interface CreditTransaction {
  id: string;
  userId: string;
  amount: number; // positive for earned, negative for spent
  type: CreditTransactionType;
  description: string;
  descriptionBn: string;
  timestamp: string;
  balanceAfter: number;
  relatedReferralId?: string;
  relatedBookingId?: string;
}

