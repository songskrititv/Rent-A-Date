# Mobile PWA Installation & Phone Testing Plan

Prepare the platform for mobile phone testing and direct home screen installation as a Progressive Web App (PWA) with offline capabilities, Android Chrome `beforeinstallprompt` banner, and an interactive scan-to-test QR code modal.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following decisions were confirmed based on your preferences:
> - **Target Mobile OS**: Android (Google Chrome & Microsoft Edge).
> - **Discovery & Install Method**: Interactive QR code modal on desktop + in-app install banner on mobile.
> - **Service Worker & Caching**: Offline support enabled with service worker asset caching and stale-while-revalidate strategy.

- **Confirmed Decision 1**: Android-optimized Progressive Web App with standard PWA manifest compliance (`standalone` display, `id`, brand colors, maskable icons).
- **Confirmed Decision 2**: Interactive "Install on Phone / টেস্ট করুন ফোনে" modal in the top header and footer containing a live QR code linking to the live applet URL, direct URL copy, and step-by-step Chrome installation guide.
- **Confirmed Decision 3**: In-app installation banner listening for the browser's `beforeinstallprompt` event so Android users can install the native APK/WebAPK with a single tap.

---

## 1. Overview & Core Concept

- **What It Does**: Transforms the web application into an installable mobile Progressive Web App that runs standalone (without browser address bar) on Android phones. Users can scan a QR code from desktop to open the app on mobile Chrome, immediately see a native "Install to Phone" action banner, and test all features—including OTP verification, face verification camera capture, and referral workflows—even in intermittent network conditions.
- **Target Audience / Persona**: Testers, companion clients, and verified service providers operating on Android smartphones.
- **Key Value**: Direct testing on real physical hardware with authentic touch gestures, native camera access for face verification, full-screen mobile immersion, and home screen icon launch.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Desktop-to-Mobile Handoff**:
   - The user clicks the prominent **"Install on Phone / ফোনে ইনস্টল করুন"** button with a smartphone icon in the top navigation bar.
   - A modal opens displaying:
     - An interactive, scannable QR code encoded with the live app URL (`https://ais-pre-dky5rqq332fzy7mth275l4-664741093126.asia-southeast1.run.app`).
     - A quick-copy URL button with instant copy feedback toast.
     - 3-step visual instruction card for Android Chrome:
       1. *Scan with phone camera or Chrome.*
       2. *Tap "Install App" or Chrome menu (⋮) -> "Add to Home screen".*
       3. *Open from Home Screen like a native app.*

2. **Mobile Browser Launch & Prompt**:
   - When opened in mobile Chrome, a discreet bottom/top banner detects the mobile viewport and prompts: *"Install Sondhani to your Home Screen for fast access & camera verification"*.
   - Tapping **"Install Now"** triggers the native Android Chrome install dialog.

3. **Standalone App Experience**:
   - Once installed, launching the app opens with a branded splash screen, no URL bar, emerald/slate status bar styling, and smooth touch-optimized transitions.
   - Native mobile camera access works seamlessly for Face Verification.
   - Offline status indicator appears gracefully if connection drops, retaining cached pages and mock verification flows.

### Visual Identity & Theme
- **Theme Color**: Emerald primary `#059669` and deep slate `#0f172a` matching the existing verified aesthetic.
- **App Icons**: 192x192 and 512x512 rounded icons with appropriate safe-zone margins for Android adaptive squircle masks.
- **Typography & Touch Targets**: 48px minimum touch targets, high contrast badges, bilingual Bengali/English labels.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Native PWA vs Third-Party App Store Package**
  - *Chosen Approach*: Progressive Web App (PWA) with Web App Manifest, Service Worker, and WebAPK installation.
  - *Why*: Instant installation without needing Google Play Store submission or developer signing certificates; preserves rapid iteration cycle.
  - *Alternatives Considered*: Building a debug APK via Capacitor/Cordova (requires native Android SDK setup and manual sideloading APK files).

- **Decision 2: Lightweight Service Worker with Stale-While-Revalidate**
  - *Chosen Approach*: Standalone `sw.js` registered in `index.html` with cache-first asset strategy and network-first API/navigation fallback.
  - *Why*: Provides instant page loads and offline reliability without bundler incompatibilities or version conflicts.

- **Decision 3: Standalone QR Code Component**
  - *Chosen Approach*: Clean SVG-rendered QR code generator inside the phone installation modal.
  - *Why*: Zero third-party network dependency; renders instantly even in local dev or preview environments.

---

## 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────┐
│                       User Entrypoints                      │
│   Desktop Browser (Scan QR)    │    Mobile Chrome (Direct)  │
└───────────────┬───────────────────────────────┬─────────────┘
                │                               │
                ▼                               ▼
┌─────────────────────────────────────────────────────────────┐
│                 Web App Manifest & Meta Tags                │
│    • manifest.webmanifest (id, name, standalone, icons)     │
│    • apple-touch-icon, theme-color, viewport-fit=cover      │
└───────────────────────────────┬─────────────────────────────┘
                                │
                ▼───────────────┴───────────────▼
┌─────────────────────────────────────────────────────────────┐
│                   PWA Service Worker (sw.js)                │
│    • Precache: core CSS, JS bundles, icons, index shell     │
│    • Runtime Cache: images, static assets                   │
│    • Offline Fallback & Update Lifecycle                    │
└───────────────────────────────┬─────────────────────────────┘
                                │
                ▼───────────────┴───────────────▼
┌─────────────────────────────────────────────────────────────┐
│                      Client UI Modules                      │
│  ┌───────────────────────┐       ┌───────────────────────┐  │
│  │ PhoneInstallModal.tsx │       │ MobileInstallBar.tsx  │  │
│  │ • SVG QR Code Render  │       │ • beforeinstallprompt │  │
│  │ • 1-Click Copy Link   │       │ • Native Install Call │  │
│  │ • Android Guide Steps │       │ • Dismissable banner  │  │
│  └───────────────────────┘       └───────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ Header & Navigation Bar                               │  │
│  │ • "Install on Phone" action trigger                   │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### Key Components to Implement
1. `public/manifest.webmanifest`: Standard-compliant PWA manifest with `display: "standalone"`, `start_url: "/"`, theme colors, and icons.
2. `public/sw.js`: Service worker implementing precaching of shell assets and stale-while-revalidate offline support.
3. `public/icons/`: 192x192, 512x512, and maskable PWA icons.
4. `src/components/pwa/PhoneInstallModal.tsx`: Modal with QR code for immediate phone scanning, URL sharing, and Android installation instructions.
5. `src/components/pwa/MobileInstallBar.tsx`: Floating install banner capturing `beforeinstallprompt` for 1-tap Android installation.
6. Integration into `Header.tsx` and `App.tsx` with offline status toast indicator.
